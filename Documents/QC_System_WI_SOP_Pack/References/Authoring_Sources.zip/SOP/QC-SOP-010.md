# QC-SOP-010 — Raw data, instrument files and calculation control

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Maintain traceable raw observations, files, calculations and reported values throughout a test.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Laboratory; QC Supervisor; Document Control; IT

Review: Laboratory; QC Supervisor; Document Control; IT

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The approved method specifies required raw data and calculation inputs.

- The permitted storage and file-upload policy is established.

- Each file can be associated with a record, sample and run.

## 4. Procedure

1. Capture raw readings at the time of work. Identify instrument, program, sample, run, operator and time; retain the instrument printout or original electronic file.

2. Register the original file and its stored digest through the supported evidence process. A filename or local path alone is not an approved registered source.

3. Link the file to the correct record and identify which portion supports which observation. If one image shows several forms, retain that relationship in the source register.

4. Record units at acquisition and calculation. Preserve the distinction between gauge and absolute pressure, cm³ and litres, seconds and minutes and N·m versus N/m.

5. For a proposed stable-volume, approximately isothermal pressure-throughput calculation, q = V × abs(Pstart − Pend) / Δt gives Pa·cm³/s when V is cm³ and pressure is Pa. It is a review proposal, not the equipment algorithm or a product acceptance criterion.

6. The method owner must address temperature change, deformation, fixture/background leakage, effective volume, uncertainty, sign convention and standard-state conversion before approving this calculation.

7. Retain all calculation inputs, rule reference/version, calculated value and calculation unit. Compare selected calculations independently without changing the raw readings.

8. Protect historical files and audit records from replacement. If a file is wrong, add a controlled correction and a new traceable file rather than overwriting the original.

## 5. Decisions, errors and stop conditions

- An unreadable file or inconsistent unit blocks the related conclusion.

- A successful upload does not prove malware scan, MIME validation, approved retention or long-term retrieval; those require separate evidence.

## 6. Records and handoff

- Original file and SHA-256

- Record/run/sample link

- Calculation rule and inputs

- Independent check

- File correction history

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/domain/measurement.ts

- Documents/DATA-GOVERNANCE-REGISTER-032.md

- EXT-009

Related work instructions: QC-WI-018, QC-WI-019

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-006 — Leak calculation validation

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-006 — Calculation validation and discrepancy handling

For an engineering check under constant effective volume and approximately isothermal conditions, propose q = V × abs(Pstart - Pend) / elapsed time. Use Pa, cm³ and seconds consistently; kPa converts to Pa by 1000 and litres to cm³ by 1000. Document whether pressures are gauge or absolute and whether compensation, reference volume, compliance, background or standard-condition normalization applies. Validate against the actual manufacturer algorithm before official use.

Decision and exception check: Observed discrepancy for investigation: IMG-048 print shows V=2.04 cm³, 330.781 and 327.852 kPa, 20 s and an output 2981 Pa·cm³/s. The simple dimensional check gives 298.758 Pa·cm³/s. These differ by about tenfold. This is not proof of an incorrect machine; printed volume/time semantics or internal scaling may differ. Require an explanation and validation dataset.

Record: QC-REC-006 calculation validation: raw readings, units, formula/version, instrument output, independent result, difference and reviewer disposition.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

## 11. Official physical record workflow

Use a separate run row for each sample/replicate. Record connector type, sample count, lot and sampling area, then equipment identity/medium, assembly force, torque, time and angle. Record actual temperature and humidity in the environmental block; an empty block remains missing information.

Enter set pressure (sp), applied pressure (tp), volume (v), pressure difference, holding time and instrument leakage result in their printed units. Retain the printer ticket with serial/run identifier and timestamp. Match each ticket to its sample row; do not assume the top ticket describes every row underneath. Distinguish setpoint from achieved pressure.

F-8-2-6-05 Rev04 prints 300–330 kPa, 15–20 s and <5000 Pa·cm³/s. F-8-2-6-07 Rev4 prints −80 to −88 kPa with the same time/limit. These are observed company-form values; adoption for a product requires the form/method reconciliation in DEC-004. A pressure outside the source range or a failed stability check needs investigation even if reported leakage is below the limit.

Mark the run outcome only after validity and criterion checks. Complete the overall PASS, FAIL or HOLD/FURTHER EVALUATION block separately from individual rows. Retain Tested by, Reviewed by and Approved by sections with actual identities/dates; do not fill a blank historical signature. Attach an investigation when independent calculation and printer output disagree.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
