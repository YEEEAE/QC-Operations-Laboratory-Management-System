# QC-SOP-006 — Quarantine, HOLD and release control

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Maintain physical and digital material status through inspection, HOLD, release or rejection.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC Supervisor; QCM; Authorized release actor; Warehouse

Review: QC Supervisor; QCM; Authorized release actor; Warehouse

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- A receiving record identifies the material and physical location.

- The applicable inspection and release authority is assigned.

- P-05 permissions and separation of duties apply.

## 4. Procedure

1. Label and segregate the lot according to the approved site practice. Reconcile the label with the receiving record; a digital state does not move or segregate physical goods.

2. Progress through PENDING, READY_FOR_INSPECTION and UNDER_INSPECTION only through available authorized actions. Record readiness evidence before starting.

3. An approved inspection can set INSPECTION_COMPLETE. Keep the inspection result PASS, FAIL or HOLD separate from the receiving workflow state.

4. Place an affected lot on HOLD when identity, evidence, equipment, method or outcome is unresolved. Record the reason and scope; stop physical use or movement unless an authorized containment instruction allows it.

5. Before release, confirm RELEASE_PENDING, official inspectionResult PASS, applicable evidence and absence of blocking conditions. PERM-QUAR-RELEASE and P-05 authority are required; the inspection author cannot self-release.

6. Invoke RELEASE and then reload the receiving record. Confirm RELEASED and the persisted release evidence before warehouse movement. A screen message or test PASS alone is insufficient.

7. HOLD has no general outgoing transition in the current receiving state map. Do not assume REMOVE_HOLD is available merely because an action type exists. Obtain an approved disposition and a separately supported correction or recovery path.

8. For rejection, retain the lot identity and link the authorized rejection record and quality follow-up. Do not treat a reject slip as permission for rework, transfer or destruction unless the approved disposition grants it.

## 5. Decisions, errors and stop conditions

- HOLD, FAIL or unavailable official result prevents release.

- If the server denies release, retain segregation and investigate the denied prerequisite; do not broaden permissions to complete the action.

## 6. Records and handoff

- Location and status label

- HOLD reason and affected quantity

- Inspection approval

- Release or rejection evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/release-receiving.ts

- src/modules/quarantine/receiving/domain/receiving-state.ts

- src/shared/authorization/p05-authority.ts

Related work instructions: QC-WI-003, QC-WI-004, QC-WI-005

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quarantine

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-027 — HOLD investigation and physical disposition

Investigate the reason and assemble the receiving, inspection/lab, equipment, source and discrepancy evidence. The authorized disposition owner decides continued HOLD, additional work, rejection, rework or release eligibility under an approved path. Record the decision and its conditions before moving material. Warehouse verifies identity and quantity against the signed disposition.

Decision and exception check: The current receiving state machine has no general outgoing HOLD transition. A proposed REMOVE_HOLD workflow must be implemented and verified under change control before digital use; do not edit the database or substitute a new receiving record. Physical release evidence and digital state must be reconciled, and no stale label is reused.

Record: QC-REC-020 HOLD and disposition; QC-SOP-006; QC-WI-004/005.

## 11. Official physical record workflow

Start with the yellow QC copy of F-7-5-7-1 Rev5 and the delivery/PO attachments. The printed distribution assigns original to Accounts, pink to Store Keeper, yellow to QC and blue to Production. Record which physical copy was checked; keep a readable linked scan when one photograph contains several overlapping pages.

Read Supplier’s Name, P.O. Ref. No., Ref. No., Ser. No. and Date independently. Ref. No. and Ser. No. may be different identifiers and must not overwrite each other. For each line, compare Sr. No., Item code no., Item Description, Unit, Qty. Received, Lot No. and Exp. Date to the actual label. Separate ordered quantity from this receipt quantity and preserve split deliveries.

Count containers and reconcile line totals in the same unit. Retain the original strike-through/correction and supporting note; ask the responsible source owner to explain a disagreement. Store Keeper acknowledgment establishes the physical receipt record; it does not establish QC release. Associate the digital receiving record with its exact paper line and evidence image/page.

Completion check: supplier, PO, item, lot, quantity/unit, receipt date and expiry agree across the physical item, slip and saved record; unresolved differences are linked to containment and Purchasing/Store Keeper clarification.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
