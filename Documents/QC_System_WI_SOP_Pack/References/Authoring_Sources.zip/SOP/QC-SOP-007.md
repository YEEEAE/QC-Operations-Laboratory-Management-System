# QC-SOP-007 — Sampling and sample custody

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Select representative samples, protect lot identity and record sample custody through testing and disposition.

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL CUSTODY AND PLAN CONTROL REQUIRED

## 2. Responsibilities and review

Responsible specialists: QC Supervisor; Sampling operator; Laboratory

Review: QC Supervisor; Sampling operator; Laboratory

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- A technical owner has approved the sampling plan and defect classification.

- The lot boundary and quantity unit are known.

- The site has an approved sample handling and disposal practice.

## 4. Procedure

1. Define the lot by product, size, supplier, lot number and manufacturing or receiving context. Resolve mixed-lot material before selecting samples.

2. Use the approved sampling plan, including lot size, inspection level, AQL or another justified design, code letter, sample size, acceptance/rejection counts and switching rules where applicable.

3. Do not infer a plan from twelve form rows, a handwritten sample size, a historical acceptance mark or this draft. ISO 2859-1:2026 is a candidate attributes-sampling source that requires licensed-text review and owner adoption.

4. Select units using the approved representative method across the lot. Identify each selected unit or defined sample group and record the location and selection method.

5. Label samples with receiving reference, lot, product, sample identifier, date and collector. Preserve packaging conditions and any environmental handling limits from the approved method.

6. Record each handoff: sender, receiver, time, condition, destination and purpose. Use a controlled manual custody record where the application has no dedicated custody function.

7. On laboratory receipt, reconcile identifiers and quantity with the request. Record damage, missing units or broken custody before testing.

8. After testing, identify consumed, retained and returnable samples. Follow the approved retention and disposal instruction; this draft sets no period.

## 5. Decisions, errors and stop conditions

- If the plan or lot boundary is unapproved, stop acceptance sampling.

- A substituted or damaged sample requires a documented technical decision; never replace a failing unit without retaining the original evidence.

## 6. Records and handoff

- Sampling plan and selection log

- Sample identity

- Custody handoffs

- Retention or disposal disposition

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

- src/modules/laboratory/domain/lab-test.ts

- EXT-008

Related work instructions: QC-WI-009, QC-WI-010

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-003 — Sampling plan

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-003 — Lot definition and sampling

The QC planner selects the approved sampling procedure and records edition, lot quantity, normal/tightened/reduced status, inspection level, defect classes, AQL or alternative rationale, code letter, sample size and Ac/Re. Select across containers or production positions using the documented random/systematic method. Allocate destructive and non-destructive samples separately and prevent replacement of an unfavorable sample without an investigation.

Decision and exception check: Compare total samples actually tested with the plan and reconcile extra runs, repeats and retained samples. The supplied feeding-tube record has a Sample Size entry and a different checked-quantity remark; reconcile that difference before using its plan as a precedent. A re-evaluation of a few retained items does not become acceptance of a new incoming lot.

Record: QC-REC-003 sampling and custody plan; per-sample identifiers; original AQL/code/Ac/Re block.

DEC-019 — Training, custody and movement

The assessor observes identity checks, correct source selection, a normal task, a deliberate exception, raw-data recording and safe handoff. Record each result and restriction. Reassess following a significant method/equipment change, an observed competence failure or the approved review schedule. Training attendance alone is insufficient.

Decision and exception check: For custody, record sample ID, parent lot, selection time, selector, quantity, condition, container/seal and every transfer with both parties and time. For movement, reconcile opening quantity, received/transferred, tested/destroyed, reworked, scrapped and closing balance in one unit. Discrepancies stop handoff until explained; maintain quarantine identity through transport.

Record: QC-REC-003, QC-REC-010 movement, QC-REC-012 competency; QC-SOP-002/007/016.

## 11. Official physical record workflow

Prepare the specific company inspection form before opening the digital template. Record the form number/revision, According to WI reference, supplier or Product Re-evaluation context, PO/date, lot, received quantity, size/type/color and inspection date. A re-evaluation without a purchase order is not an invented new receipt.

Give each selected piece a sample identity and retain its container/lot relationship. Execute every applicable printed point; record an observation or reading in Remarks and the required sample level/size. Follow the legend: acceptable, not acceptable, read remarks and not applicable are distinct. Explain NA against product design; do not copy NA from another lot.

Reconcile AQL, Code Letter, Accept, Reject, Results and Status with actual sample counts and adverse remarks. The checkmark in Accepted is part of the original record; an unresolved unfavorable remark still requires a documented review when establishing a new digital conclusion. Preserve Checked by OBM Inspectors and Reviewed by Q.C.M as the original paper roles.

Completion check: all rows and remarks are legible, sample count and subgroup totals reconcile, test references and raw readings are attached, and the review relates to the exact product/lot and form revision.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
