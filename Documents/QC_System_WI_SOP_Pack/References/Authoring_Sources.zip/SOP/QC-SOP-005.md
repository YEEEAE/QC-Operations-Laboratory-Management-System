# QC-SOP-005 — Receiving corrections and record conflicts

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Correct recorded receiving facts without overwriting inspection snapshots or historical decisions.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator; QC Supervisor; Record owner

Review: QC entry operator; QC Supervisor; Record owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The original source and reason for correction are available.

- PERM-QUAR-EDIT, scope and expectedVersion permit the action.

- The record is in PENDING, READY_FOR_INSPECTION, HOLD or EXPIRED.

## 4. Procedure

1. Open the receiving detail and read its current workflow state and version. Determine whether the error is a receiving fact or an inspection finding.

2. Use the populated correction entry from the detail page. Compare the opened values with the source; preserve the original record and evidence.

3. Enter corrected supplier, document, item, lot, quantity, unit, purchase-order and date fields only where the source supports the change. Add a meaningful reason identifying the wrong fact and the supporting record.

4. Submit the form with the version it opened. Do not replace the expected version with a freshly fetched value merely to force a stale submission through.

5. Reload after confirmed success and compare the new values, version and correction history. Confirm that the reason was recorded and the original evidence remains retrievable.

6. If another user changed the record, compare both versions before deciding what to enter again. Keep the unsaved proposed correction outside the historical record until it has been reconciled.

7. From UNDER_INSPECTION onward, use the inspection and HOLD disposition process for snapshot-bound facts. RELEASED and CANCELLED history must not be silently edited.

8. When the response is uncertain, look up the existing record and action history before retrying. A network error can occur after the server committed.

## 5. Decisions, errors and stop conditions

- A stale version requires reconciliation, not automatic overwrite.

- If the source is missing or the correction would alter an approved snapshot, stop and escalate to the record owner.

## 6. Records and handoff

- Correction reason

- Original and corrected values

- Version-conflict reconciliation

- Audit event

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/correct-receiving.ts

- src/modules/quarantine/receiving/domain/receiving-state.ts

Related work instructions: QC-WI-002, QC-WI-007

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-027 — HOLD investigation and physical disposition

Investigate the reason and assemble the receiving, inspection/lab, equipment, source and discrepancy evidence. The authorized disposition owner decides continued HOLD, additional work, rejection, rework or release eligibility under an approved path. Record the decision and its conditions before moving material. Warehouse verifies identity and quantity against the signed disposition.

Decision and exception check: The current receiving state machine has no general outgoing HOLD transition. A proposed REMOVE_HOLD workflow must be implemented and verified under change control before digital use; do not edit the database or substitute a new receiving record. Physical release evidence and digital state must be reconciled, and no stale label is reused.

Record: QC-REC-020 HOLD and disposition; QC-SOP-006; QC-WI-004/005.

## 11. Official physical record workflow

Start with the yellow QC copy of F-7-5-7-1 Rev5 and the delivery/PO attachments. The printed distribution assigns original to Accounts, pink to Store Keeper, yellow to QC and blue to Production. Record which physical copy was checked; keep a readable linked scan when one photograph contains several overlapping pages.

Read Supplier’s Name, P.O. Ref. No., Ref. No., Ser. No. and Date independently. Ref. No. and Ser. No. may be different identifiers and must not overwrite each other. For each line, compare Sr. No., Item code no., Item Description, Unit, Qty. Received, Lot No. and Exp. Date to the actual label. Separate ordered quantity from this receipt quantity and preserve split deliveries.

Count containers and reconcile line totals in the same unit. Retain the original strike-through/correction and supporting note; ask the responsible source owner to explain a disagreement. Store Keeper acknowledgment establishes the physical receipt record; it does not establish QC release. Associate the digital receiving record with its exact paper line and evidence image/page.

Completion check: supplier, PO, item, lot, quantity/unit, receipt date and expiry agree across the physical item, slip and saved record; unresolved differences are linked to containment and Purchasing/Store Keeper clarification.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
