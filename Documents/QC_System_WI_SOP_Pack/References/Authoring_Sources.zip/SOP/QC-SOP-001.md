# QC-SOP-001 — Document control and approval of this pack

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Control the creation, review, approval, distribution, revision and withdrawal of procedures, work instructions and linked company forms.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Document Control; QMS; QC Manager

Review: Document Control; QMS; QC Manager

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The master register identifies every draft and its reviewer.

- Reviewers have the current source files, original forms and applicable approved policy.

- The approved signature and effectivity policy must exist before controlled use.

## 4. Procedure

1. Document Control assigns the independent QC-SOP or QC-WI number and records D0.2. Keep the company form number unchanged in the form register; these are different identifiers.

2. The author writes the actual workflow, identifies proposed manual work and links each scientific claim to a specific source. A photograph is evidence of a record or printed field, not proof that a method remains effective.

3. A QC specialist checks technical content and applicability. Engineering checks routes, field names, permissions and supported actions. QMS checks authority, retention, change control and the distinction between a result and a release.

4. Resolve comments in a new draft revision and preserve the earlier review history. Record the disposition of each comment; do not silently remove a technical objection.

5. Before approval, the responsible owner resolves the relevant DEC entries. A reviewer may accept the writing while a method remains unapproved; record those outcomes separately.

6. Approve only through the authorized controlled process. Generic document approval is currently blocked by POLICY_SOURCE_REQUIRED while RD-019 and PD-32 are unresolved. Do not use an alternate page or direct database update.

7. Record the actual approval evidence and effective date only after the ceremony occurs. APPROVED is separate from EFFECTIVE. Withdraw superseded copies at the point of use while retaining history.

8. Train affected personnel on the effective revision and verify that the delivered SOP PDF or WI DOCX, archived Markdown and master register have the same revision and content. A draft print remains visibly marked DRAFT FOR REVIEW.

## 5. Decisions, errors and stop conditions

- If a source changes, reassess the affected procedure and update its source binding before continued controlled use.

- If the approval or effectivity policy is missing, retain the document as draft. No automatic promotion is permitted.

## 6. Records and handoff

- Master document register

- Review comment disposition

- Approval and effectivity evidence

- Training and distribution records

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- src/modules/documents/domain/document-state.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

- DEC-020 — Retention, file safety and record storage

- DEC-028 — Source description conflicts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-016 — Document, change and signature policy

Bind the decision to document number/revision, file digest, actor, role/scope, decision meaning, timestamp and authentication evidence. Preserve rejection/return reasons. Reopening creates a new review cycle without erasing the signed predecessor. A changed file invalidates the pending approval binding and requires renewed review.

Decision and exception check: Proposed separation: author cannot give their own final approval; reviewers may request corrections but may not replace raw evidence; only an approved release/distribution role may make a revision effective. Maintain current application denial for generic approval while RD-019/PD-32 are unresolved. Adopt this policy through the real owner/QMS process before implementation.

Record: QC-REC-009 review, approval and effectivity record; QC-SOP-001/011/022/023.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

DEC-028 — Source description reconciliation

For each form, preserve company number, revision, printed date, image ID/hash, observed fields and workflow context. For a conflicting narrative, state the observed evidence and the newer authority source. Distinguish paper availability from digital template integration, and historical signer evidence from a new digital signature.

Decision and exception check: Closure rule for the source-availability description: all 84 files are indexed, readable derivatives exist, and the official physical-use attestation is recorded. Remaining incomplete form suffixes and scientific/effectivity conflicts remain with their specific decisions. Do not mark those technically resolved by the general attestation.

Record: Official_Physical_Records_Basis.pdf; form-register.pdf; image-register.pdf; user attestation 2026-10-04.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
