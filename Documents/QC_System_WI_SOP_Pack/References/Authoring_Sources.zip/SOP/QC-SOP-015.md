# QC-SOP-015 — Daily production and rejection reporting

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Capture daily production/rejection details and interpret analytics with a defined quantity unit and denominator.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Production; QC entry operator; Authorized finalizer; QMS

Review: Production; QC entry operator; Authorized finalizer; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- Production source records identify date, machine, product, lot and quantities.

- PERM-RREJ-CREATE and eligible edit permissions apply.

- QMS approves the reporting metric and denominator before formal use.

## 4. Procedure

1. Open /reject-reports/new?type=daily and identify the production period, section and department. Link the original daily production/rejection form.

2. Enter each line from production evidence with product, lot, unit, good quantity, rejected quantity and reason as supported by the form.

3. Append lines using the current expectedVersion. The repository serializes row position, version, audit and outbox changes; do not renumber stored history manually.

4. Keep decimal quantities as exact text and group analytics by report type and unit. Do not total incompatible units or silently round inputs.

5. The current implementation reports rejected quantity divided by good quantity, multiplied by 100 and rounded to four decimals; good quantity zero yields NULL. This is not automatically a defect proportion of total output.

6. The approved reporting owner must confirm the metric name, denominator and interpretation. Until then, label this behavior as implemented and under review in formal reports.

7. The authorized finalizer advances DRAFT to FINALIZED. QC entry users cannot finalize or void, even when they created the report.

8. Reopen the persisted report and reconcile line totals and displayed percentage with raw source data. Retain explanations for adjustments and the final action history.

## 5. Decisions, errors and stop conditions

- A zero denominator is unavailable/undefined, not zero percent.

- If screen, export and source disagree, stop distribution and use the report-provenance investigation.

## 6. Records and handoff

- Daily report lines

- Original F-7-5-3-12-2 or verified company revision

- Metric definition

- Finalization evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Related work instructions: QC-WI-024

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /reject-reports/daily/[reportId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-017 — Rejection, physical disposition and metrics

For production-origin stock, route to the actual required Production, QC and Director authorities. For warehouse-origin stock, the supplied record explicitly notes that Production signature is not required; record the documented exception and its scope for that record. Do not map Production Manager to the application SUPERVISOR merely because both appear first in an approval chain.

Decision and exception check: QC entry records facts and prepares the report; actual approval confirmations are recorded only by an authorized confirming actor with source evidence. Rework or transfer needs a separate completed movement record and quantity reconciliation. Report the implemented reject/good ×100 metric under that explicit label; zero good denominator is undefined, not zero rejection. Any change to reject/total requires an approved definition and code change.

Record: QC-WI-022/023/024/025; FORM-015; IMG-066; QC-REC-008/010.

## 11. Official physical record workflow

Use F-7-5-7-8 Rev4. Select the actual Production/Warehouse origin, record date, item description, lot, unit, line quantity and total quantity. Attach the referenced incident/test report and identify the exact reason for rejection, including item code where shown in remarks.

Complete preparation and review in the physical workflow. Keep Checked by Production Team distinct from Reviewed by Quality Controller, and keep both distinct from the approval section for Production Manager, Quality Control Manager and Factory Director. The photographed warehouse report carries a documented Production-signature exception; retain its scope without generalizing it to every rejection.

Record proposed Rework, Transfer to Warehouse or Other disposition, then obtain the real approval before execution. Rework completion needs its own evidence and reinspection; selecting Rework does not show that it happened. Reconcile quantities sent, returned, scrapped and remaining. The digital confirmation is entered only by an authorized actor and linked to the real source.

Completion check: origin, lot, unit, quantities, reason, disposition, approval evidence and movement/reinspection references all agree. Keep the original report with its signatures and dates intact.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
