# QC-SOP-019 — Task assignment and work handoff

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Track assigned work and its evidence without allowing task completion to substitute for controlled approval.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Task owner; Assignee; Supervisor

Review: Task owner; Assignee; Supervisor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The work and intended output are defined.

- The creator and assignee have the required task permissions and scope.

- Related QC records are identifiable.

## 4. Procedure

1. Create a task with a clear title, required outcome and assigned owner. Include the related receiving, laboratory, quality or asset identifier in the supported context.

2. Set due dates only from the authorized work plan. Do not invent a regulatory deadline or change a controlled decision through task text.

3. The assignee checks the work context and required prerequisites before starting. Raise a source or authority blocker when the task cannot be performed safely.

4. Record progress and evidence through permitted task actions. Keep reasons for delay, reassignment or return factual and concise.

5. On completion, link the actual output and explain any remaining limitation. A checkbox without the requested evidence is not completed work.

6. The receiving person reviews the deliverable and confirms the handoff. Preserve the task action history.

7. Use the appropriate domain workflow for approval, release, closure or signature; a completed task does not grant those statuses.

8. Review /work and task lists with their scope and source availability. An empty bounded page is not proof that no work exists.

## 5. Decisions, errors and stop conditions

- If the controlled prerequisite is missing, document the blocker rather than marking the task complete.

- Do not use assignment to bypass ownership or separation-of-duties checks.

## 6. Records and handoff

- Task and assignment

- Progress and output evidence

- Handoff

- Blocker and action history

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/tasks/domain/state.ts

- src/shared/routing/routes.ts

Related work instructions: QC-WI-031

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /tasks

- /tasks/new

- /tasks/[taskId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-019 — Training, custody and movement

The assessor observes identity checks, correct source selection, a normal task, a deliberate exception, raw-data recording and safe handoff. Record each result and restriction. Reassess following a significant method/equipment change, an observed competence failure or the approved review schedule. Training attendance alone is insufficient.

Decision and exception check: For custody, record sample ID, parent lot, selection time, selector, quantity, condition, container/seal and every transfer with both parties and time. For movement, reconcile opening quantity, received/transferred, tested/destroyed, reworked, scrapped and closing balance in one unit. Discrepancies stop handoff until explained; maintain quarantine identity through transport.

Record: QC-REC-003, QC-REC-010 movement, QC-REC-012 competency; QC-SOP-002/007/016.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
