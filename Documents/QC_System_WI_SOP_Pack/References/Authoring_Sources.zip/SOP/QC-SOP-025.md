# QC-SOP-025 — Reports, provenance and controlled exports

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Produce scoped reports and exports with explicit filters, units, provenance and consistent screen/export data.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Report owner; QC/QMS; Authorized reader

Review: Report owner; QC/QMS; Authorized reader

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- PERM-RPT-VIEW and source domain scope permit access.

- The report purpose and approved metric definition are known.

- Source availability can be distinguished from empty results.

## 4. Procedure

1. Select the report and record its period, filters, quantity unit and requesting purpose. Confirm that scope excludes inaccessible records and counts.

2. Review the source status. Denied, unavailable, missing and empty are different outcomes; unavailable counts must not be presented as zero.

3. Compare displayed rows and totals using the same predicates. Check unit grouping and the approved denominator before interpreting a percentage.

4. Generate export from the supported report action and compare its provenance/filter context with the screen snapshot.

5. If the source changes before export, the current digest check may return REPORT_DATASET_CHANGED. Refresh and review a new coherent dataset rather than distributing a mixed snapshot.

6. Retain the report evidence in the approved location. Current request-local digests are not a durable retained report snapshot or signed certificate.

7. Mark convenience prints and unapproved outputs accordingly. Do not infer approved scientific status from formatting or a logo.

8. Record distribution and any report correction under approved policy. Preserve the original issued version and explain material changes.

## 5. Decisions, errors and stop conditions

- A stale dataset, missing source or unsupported denominator stops formal distribution.

- An export is read-only evidence of the returned dataset, not a new approval or release.

## 6. Records and handoff

- Filters and provenance

- Screen/export reconciliation

- Dataset-change response

- Approved distribution record

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- src/modules/reporting

- Documents/DATA-GOVERNANCE-REGISTER-032.md

Related work instructions: QC-WI-043

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /reports

- /reports/[reportCode]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-017 — Rejection, physical disposition and metrics

For production-origin stock, route to the actual required Production, QC and Director authorities. For warehouse-origin stock, the supplied record explicitly notes that Production signature is not required; record the documented exception and its scope for that record. Do not map Production Manager to the application SUPERVISOR merely because both appear first in an approval chain.

Decision and exception check: QC entry records facts and prepares the report; actual approval confirmations are recorded only by an authorized confirming actor with source evidence. Rework or transfer needs a separate completed movement record and quantity reconciliation. Report the implemented reject/good ×100 metric under that explicit label; zero good denominator is undefined, not zero rejection. Any change to reject/total requires an approved definition and code change.

Record: QC-WI-022/023/024/025; FORM-015; IMG-066; QC-REC-008/010.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
