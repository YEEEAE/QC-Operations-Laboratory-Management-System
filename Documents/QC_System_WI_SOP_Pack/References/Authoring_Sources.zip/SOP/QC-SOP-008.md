# QC-SOP-008 — Incoming and product inspection

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Inspect identified products using the correct approved template and preserve per-point evidence and source applicability.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC operator; Supervisor; QCM; Product specialist

Review: QC operator; Supervisor; QCM; Product specialist

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The receiving record is eligible to start inspection.

- The template, source revision and criteria apply to the exact product and size.

- The operator has PERM-QUAR-START-INSPECTION and execution permissions.

## 4. Procedure

1. Review receiving identity, quantity, lot and supplier paperwork. Confirm that any unresolved receiving discrepancy has an approved disposition before starting.

2. Choose the applicable approved inspection template and preserve its snapshot. A later template edit must not change the inspection that already began.

3. Identify the sampled units and the approved plan. Inspect packaging, identification, dimensions and functional points required for that product; family instructions QC-WI-052 through QC-WI-060 provide review proposals.

4. Record the observation for every applicable point, the unit, equipment reference, remarks and raw evidence. Use only an approved rule for not-applicable points; handwritten N/A does not establish a digital datatype.

5. Where a numeric or judgment criterion lacks approved source lineage, stop evaluation and retain the observation for technical review. The system intentionally denies unsupported scientific evaluation.

6. Submit the complete record to Supervisor review. Resolve returns in the author correction path and preserve original evidence.

7. Supervisor stage approval moves UNDER_REVIEW to PENDING_QCM_APPROVAL without a formal stage-1 e-signature. QCM final approval requires the approved FINAL_APPROVE ceremony and produces APPROVED.

8. Hand the official inspection outcome to receiving control. APPROVED inspection and PASS do not themselves release the lot.

## 5. Decisions, errors and stop conditions

- A failed, incomplete or contradictory point requires containment and a documented review decision.

- An approved template status does not substitute for approved scientific source, effectivity or applicability.

## 6. Records and handoff

- Inspection snapshot

- Sample-level observations

- Raw attachments

- Review return and final approval evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/inspection/domain/inspection-state.ts

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-011, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-003 — Sampling plan

- DEC-005 — Per-point and overall evaluation

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-001 — Source adoption and applicability

The technical owner prepares a product matrix by item code, size, material, connector, sterile/bulk condition and intended use. For each row, identify the current company WI, product specification and external standard where applicable. Document Control compares the controlled master with the photographed copy. A newer standard edition triggers an impact review; it does not silently replace the company method.

Decision and exception check: An applicable source package passes review when the exact revision can be retrieved, every mandatory point has a source and method, and the reviewer has resolved conflicting instructions. Preserve existing physical record outcomes as recorded. Registering them digitally does not create a new approval or retrospective release.

Record: QC-REC-001 source adoption record; company form register; clause-to-point matrix.

DEC-003 — Lot definition and sampling

The QC planner selects the approved sampling procedure and records edition, lot quantity, normal/tightened/reduced status, inspection level, defect classes, AQL or alternative rationale, code letter, sample size and Ac/Re. Select across containers or production positions using the documented random/systematic method. Allocate destructive and non-destructive samples separately and prevent replacement of an unfavorable sample without an investigation.

Decision and exception check: Compare total samples actually tested with the plan and reconcile extra runs, repeats and retained samples. The supplied feeding-tube record has a Sample Size entry and a different checked-quantity remark; reconcile that difference before using its plan as a precedent. A re-evaluation of a few retained items does not become acceptance of a new incoming lot.

Record: QC-REC-003 sampling and custody plan; per-sample identifiers; original AQL/code/Ac/Re block.

DEC-005 — Point evaluation and overall result

For a valid numeric run, retain the unrounded observation and compare by the exact approved operator. For visual checks, record a concrete observation and the form legend. The physical legend distinguishes acceptable, not acceptable, read remarks and not applicable. Preserve R as a review requirement and NA with a point-specific reason; neither becomes a automatic PASS.

Decision and exception check: Proposed aggregation: all required applicable points must have valid accepted outcomes before an overall pass is proposed. Any failed required point prevents a pass; missing/invalid/conflicted evidence remains HOLD/further evaluation. A reviewer resolves contradictory remarks even when an Accepted box is ticked. Lot release is a separate disposition.

Record: QC-REC-005 acceptance-point specification and review; original per-point result and remarks.

## 11. Official physical record workflow

Prepare the specific company inspection form before opening the digital template. Record the form number/revision, According to WI reference, supplier or Product Re-evaluation context, PO/date, lot, received quantity, size/type/color and inspection date. A re-evaluation without a purchase order is not an invented new receipt.

Give each selected piece a sample identity and retain its container/lot relationship. Execute every applicable printed point; record an observation or reading in Remarks and the required sample level/size. Follow the legend: acceptable, not acceptable, read remarks and not applicable are distinct. Explain NA against product design; do not copy NA from another lot.

Reconcile AQL, Code Letter, Accept, Reject, Results and Status with actual sample counts and adverse remarks. The checkmark in Accepted is part of the original record; an unresolved unfavorable remark still requires a documented review when establishing a new digital conclusion. Preserve Checked by OBM Inspectors and Reviewed by Q.C.M as the original paper roles.

Completion check: all rows and remarks are legible, sample count and subgroup totals reconcile, test references and raw readings are attached, and the review relates to the exact product/lot and form revision.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
