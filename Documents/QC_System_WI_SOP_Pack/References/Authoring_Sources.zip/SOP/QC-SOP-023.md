# QC-SOP-023 — Controlled change requests

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Evaluate, authorize, implement and verify changes without bypassing the approval transaction or losing source version context.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Change requester; Assigned reviewer; QMS; Named owner

Review: Change requester; Assigned reviewer; QMS; Named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The requested change and affected records are identified.

- The applicable change authority and signature policy is approved.

- The request references the opened current version.

## 4. Procedure

1. Create the change request with the proposed change, reason, affected product/process/system and supporting evidence.

2. Assess scientific, workflow, security, data, training, document and operational impact. Identify any new source or approval needed before implementation.

3. Submit and start review through the supported state actions. The review page has native version-bound START_REVIEW; it does not confer direct decision authority.

4. Record review findings and return incomplete work through the authorized process. Keep the reason and exact version.

5. RETURN, APPROVE and REJECT decision paths require approval transaction context. PD-32 remains unresolved; do not call a direct transition to circumvent the block.

6. After actual authorization, plan the implementation, owner, controlled environment, rollback/recovery prerequisites and acceptance criteria.

7. Implement only within the granted scope, preserve baseline evidence and produce verification tied to the resulting candidate and dirty tree.

8. Close or apply the request only through its supported authorized path and retrievable completion evidence. Update affected documents and training after approved changes.

## 5. Decisions, errors and stop conditions

- A blocked authority policy stops the decision and implementation authorization.

- A source test pass is not proof the change was applied in the operating environment.

## 6. Records and handoff

- Change request

- Impact assessment

- Version-bound approval evidence

- Implementation and verification

- Document/training updates

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/change-requests

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-038

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /change-requests

- /change-requests/new

- /change-requests/[changeRequestId]

- /change-requests/[changeRequestId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-016 — Document, change and signature policy

Bind the decision to document number/revision, file digest, actor, role/scope, decision meaning, timestamp and authentication evidence. Preserve rejection/return reasons. Reopening creates a new review cycle without erasing the signed predecessor. A changed file invalidates the pending approval binding and requires renewed review.

Decision and exception check: Proposed separation: author cannot give their own final approval; reviewers may request corrections but may not replace raw evidence; only an approved release/distribution role may make a revision effective. Maintain current application denial for generic approval while RD-019/PD-32 are unresolved. Adopt this policy through the real owner/QMS process before implementation.

Record: QC-REC-009 review, approval and effectivity record; QC-SOP-001/011/022/023.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
