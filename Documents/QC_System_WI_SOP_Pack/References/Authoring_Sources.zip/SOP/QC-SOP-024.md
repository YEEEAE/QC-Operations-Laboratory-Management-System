# QC-SOP-024 — Records, audit, retention and corrections

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Maintain accountable records and audit history, manage authorized correction and retain evidence under approved policy.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QMS; Document Control; IT; Record owners

Review: QMS; Document Control; IT; Record owners

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- Record classes, access and retention authority are defined.

- The storage location and restore responsibilities are approved.

- The actor has the record-specific permission and eligible state.

## 4. Procedure

1. Capture facts at the time of work with the record identifier, actor, date, source and version. Preserve the difference between an observation, a calculated value and a decision.

2. Use the application transaction for controlled changes. Domain record, signature where required, audit and outbox must commit together; do not patch history manually.

3. Review corrections for reason, source and affected prior decisions. Use reopened or new-revision paths where records are locked.

4. Store originals and registered digests with controlled links. Identify unreadable, cropped or conflicting forms and obtain the original rather than reconstructing unsupported text.

5. QMS approves retention periods, archival, legal hold, deletion and retrieval requirements per record class. This draft assigns no numeric retention term.

6. Protect audit and signature records from ordinary update/delete access. Support extracts must avoid credentials, tokens and unnecessary personal information.

7. Verify retrieval and restoration in the approved environment with raw files and database records. A local hash list proves file identity, not long-term recoverability.

8. Record discrepancies as an incident or quality concern and assess whether conclusions or released material are affected.

## 5. Decisions, errors and stop conditions

- Missing retention or storage policy is an approval decision, not permission to delete.

- Audit row presence alone does not prove a valid signature, provider delivery or physical activity.

## 6. Records and handoff

- Record-class policy

- Original and digest

- Correction/revision history

- Access and retrieval evidence

- Archive/disposal authorization

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DATA-GOVERNANCE-REGISTER-032.md

- src/shared/authorization/authorize.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-062

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /audit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
