# QC-SOP-021 — Calibration and maintenance control

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Plan, record and review calibration and maintenance while protecting equipment history and work eligibility.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Metrology; Equipment owner; Maintenance; QMS

Review: Metrology; Equipment owner; Maintenance; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The calibration method, interval, tolerances and traceability requirements are approved.

- The service provider and certificate can be verified.

- The actor has the relevant calibration or maintenance permission.

## 4. Procedure

1. Identify the equipment, service scope and approved due date. This pack sets no universal interval or tolerance.

2. Create the calibration or maintenance record from the real work request. Link the asset and preserve service evidence, certificate and results.

3. Record as-found and as-left condition where the approved method requires them. If out of tolerance, identify affected test work for technical impact assessment.

4. Review the provider certificate for asset identity, date, method, traceability, results, uncertainty and approval. A file attachment alone is not an accepted calibration.

5. Progress through supported calibration or maintenance actions and verify the persisted state after each action.

6. Keep equipment ineligible while blocking maintenance is active or matching calibration is absent, not current or overdue.

7. Do not force MAKE_CURRENT or VOID through a direct state update. These actions remain policy-dependent or denied where the current use case has no approved authority.

8. After authorized completion, check the equipment eligibility projection and required functional checks before returning it to controlled use.

## 5. Decisions, errors and stop conditions

- Unverified provider evidence or an unresolved out-of-tolerance impact prevents unrestricted use.

- A maintenance completion record does not itself establish calibration validity.

## 6. Records and handoff

- Service record

- Calibration certificate and review

- As-found/as-left data

- Impact review

- Return-to-use evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/assets/calibration/domain/calibration.ts

- src/modules/assets/maintenance/domain/maintenance.ts

- src/modules/assets/equipment/infrastructure/eligibility-reader.ts

Related work instructions: QC-WI-033, QC-WI-034

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-002 — Leak-test equipment manual and safety

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /assets/calibrations

- /assets/calibrations/new

- /assets/calibrations/[calibrationId]

- /assets/maintenance

- /assets/maintenance/new

- /assets/maintenance/[maintenanceId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-002 — Equipment readiness and safe operation

At the instrument, read the nameplate and record asset ID, manufacturer/model, serial, controller/software version, pressure sensor ranges, fixture identity, regulator and reference device. Match the calibration certificate to that serial and range. Attach the actual operator manual and identify its sections for connection, pressurization, isolation, emergency stop and safe venting. Record pre-use checks with a known reference and fixture/background leak check under that manual.

Decision and exception check: Stop for an unreadable label, expired or mismatched calibration, damaged connection, failed reference check or an uncontrolled program. Make the system safe using the instrument procedure; retain the failed run and identify all affected work since the last acceptable check. A maintenance completion requires a documented return-to-use check.

Record: QC-REC-002 equipment readiness and run setup; equipment/calibration/maintenance records.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
