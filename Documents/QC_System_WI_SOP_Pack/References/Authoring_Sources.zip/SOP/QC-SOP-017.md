# QC-SOP-017 — Findings and nonconformance control

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record findings, contain nonconformity and maintain the Finding to NCR link and closure evidence.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC; Supervisor; Quality process owner

Review: QC; Supervisor; Quality process owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The concern can be described with retrievable evidence.

- PERM-FIND-CREATE and PERM-NCR-CREATE apply to creation.

- The approved quality policy defines required containment and investigation.

## 4. Procedure

1. Record the factual observation, location, product or process reference and supporting evidence. Separate what was seen from the suspected cause.

2. Create the Finding with a meaningful title and description. Preserve the affected record identifiers and scope.

3. Assign immediate containment through the approved operational process. Record affected lots and quantities, responsible person and action evidence.

4. Where the approved prerequisites allow an NCR, create it from the persisted Finding link. Caller-supplied flags do not replace persisted prerequisites.

5. Review the NCR classification, owner and investigation requirements under the approved policy. The October quality decision pack contains proposals that must not be treated as approved authority.

6. Link relevant inspection, lab, rejection and task records. Maintain one clear evidence trail rather than copying conflicting summaries.

7. Advance only through actions allowed by the current state and permissions. Record reasons for return, void or closure where required.

8. Hand an NCR requiring causal analysis to RCA/CAPA. Retain the original finding even after the corrective process is complete.

## 5. Decisions, errors and stop conditions

- If containment or a required prerequisite cannot be proven, do not advance the lifecycle.

- QC entry users do not gain close or approval authority by creating the record.

## 6. Records and handoff

- Finding

- NCR and persisted predecessor

- Containment evidence

- Related records and handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/findings/domain/finding.ts

- src/modules/quality/ncr/domain/ncr.ts

- Documents/QUALITY-POLICY-DECISION-PACK-2026-10-02.md

Related work instructions: QC-WI-026, QC-WI-027

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/ncr

- /quality/ncr/new

- /quality/ncr/[ncrId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-018 — Finding to CAPA lifecycle

At NCR creation, link the finding, source requirement, product/lot/process, immediate containment, risk assessment and owner. At RCA review, distinguish verified causes from hypotheses and include evidence that could disprove the cause. At CAPA planning, assign each action, due date, completion evidence, verifier and effectiveness measure with a justified observation period.

Decision and exception check: An action marked complete is not proof of effectiveness. Record the planned versus actual observation window and denominator of opportunities or recurrence. Preserve the source P-04 exceptional Supervisor closure with its reason, reauthentication/signature and residual-risk follow-up; do not label incomplete or ineffective work effective merely because closure is permitted.

Record: QC-REC-011 quality investigation and effectiveness record; QC-SOP-017/018.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
