# QC-SOP-013 — Laboratory report-form transcription

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Transcribe physical Pressure Decay and Subatmospheric report forms into the draft report surface without treating transcription as controlled evaluation.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator; Laboratory; Document Control

Review: QC entry operator; Laboratory; Document Control

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The original report is legible and its form revision is identified.

- PERM-LAB-VIEW, PERM-LAB-CREATE or PERM-LAB-EDIT-DRAFT apply as needed.

- The original form is listed in the form register.

## 4. Procedure

1. Select /laboratory/report-templates and the matching Pressure Decay or Subatmospheric draft type. Verify the original form identity; FR-MA-018 Rev06 and F-8-2-6-07 Rev4 have materially different printed parameters.

2. Transcribe identification, equipment, assembly, environment, sample rows, remarks and historical result exactly as recorded. Preserve uncertainty instead of guessing an illegible digit.

3. Record the company form number and revision in the external source register. These drafts currently have no controlled source-link or promotion mechanism, so the register is the traceability companion.

4. The digital form has twelve sample rows. This layout is not a sampling plan, and it does not justify twelve tests for every lot.

5. Keep Tested By, Reviewed By and Approved By as historical transcription text. They do not create electronic signatures or prove current signer authority.

6. Save and reopen the draft, compare all entered fields against the original and record discrepancies for correction.

7. Use print only as a convenient draft representation. Do not present it as an approved laboratory result or promote it into qc.lab_tests by an undocumented process.

8. Retain the original record and its hash. Any later controlled test must be separately created with approved source, method, authority and evidence.

## 5. Decisions, errors and stop conditions

- If source values are unreadable or contradict printed limits, flag them for review.

- A transcribed PASS, FAIL or HOLD remains a historical source value and is not a computed outcome.

## 6. Records and handoff

- Report draft

- Original source reference

- Transcription check

- Unresolved field list

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/LABORATORY-REPORT-TEMPLATES.md

- src/modules/laboratory/application/report-drafts.ts

Related work instructions: QC-WI-021

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-004 — Leak-form revision and unit conflict

- DEC-028 — Source description conflicts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /laboratory/report-templates

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-004 — Leakage form revision reconciliation

Create a comparison of pressure direction/basis, set pressure, actual pressure, assembly force, torque unit, assembly time, angle, temperature, humidity, effective volume, measurement time and leakage unit. Record the newest form as the proposed current candidate only after Document Control confirms its distribution status. Resolve the printed N/m versus N·m label and the printout label showing seconds beside a pressure-difference symbol through the method/instrument owner.

Decision and exception check: A form may be transcribed while its uncertain labels are retained verbatim and flagged. New testing needs a coherent approved source. The 2026 forms print a leakage limit below 5000 Pa·cm³/s, whereas the older form prints a different value; the revision number alone does not prove equivalence or authorize conversion.

Record: QC-REC-004 method and form reconciliation; images IMG-040, IMG-048 and IMG-070.

DEC-028 — Source description reconciliation

For each form, preserve company number, revision, printed date, image ID/hash, observed fields and workflow context. For a conflicting narrative, state the observed evidence and the newer authority source. Distinguish paper availability from digital template integration, and historical signer evidence from a new digital signature.

Decision and exception check: Closure rule for the source-availability description: all 84 files are indexed, readable derivatives exist, and the official physical-use attestation is recorded. Remaining incomplete form suffixes and scientific/effectivity conflicts remain with their specific decisions. Do not mark those technically resolved by the general attestation.

Record: Official_Physical_Records_Basis.pdf; form-register.pdf; image-register.pdf; user attestation 2026-10-04.

## 11. Official physical record workflow

Use a separate run row for each sample/replicate. Record connector type, sample count, lot and sampling area, then equipment identity/medium, assembly force, torque, time and angle. Record actual temperature and humidity in the environmental block; an empty block remains missing information.

Enter set pressure (sp), applied pressure (tp), volume (v), pressure difference, holding time and instrument leakage result in their printed units. Retain the printer ticket with serial/run identifier and timestamp. Match each ticket to its sample row; do not assume the top ticket describes every row underneath. Distinguish setpoint from achieved pressure.

F-8-2-6-05 Rev04 prints 300–330 kPa, 15–20 s and <5000 Pa·cm³/s. F-8-2-6-07 Rev4 prints −80 to −88 kPa with the same time/limit. These are observed company-form values; adoption for a product requires the form/method reconciliation in DEC-004. A pressure outside the source range or a failed stability check needs investigation even if reported leakage is below the limit.

Mark the run outcome only after validity and criterion checks. Complete the overall PASS, FAIL or HOLD/FURTHER EVALUATION block separately from individual rows. Retain Tested by, Reviewed by and Approved by sections with actual identities/dates; do not fill a blank historical signature. Attach an investigation when independent calculation and printer output disagree.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
