# QC-SOP-002 — Personnel training and competency

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Qualify people for physical testing and digital tasks before independent work; maintain a role-specific training record.

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL TRAINING TRACKING REQUIRED

## 2. Responsibilities and review

Responsible specialists: QMS; QC Supervisor; Technical specialists

Review: QMS; QC Supervisor; Technical specialists

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- An effective procedure and the approved role assignment exist.

- The technical reviewer defines a practical competency assessment for the task.

- A controlled training record is available; there is no dedicated digital training module in this source inventory.

## 4. Procedure

1. List the operations the person will perform, including product family, equipment, template revision and review stage. Page access alone does not establish competence.

2. The trainer explains the procedure and demonstrates the task with authorized training material. Use isolated training records; do not create fake production results.

3. The trainee performs a supervised exercise, identifies a deliberately presented discrepancy, preserves raw data and demonstrates the relevant stop condition.

4. The assessor records the observed work and any limitations. For scientific methods, assess instrument setup, units, calculation checks, uncertainty and handling of an invalid run.

5. The technical owner authorizes the permitted tasks after the assessment. Keep competence approval separate from granting application permissions.

6. Document Control records the procedure revision, trainer, assessment evidence, outcome and actual authorization date. Store personal information in the controlled training location.

7. Reassess after a relevant procedure, equipment or method change and after a demonstrated competence concern. QMS must approve the reassessment interval; this draft assigns no interval.

8. Remove the person from independent work when authorization expires or performance is unacceptable. Arrange supervised retraining and record the restoration decision.

## 5. Decisions, errors and stop conditions

- An incomplete assessment requires supervision and prevents independent testing.

- Training attendance does not prove competence, and a typed trainer name does not prove a signature.

## 6. Records and handoff

- Training matrix

- Practical assessment

- Task authorization

- Retraining record

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/ROLE-MATRIX.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Related work instructions: QC-WI-039

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-019 — Training, custody and movement

The assessor observes identity checks, correct source selection, a normal task, a deliberate exception, raw-data recording and safe handoff. Record each result and restriction. Reassess following a significant method/equipment change, an observed competence failure or the approved review schedule. Training attendance alone is insufficient.

Decision and exception check: For custody, record sample ID, parent lot, selection time, selector, quantity, condition, container/seal and every transfer with both parties and time. For movement, reconcile opening quantity, received/transferred, tested/destroyed, reworked, scrapped and closing balance in one unit. Discrepancies stop handoff until explained; maintain quarantine identity through transport.

Record: QC-REC-003, QC-REC-010 movement, QC-REC-012 competency; QC-SOP-002/007/016.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
