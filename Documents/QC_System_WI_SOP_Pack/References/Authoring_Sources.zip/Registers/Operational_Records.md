# Operational records and continuation sheets

D0.2 | DRAFT FOR REVIEW

Blank proposed records for controlled adoption. They supplement original company forms without replacing their numbers or signatures. Enter actual observations only. Mark not applicable with a reason; do not prefill approval.

## QC-REC-001 — Source adoption

Linked SOP/WI and company form revision: ____________________

Company document number: __________________________________________________

revision: __________________________________________________

custodian: __________________________________________________

product/item/size/material/connector: __________________________________________________

applicable clause/point: __________________________________________________

source hash: __________________________________________________

adoption decision: __________________________________________________

reviewer: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-002 — Equipment readiness and setup

Linked SOP/WI and company form revision: ____________________

Asset/model/serial: __________________________________________________

fixture: __________________________________________________

manual/program revision: __________________________________________________

calibration certificate/range/due date: __________________________________________________

reference check: __________________________________________________

environment: __________________________________________________

set and actual settings: __________________________________________________

safe vent check: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-003 — Sampling and custody

Linked SOP/WI and company form revision: ____________________

Receipt/lot: __________________________________________________

lot quantity: __________________________________________________

plan/source revision: __________________________________________________

inspection level: __________________________________________________

code/AQL/Ac/Re if applicable: __________________________________________________

sample IDs: __________________________________________________

locations: __________________________________________________

quantity drawn/returned/destroyed: __________________________________________________

custody handoffs: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-004 — Method and form reconciliation

Linked SOP/WI and company form revision: ____________________

Old/new form revisions: __________________________________________________

disputed field/unit: __________________________________________________

original transcription: __________________________________________________

source image/page: __________________________________________________

proposed interpretation: __________________________________________________

technical rationale: __________________________________________________

owner resolution: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-005 — Acceptance point definition

Linked SOP/WI and company form revision: ____________________

Product/variant: __________________________________________________

point ID: __________________________________________________

source clause: __________________________________________________

method: __________________________________________________

type: __________________________________________________

unit: __________________________________________________

lower/upper/operator: __________________________________________________

NA rule: __________________________________________________

uncertainty/rounding: __________________________________________________

evaluator: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-006 — Calculation validation

Linked SOP/WI and company form revision: ____________________

Run/raw attachment: __________________________________________________

input values/units: __________________________________________________

equation and version: __________________________________________________

independent calculation: __________________________________________________

instrument result: __________________________________________________

difference: __________________________________________________

tolerance source: __________________________________________________

investigation: __________________________________________________

reviewer: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-007 — Product inspection continuation

Linked SOP/WI and company form revision: ____________________

Company form/revision: __________________________________________________

product/lot/sample: __________________________________________________

point: __________________________________________________

original mark: __________________________________________________

observation: __________________________________________________

measured value/unit: __________________________________________________

source limit: __________________________________________________

disposition for point: __________________________________________________

attachment: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-008 — Rejection and disposition

Linked SOP/WI and company form revision: ____________________

Issue slip ID: __________________________________________________

product/lot: __________________________________________________

quantity: __________________________________________________

defect/source: __________________________________________________

containment location: __________________________________________________

production signature applicability/rationale: __________________________________________________

QC review: __________________________________________________

authorized disposition: __________________________________________________

handoff: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-009 — Review approval and effectivity

Linked SOP/WI and company form revision: ____________________

Record ID/version/hash: __________________________________________________

author: __________________________________________________

reviewer: __________________________________________________

review outcome: __________________________________________________

approver authority: __________________________________________________

signature evidence ID: __________________________________________________

approval time: __________________________________________________

separate effectivity decision/date: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-010 — Movement and rework balance

Linked SOP/WI and company form revision: ____________________

Origin/destination: __________________________________________________

lot: __________________________________________________

initial quantity: __________________________________________________

moved/reworked/scrapped/remaining: __________________________________________________

reconciliation: __________________________________________________

work instruction: __________________________________________________

verification: __________________________________________________

custody receipt: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-011 — Finding NCR RCA CAPA effectiveness

Linked SOP/WI and company form revision: ____________________

Linked records: __________________________________________________

factual finding: __________________________________________________

requirement: __________________________________________________

containment: __________________________________________________

cause evidence: __________________________________________________

action/owner: __________________________________________________

verification criterion: __________________________________________________

follow-up sample/window: __________________________________________________

actual outcome: __________________________________________________

closure authority: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-012 — Training and competency

Linked SOP/WI and company form revision: ____________________

Person/role: __________________________________________________

document revision: __________________________________________________

trainer: __________________________________________________

demonstration task: __________________________________________________

observed errors: __________________________________________________

assessment result: __________________________________________________

limitations: __________________________________________________

reassessment: __________________________________________________

authorization: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-013 — Retention retrieval and disposal

Linked SOP/WI and company form revision: ____________________

Record class/owner: __________________________________________________

retention source: __________________________________________________

trigger/date: __________________________________________________

legal hold: __________________________________________________

storage/access: __________________________________________________

retrieval check: __________________________________________________

disposal approval: __________________________________________________

execution evidence: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-014 — Recovery exercise

Linked SOP/WI and company form revision: ____________________

Authorization: __________________________________________________

isolated target: __________________________________________________

backup IDs/timestamps/hashes: __________________________________________________

database/files scope: __________________________________________________

restore steps: __________________________________________________

actual recovery time: __________________________________________________

integrity checks: __________________________________________________

measured RPO/RTO: __________________________________________________

exceptions: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-015 — Worker telemetry and alerts

Linked SOP/WI and company form revision: ____________________

Worker/version: __________________________________________________

heartbeat: __________________________________________________

outbox/correlation IDs: __________________________________________________

attempt: __________________________________________________

channel receipt: __________________________________________________

telemetry query: __________________________________________________

alert trigger: __________________________________________________

receiver acknowledgement: __________________________________________________

recovery: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-016 — AI request assessment

Linked SOP/WI and company form revision: ____________________

Purpose: __________________________________________________

data classification: __________________________________________________

permitted provider/model: __________________________________________________

policy version: __________________________________________________

external-processing authority: __________________________________________________

consent: __________________________________________________

redaction: __________________________________________________

advisory output: __________________________________________________

human decision: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-017 — Release gates and UAT

Linked SOP/WI and company form revision: ____________________

Candidate SHA/dirty fingerprint: __________________________________________________

gate ID: __________________________________________________

approved criterion/owner: __________________________________________________

evidence: __________________________________________________

human actor/session/scenario: __________________________________________________

actual result: __________________________________________________

defect: __________________________________________________

decision: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-018 — Performance baseline

Linked SOP/WI and company form revision: ____________________

Environment/candidate: __________________________________________________

scenario: __________________________________________________

data volume: __________________________________________________

concurrency: __________________________________________________

warmup: __________________________________________________

sample count: __________________________________________________

raw timings: __________________________________________________

percentile method: __________________________________________________

budget/source: __________________________________________________

measured result: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-019 — Invalidation and retest

Linked SOP/WI and company form revision: ____________________

Original run/result: __________________________________________________

failure vs invalidity rationale: __________________________________________________

retained raw data: __________________________________________________

affected scope: __________________________________________________

authorization: __________________________________________________

retest link: __________________________________________________

original/new comparison: __________________________________________________

review: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

## QC-REC-020 — HOLD and containment

Linked SOP/WI and company form revision: ____________________

Record/lot: __________________________________________________

reason: __________________________________________________

affected quantity: __________________________________________________

physical location/label: __________________________________________________

blocked movement: __________________________________________________

system state: __________________________________________________

investigation owner: __________________________________________________

authorized resolution path: __________________________________________________

release evidence: __________________________________________________

Prepared by/date: ____________________

Reviewed by/date/outcome: ____________________

Evidence attachment IDs and unresolved exceptions: ____________________

