# Official physical records — source basis

D0.2 | 2026-10-04

The process owner confirmed in this task that QC_Controlled_Forms_and_Operational_Evidence contains official forms, documents and reports used physically. The 84 originals are retained byte-for-byte in Original_Company_Forms.zip and are readable in Company_Forms_Visual_Reference.pdf. This confirmation resolves whether these are genuine operating source materials for this authoring task. It does not establish the effectivity of a newly drafted procedure.

## Receiving

Start with the yellow QC copy of F-7-5-7-1 Rev5 and the delivery/PO attachments. The printed distribution assigns original to Accounts, pink to Store Keeper, yellow to QC and blue to Production. Record which physical copy was checked; keep a readable linked scan when one photograph contains several overlapping pages.

Read Supplier’s Name, P.O. Ref. No., Ref. No., Ser. No. and Date independently. Ref. No. and Ser. No. may be different identifiers and must not overwrite each other. For each line, compare Sr. No., Item code no., Item Description, Unit, Qty. Received, Lot No. and Exp. Date to the actual label. Separate ordered quantity from this receipt quantity and preserve split deliveries.

Count containers and reconcile line totals in the same unit. Retain the original strike-through/correction and supporting note; ask the responsible source owner to explain a disagreement. Store Keeper acknowledgment establishes the physical receipt record; it does not establish QC release. Associate the digital receiving record with its exact paper line and evidence image/page.

Completion check: supplier, PO, item, lot, quantity/unit, receipt date and expiry agree across the physical item, slip and saved record; unresolved differences are linked to containment and Purchasing/Store Keeper clarification.

## Inspection

Prepare the specific company inspection form before opening the digital template. Record the form number/revision, According to WI reference, supplier or Product Re-evaluation context, PO/date, lot, received quantity, size/type/color and inspection date. A re-evaluation without a purchase order is not an invented new receipt.

Give each selected piece a sample identity and retain its container/lot relationship. Execute every applicable printed point; record an observation or reading in Remarks and the required sample level/size. Follow the legend: acceptable, not acceptable, read remarks and not applicable are distinct. Explain NA against product design; do not copy NA from another lot.

Reconcile AQL, Code Letter, Accept, Reject, Results and Status with actual sample counts and adverse remarks. The checkmark in Accepted is part of the original record; an unresolved unfavorable remark still requires a documented review when establishing a new digital conclusion. Preserve Checked by OBM Inspectors and Reviewed by Q.C.M as the original paper roles.

Completion check: all rows and remarks are legible, sample count and subgroup totals reconcile, test references and raw readings are attached, and the review relates to the exact product/lot and form revision.

## Leak

Use a separate run row for each sample/replicate. Record connector type, sample count, lot and sampling area, then equipment identity/medium, assembly force, torque, time and angle. Record actual temperature and humidity in the environmental block; an empty block remains missing information.

Enter set pressure (sp), applied pressure (tp), volume (v), pressure difference, holding time and instrument leakage result in their printed units. Retain the printer ticket with serial/run identifier and timestamp. Match each ticket to its sample row; do not assume the top ticket describes every row underneath. Distinguish setpoint from achieved pressure.

F-8-2-6-05 Rev04 prints 300–330 kPa, 15–20 s and <5000 Pa·cm³/s. F-8-2-6-07 Rev4 prints −80 to −88 kPa with the same time/limit. These are observed company-form values; adoption for a product requires the form/method reconciliation in DEC-004. A pressure outside the source range or a failed stability check needs investigation even if reported leakage is below the limit.

Mark the run outcome only after validity and criterion checks. Complete the overall PASS, FAIL or HOLD/FURTHER EVALUATION block separately from individual rows. Retain Tested by, Reviewed by and Approved by sections with actual identities/dates; do not fill a blank historical signature. Attach an investigation when independent calculation and printer output disagree.

## Reject

Use F-7-5-7-8 Rev4. Select the actual Production/Warehouse origin, record date, item description, lot, unit, line quantity and total quantity. Attach the referenced incident/test report and identify the exact reason for rejection, including item code where shown in remarks.

Complete preparation and review in the physical workflow. Keep Checked by Production Team distinct from Reviewed by Quality Controller, and keep both distinct from the approval section for Production Manager, Quality Control Manager and Factory Director. The photographed warehouse report carries a documented Production-signature exception; retain its scope without generalizing it to every rejection.

Record proposed Rework, Transfer to Warehouse or Other disposition, then obtain the real approval before execution. Rework completion needs its own evidence and reinspection; selecting Rework does not show that it happened. Reconcile quantities sent, returned, scrapped and remaining. The digital confirmation is entered only by an authorized actor and linked to the real source.

Completion check: origin, lot, unit, quantities, reason, disposition, approval evidence and movement/reinspection references all agree. Keep the original report with its signatures and dates intact.

