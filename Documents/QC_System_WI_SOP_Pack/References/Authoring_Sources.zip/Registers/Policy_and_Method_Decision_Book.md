# Policy and method decision book

D0.2 | DRAFT FOR REVIEW | 2026-10-04

All 28 topics have complete draft proposals below. New policy adoption and technical evidence remain distinct from document drafting. Official physical use of the supplied company records is confirmed by the owner. No new signature or effectivity has been created.

## DEC-001 — Source adoption and applicability

Proposed policy: Accept the supplied company forms and completed reports as official physical operating records, as confirmed by the process owner on 2026-10-04. Keep their company document number and revision. Register a new source by identity, revision, issue date, custodian and SHA-256; link each acceptance point to a specific clause, drawing dimension or printed form requirement.

Execution: The technical owner prepares a product matrix by item code, size, material, connector, sterile/bulk condition and intended use. For each row, identify the current company WI, product specification and external standard where applicable. Document Control compares the controlled master with the photographed copy. A newer standard edition triggers an impact review; it does not silently replace the company method.

Acceptance and exceptions: An applicable source package passes review when the exact revision can be retrieved, every mandatory point has a source and method, and the reviewer has resolved conflicting instructions. Preserve existing physical record outcomes as recorded. Registering them digitally does not create a new approval or retrospective release.

Records: QC-REC-001 source adoption record; company form register; clause-to-point matrix.

Remaining authoritative input: The full referenced company WIs/drawings and licensed method clauses are not all present in the image set. Source registration can be prepared now; new method effectivity requires the actual document-control decision.

## DEC-002 — Equipment readiness and safe operation

Proposed policy: Use only identified equipment and fixtures within their approved operating range. The generic description on the leakage forms identifies a test function but does not identify the manufacturer, model, serial number or program revision.

Execution: At the instrument, read the nameplate and record asset ID, manufacturer/model, serial, controller/software version, pressure sensor ranges, fixture identity, regulator and reference device. Match the calibration certificate to that serial and range. Attach the actual operator manual and identify its sections for connection, pressurization, isolation, emergency stop and safe venting. Record pre-use checks with a known reference and fixture/background leak check under that manual.

Acceptance and exceptions: Stop for an unreadable label, expired or mismatched calibration, damaged connection, failed reference check or an uncontrolled program. Make the system safe using the instrument procedure; retain the failed run and identify all affected work since the last acceptable check. A maintenance completion requires a documented return-to-use check.

Records: QC-REC-002 equipment readiness and run setup; equipment/calibration/maintenance records.

Remaining authoritative input: The make/model, manual, approved pressure/vacuum safety envelope and reference-check limits still need instrument-side evidence. Do not derive safety ratings from a report printout.

## DEC-003 — Lot definition and sampling

Proposed policy: Define each lot by item code, supplier/manufacturing batch, variant, condition and quantity unit. A mixed variant or connector design needs explicit stratification or separation before selection. The number of printed rows is not a sampling plan.

Execution: The QC planner selects the approved sampling procedure and records edition, lot quantity, normal/tightened/reduced status, inspection level, defect classes, AQL or alternative rationale, code letter, sample size and Ac/Re. Select across containers or production positions using the documented random/systematic method. Allocate destructive and non-destructive samples separately and prevent replacement of an unfavorable sample without an investigation.

Acceptance and exceptions: Compare total samples actually tested with the plan and reconcile extra runs, repeats and retained samples. The supplied feeding-tube record has a Sample Size entry and a different checked-quantity remark; reconcile that difference before using its plan as a precedent. A re-evaluation of a few retained items does not become acceptance of a new incoming lot.

Records: QC-REC-003 sampling and custody plan; per-sample identifiers; original AQL/code/Ac/Re block.

Remaining authoritative input: The owner must select the actual plan and acceptance numbers for each product and defect class. Examples written in completed reports are evidence of those records only.

## DEC-004 — Leakage form revision reconciliation

Proposed policy: Use F-8-2-6-05 Rev04 for the pressure-decay record and identify F-8-2-6-07 Rev4 and FR-MA-018 Rev06 separately for subatmospheric records. Retain the printed revision on historical reports. Never merge their units or acceptance limits into one universal template.

Execution: Create a comparison of pressure direction/basis, set pressure, actual pressure, assembly force, torque unit, assembly time, angle, temperature, humidity, effective volume, measurement time and leakage unit. Record the newest form as the proposed current candidate only after Document Control confirms its distribution status. Resolve the printed N/m versus N·m label and the printout label showing seconds beside a pressure-difference symbol through the method/instrument owner.

Acceptance and exceptions: A form may be transcribed while its uncertain labels are retained verbatim and flagged. New testing needs a coherent approved source. The 2026 forms print a leakage limit below 5000 Pa·cm³/s, whereas the older form prints a different value; the revision number alone does not prove equivalence or authorize conversion.

Records: QC-REC-004 method and form reconciliation; images IMG-040, IMG-048 and IMG-070.

Remaining authoritative input: Revision effectivity, conflicting limits and instrument label interpretation require a signed technical disposition; historical results must not be rewritten.

## DEC-005 — Point evaluation and overall result

Proposed policy: Create an acceptance-point record containing point ID, product scope, source revision/page, method, data type, unit, required/optional flag, comparison operator, limits where present, precision and designated evaluator. Copy source wording without turning a qualitative observation into an invented numeric threshold.

Execution: For a valid numeric run, retain the unrounded observation and compare by the exact approved operator. For visual checks, record a concrete observation and the form legend. The physical legend distinguishes acceptable, not acceptable, read remarks and not applicable. Preserve R as a review requirement and NA with a point-specific reason; neither becomes a automatic PASS.

Acceptance and exceptions: Proposed aggregation: all required applicable points must have valid accepted outcomes before an overall pass is proposed. Any failed required point prevents a pass; missing/invalid/conflicted evidence remains HOLD/further evaluation. A reviewer resolves contradictory remarks even when an Accepted box is ticked. Lot release is a separate disposition.

Records: QC-REC-005 acceptance-point specification and review; original per-point result and remarks.

Remaining authoritative input: Aggregation, rounding, uncertainty rule and manual evaluator authority are drafted here for approval. No numeric criteria absent from the original source are supplied.

## DEC-006 — Calculation validation and discrepancy handling

Proposed policy: Treat the original instrument output as primary measured evidence. A separately calculated value is a verification result with its own rule revision; it must not overwrite the instrument value.

Execution: For an engineering check under constant effective volume and approximately isothermal conditions, propose q = V × abs(Pstart - Pend) / elapsed time. Use Pa, cm³ and seconds consistently; kPa converts to Pa by 1000 and litres to cm³ by 1000. Document whether pressures are gauge or absolute and whether compensation, reference volume, compliance, background or standard-condition normalization applies. Validate against the actual manufacturer algorithm before official use.

Acceptance and exceptions: Observed discrepancy for investigation: IMG-048 print shows V=2.04 cm³, 330.781 and 327.852 kPa, 20 s and an output 2981 Pa·cm³/s. The simple dimensional check gives 298.758 Pa·cm³/s. These differ by about tenfold. This is not proof of an incorrect machine; printed volume/time semantics or internal scaling may differ. Require an explanation and validation dataset.

Records: QC-REC-006 calculation validation: raw readings, units, formula/version, instrument output, independent result, difference and reviewer disposition.

Remaining authoritative input: The instrument algorithm, effective volume and corrections are unresolved. Do not adopt the proposed equation as a replacement algorithm or retroactively invalidate reports from this check alone.

## DEC-007 — Oral medication syringe inspection

Proposed policy: Use F-823-T61-2 Rev0 (01.01.2024) and the oral-product source referenced on the actual report. Maintain oral intended use as a separate scope from hypodermic and enteral connectors.

Execution: Inspect packaging and identity first; then body/nozzle irregularities, barrel, scale, plunger, rubber fit, lubrication, liquid leakage, aspiration leakage and dead space. Record size, tip and marked units, especially tsp/ml/cc. The observed report is a re-evaluation with a small retained sample; record that context explicitly. Link any volume check to the cylinder identity and certificate and retain both reference and equipment readings.

Acceptance and exceptions: The form includes printed accuracy bands and a dead-space reference to specification. Record those as company form criteria awaiting method/application reconciliation; define test fill level, medium, meniscus/temperature correction and repeat plan from the actual WI. Do not adopt an enteral-system method automatically: ISO 20695 excludes oral syringes.

Records: QC-WI-052; FORM-006; IMG-074/075; QC-REC-005 and QC-REC-007.

Remaining authoritative input: The referenced oral product specification, intended volume range and dead-space procedure must be supplied for reproducible physical testing.

## DEC-008 — Syringe variants and volume verification

Proposed policy: Use F-823-T61 Rev3 (20.03.2024). Record the exact type: Luer lock, Luer tip, catheter tip or side nozzle as applicable. A photographed catheter-tip syringe is not evidence that every syringe is within a Luer test scope.

Execution: Complete the 17 inspection points in the printed sequence. Inspect scale, piston, nozzle and barrel/wings before clinical-fit, liquid, aspiration and spillage tests. Record lubrication and sterile/bulk presentation. Preserve the original pH requirement of 5.0–6.0 and the printed accuracy bands as observed company-source text; attach the source method before executing or validating those tests.

Acceptance and exceptions: For volume verification, identify the calibrated reference cylinder, certificate, nominal test point, reference reading, observed syringe reading and error direction. Define the approved percentage-error denominator and rounding rule before evaluation. A diagonal strike across rows or a handwritten NA must be explained per point; it is not a validated exclusion for another lot.

Records: QC-WI-053; FORM-007; IMG-014/025; QC-REC-005/007.

Remaining authoritative input: The full WI, pH preparation/measurement method, volume verification conditions and product-specific connector scope require technical confirmation.

## DEC-009 — Feeding tube and gastrostomy inspection

Proposed policy: Treat the photographed Feeding Tube Gastrostomy record as a real physical report. Retain its partly legible document identity without guessing the suffix; use the original master for the full number.

Execution: Record Fr size, material (PVC/silicone as applicable), lot, color and tube variant. Check package, clarity, irregularities, length/ID/OD, radiopaque line, balloon, valve, port cap and retention ring in the printed sequence. Separate ballooned gastrostomy work from a non-balloon feeding tube; document NA applicability rather than copying the same checklist unchanged.

Acceptance and exceptions: Record actual dimensions in units with instrument identity. For retention/leak checks, obtain the specified inflation medium, volume, time and limits; do not infer these from a checked box. Resolve the photographed difference between Sample Size and the quantity checked in remarks. Keep the original report and the clarification linked.

Records: QC-WI-054; FORM-008; IMG-079; QC-REC-003/005/007.

Remaining authoritative input: The exact form suffix, device drawing and balloon/valve test conditions remain source-specific inputs.

## DEC-010 — Nelaton catheter inspection and mixed variants

Proposed policy: Use the photographed F-823-T48 record subject to identity confirmation from the original. Record whether the device is a non-balloon catheter and document connector variants within the received lot.

Execution: Inspect lubrication applicability, clarity, tip, eyes, OD/ID, length, connector color, connection/gluing, scale, labels, pouch and sterile/bulk presentation. Capture each design/color group separately. The report comments identify different connector designs and a pullout/leakage concern; preserve those details even where the overall box says Accepted.

Acceptance and exceptions: For the pullout or leakage point, identify sample, failure mode, fixture, load/pressure, duration and source limit under the product method. Do not add balloon checks to a non-balloon catheter merely because a different tube family has them. Require the reviewer to reconcile unfavorable remarks, group counts and lot disposition.

Records: QC-WI-055; FORM-009; IMG-077/078/080; QC-REC-005/007/008.

Remaining authoritative input: Original form identity, actual variant scope and the approved connection-strength/leak method require verification.

## DEC-011 — Nasal cannula inspection

Proposed policy: Use F-823-T9 Rev3 (01.02.2024). Record patient size, straight/other configuration, item code and the intended oxygen-flow class from the approved product source.

Execution: Follow the 16 physical points: packing, appearance, nostril assembly, irregularities, type/size, tip holes, pilot/nostril assembly, thin tubing, connector, main tube, dimensions, connector condition/dimensions/gluing, logo and sterile/bulk condition. Measure each component with its own dimension identifier; do not combine several OD values into one field.

Acceptance and exceptions: Where the physical report quotes drawing dimensions in remarks, retain them with that item code and source reference. Distinguish measured values from tolerances. The photographed re-evaluation notes missing manufacturing/expiry label information; carry it into the disposition review. Flow and oxygen-service tests require the qualified method and apparatus.

Records: QC-WI-056; FORM-010; IMG-076; QC-REC-005/007.

Remaining authoritative input: The full referenced product source, intended flow class and functional test conditions are required before adding quantitative flow acceptance.

## DEC-012 — Cleaning-brush inspection

Proposed policy: Use F-823-T147 Rev0 (13.09.2023) and retrieve TF-M73-PS Rev0 or its controlled successor for the exact brush design.

Execution: Inspect the 12 form points: packing, clarity, twisted wire, wire dimensions, protector, bristle condition/dimensions, handle, cover, label, logo and sterile/bulk condition. Record single/double-ended design. Measure total length, wire/protector diameters and bristle length/diameter as separate characteristics, each tied to the drawing.

Acceptance and exceptions: The record contains dimensions and tolerances for a particular 500 mm design; use it as a traceable historical example, not a specification for every brush. Define bristle-retention load, fixture and duration through design evidence. Where protector or cover is absent by design, document NA against the drawing. Any loose wire/bristle or sharp end requires containment and review.

Records: QC-WI-057; FORM-011; IMG-017/021; QC-REC-005/007.

Remaining authoritative input: TF-M73-PS itself and validated retention/function limits are still required; the report references it but does not reproduce the full method.

## DEC-013 — Clamp inspection method

Proposed policy: Create a product-specific clamp inspection specification before controlled acceptance. No clamp form has been positively identified in the reviewed images; retain that source gap rather than assign another product form to it.

Execution: The proposed inspection sequence is identity/material and size; package; moulding/flash; jaw alignment; hinge/pivot; latch engagement/release; intended tubing fit; occlusion; repeated operation where required; damage after operation; marking and final condition. Record the intended tube material and OD/wall range, since occlusion of one tube is not evidence for all tubes.

Acceptance and exceptions: For a validated functional test, specify conditioned tubing, medium, upstream/downstream pressure, closing position/force, duration, leak detection and reopening assessment from the design source. Record actual observations and maintain uncertain product on HOLD. These variables are an executable protocol structure but no unapproved load, cycle count or pressure is invented.

Records: QC-WI-058; proposed QC-REC-007 product inspection continuation sheet; DEC-013.

Remaining authoritative input: Original clamp form, intended use, drawing and validated functional limits remain missing.

## DEC-014 — Safety-goggle inspection

Proposed policy: Use the supplied safety-goggle record as the physical checklist; verify the full document suffix on the original master. Preserve the non-sterile product label and exact model rather than infer clinical or impact protection from appearance.

Execution: Inspect package, visual clarity, color, frame/PVC edges, ventilation openings, lens condition and fit, strap holder, elastic strap, strap attachment, logo and sterile/bulk statement. The supplied report notes loose fittings in some pieces; retain the defect count and segregation/rework details and reconcile the balance of acceptable stock.

Acceptance and exceptions: Visual inspection can establish observed scratches, damage, flash and loose assembly. Optical performance, impact and splash claims require the corresponding qualified method and apparatus. Record the applicable protection claim before deciding whether a routine incoming check or type-test evidence applies.

Records: QC-WI-059; FORM-013; IMG-015/024; QC-REC-005/007/008.

Remaining authoritative input: Full form identity, approved drawing and claim-specific test evidence remain technical inputs.

## DEC-015 — Endotracheal tube inspection

Proposed policy: Use F-823-T30 Rev4 (23.04.2024) and the exact oral/nasal, cuffed/uncuffed and reinforced/unreinforced product specification.

Execution: Execute the printed 23 points in order: package, tube, bevelled tip, connector fit/status, cuff type, tube formation, angle, OD/ID, length, inflation tube/status/gluing, cuff, Murphy eye, X-ray line, graduations, depth guide, pilot-balloon printing/leak, balloon leak, reinforcement, logo and sterile/bulk. Mark variant-inapplicable points with a documented reason.

Acceptance and exceptions: Measure tube dimensions without distorting the lumen. Record cuff/pilot-balloon conditions and the actual source method for inflation/leak checks. Do not inflate using a guessed pressure or volume. Preserve remarks linking the tested article to the drawing revision; a size written on one record does not set tolerances for other sizes.

Records: QC-WI-060; FORM-014; IMG-016/036; QC-REC-005/007.

Remaining authoritative input: Actual drawing/WI, cuff/balloon test setup and applicability of the current external method require the airway-product owner.

## DEC-016 — Document, change and signature policy

Proposed policy: Proposed policy: an author prepares a controlled revision; a technically competent reviewer assesses its content; the authorized approver signs the exact reviewed revision and meaning. Document Control then records a separately authorized effective date after training/distribution prerequisites. An entered name, photograph or scanned signature is retained as source evidence and does not become a newly executed electronic signature.

Execution: Bind the decision to document number/revision, file digest, actor, role/scope, decision meaning, timestamp and authentication evidence. Preserve rejection/return reasons. Reopening creates a new review cycle without erasing the signed predecessor. A changed file invalidates the pending approval binding and requires renewed review.

Acceptance and exceptions: Proposed separation: author cannot give their own final approval; reviewers may request corrections but may not replace raw evidence; only an approved release/distribution role may make a revision effective. Maintain current application denial for generic approval while RD-019/PD-32 are unresolved. Adopt this policy through the real owner/QMS process before implementation.

Records: QC-REC-009 review, approval and effectivity record; QC-SOP-001/011/022/023.

Remaining authoritative input: Named signatories, delegation limits, effective-date authority and applicable reauthentication ceremony still need actual approval; the draft does not grant permissions.

## DEC-017 — Rejection, physical disposition and metrics

Proposed policy: Use F-7-5-7-8 Rev4 (21.09.2026) as the physical rejection record. Preserve Department, item/lot/unit/quantity, reason, prepared/checked/reviewed roles, disposition and approval sections separately.

Execution: For production-origin stock, route to the actual required Production, QC and Director authorities. For warehouse-origin stock, the supplied record explicitly notes that Production signature is not required; record the documented exception and its scope for that record. Do not map Production Manager to the application SUPERVISOR merely because both appear first in an approval chain.

Acceptance and exceptions: QC entry records facts and prepares the report; actual approval confirmations are recorded only by an authorized confirming actor with source evidence. Rework or transfer needs a separate completed movement record and quantity reconciliation. Report the implemented reject/good ×100 metric under that explicit label; zero good denominator is undefined, not zero rejection. Any change to reject/total requires an approved definition and code change.

Records: QC-WI-022/023/024/025; FORM-015; IMG-066; QC-REC-008/010.

Remaining authoritative input: Crosswalk of physical positions to digital roles and warehouse exception policy require owner approval. Historical paper signatures are not copied into new digital ceremonies.

## DEC-018 — Finding to CAPA lifecycle

Proposed policy: Proposed quality policy: a Finding records observed evidence and containment. An NCR identifies the unmet requirement and affected scope. RCA tests causal explanations against evidence. CAPA assigns actions to supported causes and defines verification and effectiveness before closure.

Execution: At NCR creation, link the finding, source requirement, product/lot/process, immediate containment, risk assessment and owner. At RCA review, distinguish verified causes from hypotheses and include evidence that could disprove the cause. At CAPA planning, assign each action, due date, completion evidence, verifier and effectiveness measure with a justified observation period.

Acceptance and exceptions: An action marked complete is not proof of effectiveness. Record the planned versus actual observation window and denominator of opportunities or recurrence. Preserve the source P-04 exceptional Supervisor closure with its reason, reauthentication/signature and residual-risk follow-up; do not label incomplete or ineffective work effective merely because closure is permitted.

Records: QC-REC-011 quality investigation and effectiveness record; QC-SOP-017/018.

Remaining authoritative input: Product/process-specific risk criteria and effectiveness period require QMS approval. No invented universal duration or threshold is imposed.

## DEC-019 — Training, custody and movement

Proposed policy: Proposed physical policy: authorize a person for a named procedure revision and equipment/product scope only after instruction, demonstrated practice and observed competence. Maintain paper records until an approved digital module exists.

Execution: The assessor observes identity checks, correct source selection, a normal task, a deliberate exception, raw-data recording and safe handoff. Record each result and restriction. Reassess following a significant method/equipment change, an observed competence failure or the approved review schedule. Training attendance alone is insufficient.

Acceptance and exceptions: For custody, record sample ID, parent lot, selection time, selector, quantity, condition, container/seal and every transfer with both parties and time. For movement, reconcile opening quantity, received/transferred, tested/destroyed, reworked, scrapped and closing balance in one unit. Discrepancies stop handoff until explained; maintain quarantine identity through transport.

Records: QC-REC-003, QC-REC-010 movement, QC-REC-012 competency; QC-SOP-002/007/016.

Remaining authoritative input: These complete manual procedures are proposed for adoption. Digital custody, competency and physical movement ledgers remain separate implementation work.

## DEC-020 — Retention and controlled storage

Proposed policy: Proposed policy: classify original paper, scanned copy, raw instrument file, derived report, audit trail and signature evidence separately. Preserve the original relationship, version, hash and custodian. Do not destroy originals because a scan exists.

Execution: For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Acceptance and exceptions: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Records: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

Remaining authoritative input: Actual retention periods, scanner/provider configuration and storage durability need owner/legal/IT evidence.

## DEC-021 — Database and file recovery protocol

Proposed policy: Proposed recovery scope covers the database, linked file bytes, configuration references, encryption/key-recovery dependencies and release/schema identity as a consistent recovery set. A backup status row is not that set.

Execution: For each exercise, obtain explicit isolated-target authorization and the provider runbook. Record source artifact/time, database and file manifest, checksums, target identity, restore start/end and service verification times. Restore only into the approved isolated destination, check relational integrity and attachment readability, and reconcile a representative cross-domain record set before sign-off.

Acceptance and exceptions: Measure achieved RPO as the difference between the incident/reference time and latest recoverable committed data; measure RTO from the defined interruption start to verified service recovery. Record the start/end definitions before the exercise. Compare with owner-approved objectives; no objective is inferred from a successful local copy. Production restore requires separate authority.

Records: QC-REC-014 recovery exercise; QC-WI-047/048/065.

Remaining authoritative input: Provider artifacts, approved RPO/RTO targets, durable file storage and a measured isolated restore remain external evidence, not document-authoring deliverables.

## DEC-022 — Outbox worker and operator alert protocol

Proposed policy: Proposed operational contract: each accepted business event has a correlation identity, durable outbox state and a separately evidenced delivery outcome. Delivery retries must not repeat the business mutation.

Execution: Define the deployed worker, queue, claim/lease, retry/backoff, terminal-failure handling, scheduler and heartbeat. Record exporter destination, redaction and authorized alert receivers. Derive alert thresholds from approved service objectives and measured queue behavior. Under separate test authorization, enqueue a non-sensitive test event, track claim and attempt, obtain provider receipt and receiver acknowledgment, then prove deduplication/retry behavior.

Acceptance and exceptions: A missing heartbeat, growing oldest-event age or terminal failure creates an incident under the approved threshold. A zero queue or no-op exporter is not proof of delivery. Retain raw timestamps and provider IDs; operator acknowledgment records who acted and when. No live message is sent by this document package.

Records: QC-REC-015 worker, telemetry and alert exercise; QC-WI-064.

Remaining authoritative input: Worker deployment, real exporter, thresholds/receivers and actual provider delivery evidence remain operational inputs.

## DEC-023 — AI advisory data handling

Proposed policy: Proposed policy: AI provides advisory text only. It cannot approve QC records, sign, release material, alter scientific criteria or replace a reviewer. Keep external processing disabled until provider and data use are approved.

Execution: The owner and privacy/security reviewer document provider/model, geography, retention/training terms, permitted data classes, credentials custody, incident path and audit metadata. Minimize each prompt; remove personal identifiers and signatures. Actual company photos may contain names, supplier information and production details; their presence in this repository is not consent to external upload.

Acceptance and exceptions: Each authorized request records purpose, policy version, allowed content class, consent and response correlation. Verify recommendations against the controlled sources and record the human conclusion. Deny when the policy/provider is missing, consent is absent or the data exceeds scope. Record provider failure without substituting fabricated advice.

Records: QC-REC-016 AI request assessment; QC-SOP-027; current AI-PROVIDERS source.

Remaining authoritative input: Provider choice, processing terms and authorized data scope need actual approval. This pack does not enable a provider or send evidence images externally.

## DEC-024 — Release and human UAT evidence

Proposed policy: Proposed release record binds each of the nineteen gates to the exact candidate, applicable route/process, evidence producer, artifact/hash, reviewer and result. Applicability exclusions require a reason and an authorized decision.

Execution: Freeze source SHA, dirty fingerprint, build/runtime identity and migration state. Define real UAT roles and scenarios, including receiving, inspection/lab review, denial, stale version, uncertain submission, reports and recovery intent. Participants execute with their own authorized accounts and record observed outcome, evidence and defects. Preserve failed and blocked cases.

Acceptance and exceptions: A verification lead checks candidate binding and unresolved defects; the authorized acceptor signs only real participant evidence. A source test, authored script or planned scenario cannot be substituted for the session. If the candidate changes, assess affected evidence and rebind/rerun as required. Gate PASS does not itself execute release or deployment.

Records: QC-REC-017 release gate and UAT session; QC-SOP-030; route-coverage register.

Remaining authoritative input: Named acceptance authority, signed applicability and real UAT sessions remain external human actions.

## DEC-025 — Performance measurement contract

Proposed policy: Proposed protocol defines each operation, role, data volume, device, browser, network and cold/warm condition before measuring. Budgets are owner decisions and remain separate from raw measurements.

Execution: Capture request/query counts, payload size and the relevant timing metric with clock/method details. For p95, retain all raw samples, sample count and percentile method; do not report a percentile from one observation. Compare before/after with equivalent data and conditions. Include errors and timeouts in the stated analysis rather than silently dropping them.

Acceptance and exceptions: For interactive pages, define the measured user interaction and tooling; page load time is not INP. Record server and browser segments separately. If a budget is absent, report measured values and request the acceptance decision without claiming a pass. A local loopback benchmark does not establish provider latency.

Records: QC-REC-018 performance plan and measurements; QC-WI-061.

Remaining authoritative input: Approved budgets, representative environment and raw runtime measurements remain required for performance acceptance.

## DEC-026 — Invalid test, retest and rejection

Proposed policy: Proposed rule: classify a run as invalid only for a documented assignable test-system or procedure failure, not merely because its result is unfavorable. Preserve the original result and investigation.

Execution: Contain affected material, identify all runs since the last valid control and record the reason for invalidation or retest. The method owner approves sample selection, repeat count, conditions and the rule for combining or separately reporting results before retesting. Link the new run to the original and preserve the operator, time, equipment and source revisions.

Acceptance and exceptions: A confirmed product failure proceeds to the authorized nonconformance/disposition process. A passing retest does not erase a failing result. Ambiguous results remain HOLD/further evaluation until reviewed. The current digital lab reject path remains policy-blocked where PD-38 authority is not established; no alternate route is proposed.

Records: QC-REC-019 invalidation and retest authorization; QC-SOP-012; QC-WI-020/042.

Remaining authoritative input: Product-specific repeat/aggregation rules and final lab rejection authority require method/QMS approval.

## DEC-027 — HOLD investigation and physical disposition

Proposed policy: Proposed HOLD record identifies the exact material quantity/location, reason, initiating record, custodian and permitted handling. Apply a physical status label and prevent uncontrolled issue or mixing.

Execution: Investigate the reason and assemble the receiving, inspection/lab, equipment, source and discrepancy evidence. The authorized disposition owner decides continued HOLD, additional work, rejection, rework or release eligibility under an approved path. Record the decision and its conditions before moving material. Warehouse verifies identity and quantity against the signed disposition.

Acceptance and exceptions: The current receiving state machine has no general outgoing HOLD transition. A proposed REMOVE_HOLD workflow must be implemented and verified under change control before digital use; do not edit the database or substitute a new receiving record. Physical release evidence and digital state must be reconciled, and no stale label is reused.

Records: QC-REC-020 HOLD and disposition; QC-SOP-006; QC-WI-004/005.

Remaining authoritative input: Actual HOLD recovery authority and digital transition implementation remain required. The procedure itself does not unlock the record.

## DEC-028 — Source description reconciliation

Proposed policy: The process owner confirmed on 2026-10-04 that the supplied documents, forms and reports are official records used physically. Record that attestation as the source basis for documenting the physical workflow. Earlier blanket descriptions implying that the forms were absent are historical.

Execution: For each form, preserve company number, revision, printed date, image ID/hash, observed fields and workflow context. For a conflicting narrative, state the observed evidence and the newer authority source. Distinguish paper availability from digital template integration, and historical signer evidence from a new digital signature.

Acceptance and exceptions: Closure rule for the source-availability description: all 84 files are indexed, readable derivatives exist, and the official physical-use attestation is recorded. Remaining incomplete form suffixes and scientific/effectivity conflicts remain with their specific decisions. Do not mark those technically resolved by the general attestation.

Records: Official_Physical_Records_Basis.pdf; form-register.pdf; image-register.pdf; user attestation 2026-10-04.

Remaining authoritative input: Documentary source-availability statement can be closed. Digital parity, formal source registration and individual technical conflicts remain separately reviewable.

## Verified external scope references

ISO 20695:2020, enteral feeding systems: https://www.iso.org/standard/68853.html — catalog excludes oral syringes. ISO 80369-20:2024, common connector test methods: https://www.iso.org/standard/82712.html — catalog confirms edition and scope, not licensed method details. ATEQ general pressure-decay sequence: https://ateq.co.uk/faq-items/how-does-pressure-decay-testing-work/ — general method overview, not identification of the company instrument. Accessed 2026-10-04.
