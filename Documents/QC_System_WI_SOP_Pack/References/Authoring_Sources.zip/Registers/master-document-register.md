# Master document register

D0.2 | DRAFT FOR REVIEW | 2026-10-04

## QC-SOP-001

title: Document control and approval of this pack

revision: D0.2

status: DRAFT FOR REVIEW

owner: Document Control; QMS; QC Manager

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-001.md

content_sha256: 619a5cef53502aae99e2dc43caf7250e2e3ca3339d9124dcb9a4d2e3c2cd8d04

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-001.pdf

## QC-SOP-002

title: Personnel training and competency

revision: D0.2

status: DRAFT FOR REVIEW

owner: QMS; QC Supervisor; Technical specialists

implementation: PROPOSED MANUAL PROCEDURE — DIGITAL TRAINING TRACKING REQUIRED

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-002.md

content_sha256: eab843f0fcda3ba23b90e0f0465d6b1e5f3c261ea7d1a19feeabeee5eeb5ef4a

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-002.pdf

## QC-SOP-003

title: Account, permission and session management

revision: D0.2

status: DRAFT FOR REVIEW

owner: Named System Owner; Authorized identity administrator

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-003.md

content_sha256: 24a6f426e40390d4932a0c7f6ab001f0ff62145dc7083dbe64fcea99b015222d

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-003.pdf

## QC-SOP-004

title: Supplier receipt and purchase-order reconciliation

revision: D0.2

status: DRAFT FOR REVIEW

owner: Warehouse; QC entry operator; Purchasing; QC Supervisor

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-004.md

content_sha256: f8238fbedd919fe0097e5223ffea0cea6986e680d6f9f6cbb4a91bf681f7d1c9

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-004.pdf

## QC-SOP-005

title: Receiving corrections and record conflicts

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC entry operator; QC Supervisor; Record owner

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-005.md

content_sha256: 3e82743348a988c1679c2952562928fdda58a650d0711f6f0771128b6d57d14a

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-005.pdf

## QC-SOP-006

title: Quarantine, HOLD and release control

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC Supervisor; QCM; Authorized release actor; Warehouse

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-006.md

content_sha256: 1aa88b8199f946e4979c97af07bb1551631bc0add388011ef19db7b9bf71a912

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-006.pdf

## QC-SOP-007

title: Sampling and sample custody

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC Supervisor; Sampling operator; Laboratory

implementation: PROPOSED MANUAL PROCEDURE — DIGITAL CUSTODY AND PLAN CONTROL REQUIRED

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-007.md

content_sha256: 59fea27916d047d1510677f84cb23a88e9396c64d728c48e7c2cdf19cacfa081

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-007.pdf

## QC-SOP-008

title: Incoming and product inspection

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC operator; Supervisor; QCM; Product specialist

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-008.md

content_sha256: 830b374b1a17f6c5f99e83c99587c8211fc8b20263d62ac3bffdcf222dd7891e

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-008.pdf

## QC-SOP-009

title: Laboratory method selection and execution

revision: D0.2

status: DRAFT FOR REVIEW

owner: Laboratory operator; Technical method owner; Supervisor; QCM

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-009.md

content_sha256: 0ba85ff3d1dbfa449ec2a78c2103578e8d44f677136ee456298767b9b296e08a

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-009.pdf

## QC-SOP-010

title: Raw data, instrument files and calculation control

revision: D0.2

status: DRAFT FOR REVIEW

owner: Laboratory; QC Supervisor; Document Control; IT

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-010.md

content_sha256: 53304376d5714e4f967e4d008e7cd558a3098d62c8cb1d4a32125336cd24aa2a

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-010.pdf

## QC-SOP-011

title: Review, approval and electronic signatures

revision: D0.2

status: DRAFT FOR REVIEW

owner: Supervisor; QCM; Authorized domain approver; QMS

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-011.md

content_sha256: aa018b75131d56447e5dae417c5b98c0bcf2a733491c225689fd0120eeb0fc2c

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-011.pdf

## QC-SOP-012

title: Invalid work, retesting and disputed results

revision: D0.2

status: DRAFT FOR REVIEW

owner: Technical method owner; Supervisor; QCM

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-012.md

content_sha256: 767980cecd579b925564107418f5bdc9b3333b14721d9343143465cb28c83885

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-012.pdf

## QC-SOP-013

title: Laboratory report-form transcription

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC entry operator; Laboratory; Document Control

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-013.md

content_sha256: 7294a447d25cca4d92a759b50007a676547e0ac289961111eebae46ea34b6e2c

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-013.pdf

## QC-SOP-014

title: Rejected material and rejection slips

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC entry operator; Authorized confirmation actors; Warehouse; QMS

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-014.md

content_sha256: 1a42f0e3d64e2bd3e86cf274a7d47e993653be541d77ade04ff77b35c1d3e5a8

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-014.pdf

## QC-SOP-015

title: Daily production and rejection reporting

revision: D0.2

status: DRAFT FOR REVIEW

owner: Production; QC entry operator; Authorized finalizer; QMS

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-015.md

content_sha256: 0ba98aeb451d92f25831c399e28e853d251764ad55ea09ffa9c7699aa11e7d67

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-015.pdf

## QC-SOP-016

title: Internal transfer, rework and physical disposition

revision: D0.2

status: DRAFT FOR REVIEW

owner: Warehouse; Production; QC Supervisor; QMS

implementation: PROPOSED MANUAL PROCEDURE — DIGITAL MOVEMENT LEDGER REQUIRED

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-016.md

content_sha256: 8422c9709f3ba085cbdcd3dbd3b22e9b07ecffc95aa1eff38c82c4c49d6a003c

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-016.pdf

## QC-SOP-017

title: Findings and nonconformance control

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC; Supervisor; Quality process owner

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-017.md

content_sha256: e4cd5719e1264739c15b75becd8bda3211de37a19e6aa79f4358a96b64dc2fac

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-017.pdf

## QC-SOP-018

title: Root cause and CAPA lifecycle

revision: D0.2

status: DRAFT FOR REVIEW

owner: Quality process owner; Investigator; Supervisor; QMS

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-018.md

content_sha256: 1f5b914f11488276471ca28dbbc1f0df8da452060caafd462e2e5f65f32eba39

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-018.pdf

## QC-SOP-019

title: Task assignment and work handoff

revision: D0.2

status: DRAFT FOR REVIEW

owner: Task owner; Assignee; Supervisor

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-019.md

content_sha256: 3418b1e59c5512e7d545d8ec642494e296182232c55ec5d1f6d7ed837d36ae4f

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-019.pdf

## QC-SOP-020

title: Equipment registration and fitness for use

revision: D0.2

status: DRAFT FOR REVIEW

owner: Equipment owner; Laboratory; Asset administrator

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-020.md

content_sha256: e4262ecefd9081706a19d9e55df35335aa931460fe849be68c7e14df4bc11b6f

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-020.pdf

## QC-SOP-021

title: Calibration and maintenance control

revision: D0.2

status: DRAFT FOR REVIEW

owner: Metrology; Equipment owner; Maintenance; QMS

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-021.md

content_sha256: d58fa50a6847f2f612fa325162f473f7338dbacd7ec6292935be8682ece9a515

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-021.pdf

## QC-SOP-022

title: Templates, controlled documents and revisions

revision: D0.2

status: DRAFT FOR REVIEW

owner: Document Control; Template technical owner; Supervisor; QCM

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-022.md

content_sha256: 26640a6e540c528d33802dd965c00f652998755bcb6e752a680894ecad4d84e4

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-022.pdf

## QC-SOP-023

title: Controlled change requests

revision: D0.2

status: DRAFT FOR REVIEW

owner: Change requester; Assigned reviewer; QMS; Named owner

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-023.md

content_sha256: 4d303680b4bb20bb4a77366847379c0f7c0dcc4da7027f7766d5cac4eaa8fde8

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-023.pdf

## QC-SOP-024

title: Records, audit, retention and corrections

revision: D0.2

status: DRAFT FOR REVIEW

owner: QMS; Document Control; IT; Record owners

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-024.md

content_sha256: 5a37c8a91f125d0f411e0452531f1f16723881630f1c247469fa15bdd1245c91

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-024.pdf

## QC-SOP-025

title: Reports, provenance and controlled exports

revision: D0.2

status: DRAFT FOR REVIEW

owner: Report owner; QC/QMS; Authorized reader

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-025.md

content_sha256: 008d603452ebf8379cb2c81b558178bc2fe3a6bdbbf76b7b20ef63e6dd357898

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-025.pdf

## QC-SOP-026

title: Worklists, search, dashboards and notifications

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized system user; Work owner; Support

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-026.md

content_sha256: 50d73a56d6cc4574ad360fec4d8aa49baa40ba2d3e69082ed4144fa35dea5f1d

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-026.pdf

## QC-SOP-027

title: AI advisory governance

revision: D0.2

status: DRAFT FOR REVIEW

owner: Named owner; QMS; Authorized advisory user; Privacy/security reviewer

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-027.md

content_sha256: 3663067775b2c0f0e826f103fe76d628abf98944032cdb056708f31c83c51da1

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-027.pdf

## QC-SOP-028

title: Support, security incidents and service interruptions

revision: D0.2

status: DRAFT FOR REVIEW

owner: Support; Named owner; Security; QC/QMS

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-028.md

content_sha256: df1c6dcd910cc81635493e6b9b0d24366b2f6d55851773c7bb9841730f88710b

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-028.pdf

## QC-SOP-029

title: Backup, restore intent and disaster recovery

revision: D0.2

status: DRAFT FOR REVIEW

owner: Named owner; IT recovery operator; QMS; Provider

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-029.md

content_sha256: 25272004b3881e96a7af6c672228463058d547612b81b83ec05ee94b4e83e2d0

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-029.pdf

## QC-SOP-030

title: Release governance, verification and human UAT

revision: D0.2

status: DRAFT FOR REVIEW

owner: Named owner; Engineering; Verification lead; QMS; Human UAT participants

implementation: SOURCE-ALIGNED DRAFT

parent: None

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-030.md

content_sha256: 94ef8ce577b18a5f57ec00db0229650579d2ec7bd877ead2a0503e12b1434548

hash_scope: Archived Markdown UTF-8 bytes

delivery: SOPs/QC-SOP-030.pdf

## QC-WI-001

title: Receive and reconcile a supplier delivery

revision: D0.2

status: DRAFT FOR REVIEW

owner: Warehouse; QC entry operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-004

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-001.md

content_sha256: d8abde7a2e1068542a2a788325aee94bd9f840a5d7a1d7fb50a3b3cbce157746

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-001.docx

## QC-WI-002

title: Open and save a receiving correction

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized QC entry operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-005

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-002.md

content_sha256: 39801e93782f86856b4fb184cf06aaedaf82360d0d1528b4c84a2cc970926a29

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-002.docx

## QC-WI-003

title: Prepare receiving for inspection

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized receiving/inspection actor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-006

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-003.md

content_sha256: f47668db4a3a3cbd3af1a0b469abdfc7ddacf0b65c33be0bc4808b9b46f93186

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-003.docx

## QC-WI-004

title: Place material on HOLD and preserve containment

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized HOLD actor; Warehouse

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-006

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-004.md

content_sha256: aa50dbeb44d59dedbfed33c19222b5f8ec3ba3bff16697f171e96ef0dfc5ad8a

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-004.docx

## QC-WI-005

title: Perform an authorized receiving release

revision: D0.2

status: DRAFT FOR REVIEW

owner: P-05 authorized release actor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-006

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-005.md

content_sha256: 09130681d03ecdd712abe9f86c145f168b40c0804b05a55b34cabf07acf5520b

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-005.docx

## QC-WI-006

title: Check a missing, denied, empty or unavailable source

revision: D0.2

status: DRAFT FOR REVIEW

owner: Operator; Authorized support

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-028

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-006.md

content_sha256: 0b3ce76e395bf6774cdd297264b1b04856f0c673de264521aa56efb44b171857

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-006.docx

## QC-WI-007

title: Reconcile a conflict between two record versions

revision: D0.2

status: DRAFT FOR REVIEW

owner: Record author; Record owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-005

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-007.md

content_sha256: 16cb48ce76404cc7746b4146610a01c030389cf419f30fe6d9bca6cf133ab658

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-007.docx

## QC-WI-008

title: Resolve an unknown result after submission

revision: D0.2

status: DRAFT FOR REVIEW

owner: Operator; Support

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-028

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-008.md

content_sha256: 74a75c4577aea7d6ecfcdc55f54048e2d932d553fcf59892b51f24fb91945b9c

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-008.docx

## QC-WI-009

title: Select and identify samples from a lot

revision: D0.2

status: DRAFT FOR REVIEW

owner: Qualified sampling operator

implementation: PROPOSED MANUAL PROCEDURE

parent: QC-SOP-007

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-009.md

content_sha256: cda79e9ee3a48b7b5b36bae65628d406d9f8f019624b78384450906c6dabdef4

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-009.docx

## QC-WI-010

title: Receive and hand over laboratory samples

revision: D0.2

status: DRAFT FOR REVIEW

owner: Sampler; Laboratory receiver

implementation: PROPOSED MANUAL PROCEDURE

parent: QC-SOP-007

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-010.md

content_sha256: eeaab7488ec7f0307c28890388fa06ce05a0d3b605f538146d8bf22a2b5daade

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-010.docx

## QC-WI-011

title: Execute an inspection record

revision: D0.2

status: DRAFT FOR REVIEW

owner: Qualified QC executor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-011.md

content_sha256: 91ae1ea6d43b4f662a0b9201f24d382391461dd56ea483d101a43c3552bdf8c9

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-011.docx

## QC-WI-012

title: Review an inspection or lab report at stage 1

revision: D0.2

status: DRAFT FOR REVIEW

owner: Supervisor; Explicitly authorized named owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-011

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-012.md

content_sha256: 056f3ecdead30159a282e80aa40fa36b144d36acf43e856b6e96cd0e567540a1

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-012.docx

## QC-WI-013

title: Complete QCM final approval with signature binding

revision: D0.2

status: DRAFT FOR REVIEW

owner: QCM; Explicitly authorized named owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-011

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-013.md

content_sha256: 2b9378ebd6ed50b50ab58cd679886cf05712ba651eee73796f64f567f1ca1058

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-013.docx

## QC-WI-014

title: Correct returned work and reopen approved work

revision: D0.2

status: DRAFT FOR REVIEW

owner: Author; Authorized reopen actor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-011

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-014.md

content_sha256: ad54ed28c0493663a5808d47d217a068e088b61fd5dcf73a6e43bbc7403f95ae

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-014.docx

## QC-WI-015

title: Create a laboratory test with an approved template

revision: D0.2

status: DRAFT FOR REVIEW

owner: Qualified lab entry operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-009

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-015.md

content_sha256: e791a10f1ac8fdb77a3bffe20fe11990ddf2861e39303a9971c4214e811df88c

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-015.docx

## QC-WI-016

title: Record a laboratory run and equipment context

revision: D0.2

status: DRAFT FOR REVIEW

owner: Qualified laboratory operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-009

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-016.md

content_sha256: 5ca7e293484af9573ae1eaede9c070b68eab6b86a9411876eea47a406c7a968e

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-016.docx

## QC-WI-017

title: Enter typed laboratory measurements

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized laboratory operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-009

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-017.md

content_sha256: f583fad4d9fddd4041abe35b8dd0fff2c97c24e53a046c10940d69e9579e830f

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-017.docx

## QC-WI-018

title: Attach and verify raw laboratory evidence

revision: D0.2

status: DRAFT FOR REVIEW

owner: Laboratory; Authorized evidence uploader

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-010

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-018.md

content_sha256: 1ac96340c776e1bbc897c4f459720f49a0098ebf6c3e9a7342cbe41af32b1643

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-018.docx

## QC-WI-019

title: Check a calculated result before review

revision: D0.2

status: DRAFT FOR REVIEW

owner: Technical reviewer; Laboratory

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-010

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-019.md

content_sha256: 7805d2bf111b157865c80263ca97122c4b218961190729f12fa7f462fae583c4

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-019.docx

## QC-WI-020

title: Authorize and create a traceable retest

revision: D0.2

status: DRAFT FOR REVIEW

owner: Technical method owner; Authorized lab actor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-012

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-020.md

content_sha256: c4188479083f6215aa150c33fa6f348206c67641a32304a62255d263e92bc7b5

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-020.docx

## QC-WI-021

title: Transcribe a Pressure Decay or Subatmospheric form

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC entry operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-013

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-021.md

content_sha256: ba2fdb40a97af0215e1b48eb4985602d72bee678da8627b1ad5cbed63916163c

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-021.docx

## QC-WI-022

title: Create and submit a rejection issue slip

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC entry operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-014

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-022.md

content_sha256: dfed88668c6f8aae4a07914db7caa9331f2998b80e26625739e3618727211143

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-022.docx

## QC-WI-023

title: Record authorized rejection approval confirmations

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized checkpoint actor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-014

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-023.md

content_sha256: 0eb8f09a4bf62bfd985b0732112003680c3c637e9166d551acc37cef24fbe4e7

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-023.docx

## QC-WI-024

title: Enter a daily production/rejection report

revision: D0.2

status: DRAFT FOR REVIEW

owner: Production; QC entry operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-015

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-024.md

content_sha256: d87dd81187408c963fc14ff43758b8c74a3d2a3f3164c32109badded887f9d13

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-024.docx

## QC-WI-025

title: Carry out an approved internal transfer or rework handoff

revision: D0.2

status: DRAFT FOR REVIEW

owner: Warehouse; Production; QC

implementation: PROPOSED MANUAL PROCEDURE

parent: QC-SOP-016

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-025.md

content_sha256: a64005f822261626c00115fc07058e7a9f7db8581e598b425a2df03d26ca1e9e

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-025.docx

## QC-WI-026

title: Create a factual Finding

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC entry operator

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-017

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-026.md

content_sha256: 1fc9a160f3368d8dd126ba4cff9a724cc05d04a1f764f671d0cde5bcdfa6abed

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-026.docx

## QC-WI-027

title: Create an NCR linked to persisted evidence

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized QC entry operator; Quality owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-017

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-027.md

content_sha256: 4497709bf3a4fbcb17a3bec864cc0247a0bd24f64bd77ff0264d208d6755144b

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-027.docx

## QC-WI-028

title: Record and review root-cause analysis

revision: D0.2

status: DRAFT FOR REVIEW

owner: Quality investigator; Technical reviewer

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-018

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-028.md

content_sha256: 4a38c6605bcdcd91786c550e61f6c9d0de0bd59c936cf4dbf7abe4370a965939

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-028.docx

## QC-WI-029

title: Create and track CAPA actions

revision: D0.2

status: DRAFT FOR REVIEW

owner: QC entry operator; CAPA owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-018

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-029.md

content_sha256: 63c9566b9a411aae66514a2637a88827b348d4eb5b5d8be980a5fcdac54744ed

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-029.docx

## QC-WI-030

title: Verify effectiveness and record controlled CAPA closure

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized verifier; Supervisor close actor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-018

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-030.md

content_sha256: 1ca6d3c4c0052732cb5544ad2c83e11e143776fb5b745b7f7fc69706d506ddcc

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-030.docx

## QC-WI-031

title: Assign, complete and hand over a task

revision: D0.2

status: DRAFT FOR REVIEW

owner: Task creator; Assignee

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-019

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-031.md

content_sha256: 9a594cc71b8e182dece76cabc12b4bdc907dc772ef7405ab00c3448568ba44b8

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-031.docx

## QC-WI-032

title: Register and inspect an equipment asset

revision: D0.2

status: DRAFT FOR REVIEW

owner: Asset entry operator; Equipment owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-020

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-032.md

content_sha256: 6a62ce0a23d2d83ccfe14164e12edb1576d5b2b803a7f6f81771a75efdbea57b

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-032.docx

## QC-WI-033

title: Record and review calibration evidence

revision: D0.2

status: DRAFT FOR REVIEW

owner: Metrology; Authorized calibration actor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-021

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-033.md

content_sha256: bc060e01e59218c087b2b7d33aa81ef373cea3db8d74568f438b3363e1777f32

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-033.docx

## QC-WI-034

title: Record maintenance and return-to-use checks

revision: D0.2

status: DRAFT FOR REVIEW

owner: Maintenance; Equipment owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-021

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-034.md

content_sha256: 02294ee9d30bf695449ba42a73b0c818f6c425a813faf8df89ac044a2f5c10a0

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-034.docx

## QC-WI-035

title: Create or revise a controlled document

revision: D0.2

status: DRAFT FOR REVIEW

owner: Document author; Document Control

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-022

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-035.md

content_sha256: 9bd613c7d9263a76f097ec561ecdd09f626087cef6b7f168f69a4686e38650d9

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-035.docx

## QC-WI-036

title: Save a document draft against its opened version

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized document author

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-022

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-036.md

content_sha256: e65db9acc859077f81d73cd49cb6149788c9628d750f487cdd044b2b73d635d5

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-036.docx

## QC-WI-037

title: Manage an inspection or laboratory template

revision: D0.2

status: DRAFT FOR REVIEW

owner: Supervisor; QCM; Explicit named owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-022

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-037.md

content_sha256: 311c600d6b9faef5d24326eed681d530d2291c8a04972d0b44473d56e0066db2

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-037.docx

## QC-WI-038

title: Create and start review of a change request

revision: D0.2

status: DRAFT FOR REVIEW

owner: Requester; Assigned reviewer

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-023

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-038.md

content_sha256: c98535bb3a9371080e7b066a1bcb4c370395db8f7c886d72545730847ecf3698

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-038.docx

## QC-WI-039

title: Prepare a human training and competency assessment

revision: D0.2

status: DRAFT FOR REVIEW

owner: Trainer; Technical assessor

implementation: PROPOSED MANUAL PROCEDURE

parent: QC-SOP-002

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-039.md

content_sha256: da11fc6cd9609705bff63ef588d0b5957022b0a02b22e31618adb20d08b03cc0

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-039.docx

## QC-WI-040

title: Manage an account or recover a session

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized identity administrator; Account holder

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-003

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-040.md

content_sha256: 2c00edb3caf6abd6cf0b91e480fe353d1542230cac95e8cd9054a9560a2913b4

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-040.docx

## QC-WI-041

title: Respond to instrument failure during a test

revision: D0.2

status: DRAFT FOR REVIEW

owner: Laboratory; Equipment owner; Technical method owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-012

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-041.md

content_sha256: 8710b4d73f2d5591c14b6f67078f9bc07cae1adfeb2f005888532a70de50de03

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-041.docx

## QC-WI-042

title: Investigate a failed review or contradictory result

revision: D0.2

status: DRAFT FOR REVIEW

owner: Supervisor; Technical owner; Author

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-012

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-042.md

content_sha256: 8ab551fa4889b7d9b1b62df9198669950131aa043b98cbed946397f6beda6e9b

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-042.docx

## QC-WI-043

title: Generate and reconcile a report export

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized report reader; Report owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-025

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-043.md

content_sha256: 82f40d2bd6311ff7991fef2a9990fb78c028c87968fa276504061f3e23e02010

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-043.docx

## QC-WI-044

title: Find scoped work and read in-app notifications

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authenticated authorized user

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-026

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-044.md

content_sha256: dfdbe37f35bad5933d3b26a4db5cfeb6143006fc7b0ada11c6d6db9b443b9abc

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-044.docx

## QC-WI-045

title: Make an authorized AI advisory request

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized advisory user

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-027

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-045.md

content_sha256: 28b2f74aac93f35876677f7fd93c307dd16e70ba6068a668c4f88bafbd495644

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-045.docx

## QC-WI-046

title: Register a support incident and inspect owner health

revision: D0.2

status: DRAFT FOR REVIEW

owner: Operator; Authorized support; Named yazeed

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-028

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-046.md

content_sha256: 5938550d97766546035d4d44f9415624f75570332f7abc490755e542bb364b76

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-046.docx

## QC-WI-047

title: Create and verify a PLANNED restore intent

revision: D0.2

status: DRAFT FOR REVIEW

owner: Explicitly authorized drill actor; Named owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-029

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-047.md

content_sha256: e2ad7f1836ee99d89d87a040a899462cef7699161f450eea7b80a581611f1374

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-047.docx

## QC-WI-048

title: Verify an isolated database-and-files recovery

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized recovery operator; Provider; Verification reviewer

implementation: PROPOSED OPERATOR PROCEDURE — PROVIDER RUNBOOK REQUIRED

parent: QC-SOP-029

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-048.md

content_sha256: 3ad55c6e8c29dfdfc65fe9852f0ca07cd92552aca48a8b9a7b60ce17e262db70

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-048.docx

## QC-WI-049

title: Freeze release evidence and conduct real UAT

revision: D0.2

status: DRAFT FOR REVIEW

owner: Engineering; Verification lead; Human UAT participants; QCM/owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-030

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-049.md

content_sha256: 0f3f296bb84cbb50c3313a62747df89b9545f8795e92144bbbb055710be29a06

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-049.docx

## QC-WI-050

title: Pressure Decay connector leakage test — technical review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Leak-test specialist; Metrology; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-009

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-050.md

content_sha256: df563cf122fc998ce13f087a014f689cd46125fce53f7bb23cf86dbf8b601f2c

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-050.docx

## QC-WI-051

title: Subatmospheric Pressure Air Leakage — technical review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Leak-test specialist; Metrology; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-009

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-051.md

content_sha256: 492c7d258292f41d971f6751a8590a2fd342fc9a03bb65eb8faed94343c62a91

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-051.docx

## QC-WI-052

title: Oral medication syringes — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Oral administration product specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-052.md

content_sha256: 1017ca0264dae86f4249bfc068b0d0660d2f8b6c55d1ac9abdaad2abfa47c61f

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-052.docx

## QC-WI-053

title: Syringes — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Syringe product specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-053.md

content_sha256: da404d12b4775013068b2bac12f0fd6cecff2ab4ff20210e524347cd6befe34d

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-053.docx

## QC-WI-054

title: Feeding tubes — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Enteral product specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-054.md

content_sha256: c17f84ce489bfaa900ab953b8afee962877fd3218206893004b447e1a0368013

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-054.docx

## QC-WI-055

title: Nelaton catheters — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Urethral catheter product specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-055.md

content_sha256: 8496c74b6ee658b19060316f7539976f398520ff3d6f0f38f3c9ca07f18ae6eb

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-055.docx

## QC-WI-056

title: Nasal cannulas — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Respiratory product specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-056.md

content_sha256: b04f82012b5ad8d07b06f056a752c715a0404a57d545b4bb132cafd8c2875da1

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-056.docx

## QC-WI-057

title: Brushes — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Product/design specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-057.md

content_sha256: 8a32553ab7f7e6b9f74d25677ad6816d506b70ad1f779864e2910c79e813877a

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-057.docx

## QC-WI-058

title: Clamps — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Product/design specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-058.md

content_sha256: 18b87a5ccdcf7b4f2b4306b43e8cc50a8a1877796bd28639e22750d86da8c19b

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-058.docx

## QC-WI-059

title: Goggles — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Eye-protection product specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-059.md

content_sha256: 19bbfe17d459fde3371e787ebcb656f25fc77732a3cf2aa871059bf1732184d4

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-059.docx

## QC-WI-060

title: Endotracheal tubes — inspection and test review proposal

revision: D0.2

status: DRAFT FOR REVIEW

owner: Airway product specialist; QC/QMS

implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

parent: QC-SOP-008

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-060.md

content_sha256: 2bf6a18d3efd5df1b280f3fb5f950ec8b3cdb0836385eecdebc42a7209fa2883

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-060.docx

## QC-WI-061

title: Establish and measure an approved performance baseline

revision: D0.2

status: DRAFT FOR REVIEW

owner: Performance engineer; Product owner; QMS

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-030

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-061.md

content_sha256: bc76afa2906851d5b4edf2b2d34cd7ca81b3c43283ca96012f81948701ad6c5e

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-061.docx

## QC-WI-062

title: Review audit evidence and controlled-record history

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized audit reader; QMS

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-024

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-062.md

content_sha256: 697c3f91842c60fcea60bc697a3d25b8b0af82f520b31a991d3753535b7b0a77

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-062.docx

## QC-WI-063

title: Handle a generic approval awaiting authority policy

revision: D0.2

status: DRAFT FOR REVIEW

owner: Assigned approver; QMS; Named owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-011

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-063.md

content_sha256: a61849c58357d5a1d38ae9c1a6ce7ca90a66db347a13edb3dc3767b321f0f80a

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-063.docx

## QC-WI-064

title: Verify outbox processing, correlation and operator alerts

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized operations engineer; Provider; Named owner

implementation: PROPOSED OPERATIONS PROCEDURE — WORKER/PROVIDER CAPABILITY REQUIRED

parent: QC-SOP-028

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-064.md

content_sha256: 3ced73a935cc36db7aed1d9749d273b0f70b650958ab9cbfad257de5467d59a1

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-064.docx

## QC-WI-065

title: Review storage and environment configuration readiness

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized IT operator; Named owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-029

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-065.md

content_sha256: 459450b44b7aa17b7af40631814b2904b97962f283f4d306ef668ac75976ec20

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-065.docx

## QC-WI-066

title: Review quarantine administration and configuration sources

revision: D0.2

status: DRAFT FOR REVIEW

owner: Authorized template administrator; Named owner; QC technical owner

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-022

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-066.md

content_sha256: 42887d9ada94b10b770e24e720b38f8296a8cdace755b317295b2cc8f1c6d160

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-066.docx

## QC-WI-067

title: Review release evidence intake and the nineteen gates

revision: D0.2

status: DRAFT FOR REVIEW

owner: Named owner; Authorized release reviewer; Trusted evidence provider

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-030

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-067.md

content_sha256: 8f928c5a2b2571718be19e7f93f53edccfc61aec008dfdde1fd70847ef2b9be4

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-067.docx

## QC-WI-068

title: Record a real UAT cycle, session and defect

revision: D0.2

status: DRAFT FOR REVIEW

owner: Named owner; Actual UAT participant; QCM/owner acceptor

implementation: SOURCE-ALIGNED DRAFT

parent: QC-SOP-030

effective_date: None

approval_signature: None

markdown: References/Authoring_Sources.zip!/WI/QC-WI-068.md

content_sha256: e7fce25c237ceb5216298554fd3834137e101472272e91ce4baffa5a108d9fb4

hash_scope: Archived Markdown UTF-8 bytes

delivery: WIs/QC-WI-068.docx