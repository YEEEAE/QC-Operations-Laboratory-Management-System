# QC-SOP-016 — Internal transfer, rework and physical disposition

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Move, rework, return or dispose of controlled material only after an authorized disposition and quantity reconciliation.

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL MOVEMENT LEDGER REQUIRED

## 2. Responsibilities and review

Responsible specialists: Warehouse; Production; QC Supervisor; QMS

Review: Warehouse; Production; QC Supervisor; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The disposition identifies material, lot, quantity, permitted destination and restrictions.

- The sending and receiving locations can preserve status.

- The technical owner has approved any rework method and reinspection requirement.

## 4. Procedure

1. Read the disposition and verify its authority and affected quantity. A report title, printed signature box or proposed checkbox is not sufficient authorization.

2. Create a controlled movement record containing origin, destination, lot, quantity, unit, condition, reason and related QC record identifiers.

3. Before movement, count the segregated units and reconcile partial lots. Preserve rejected or HOLD status on labels and containers.

4. For rework, issue the approved instruction and identify who may perform it. Record the original defect, work performed and new inspection requirement; do not relabel material as accepted on completion of rework alone.

5. The receiver checks identity, quantity and status and records receipt. Document discrepancies before merging material into another location or production order.

6. Return the completed movement evidence to QC and the source record owner. The current system has no dedicated stock-transfer execution or inventory-balance ledger for this procedure.

7. Perform the required reinspection or retest as new linked work, keeping the original failure and disposition history.

8. Close the physical reconciliation after sender and receiver resolve any balance. QMS must approve disposal controls and retention requirements separately.

## 5. Decisions, errors and stop conditions

- An absent disposition or destination acceptance stops movement.

- Do not interpret a rejected-material report completion as proof that physical transfer or destruction occurred.

## 6. Records and handoff

- Disposition approval

- Movement and quantity reconciliation

- Rework execution

- Reinspection and destination receipt

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-025

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
