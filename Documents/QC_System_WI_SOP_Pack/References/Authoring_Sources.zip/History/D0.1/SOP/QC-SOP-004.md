# QC-SOP-004 — Supplier receipt and purchase-order reconciliation

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Receive raw materials and finished goods, reconcile the physical delivery to supplier documents and capture the receiving record.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Warehouse; QC entry operator; Purchasing; QC Supervisor

Review: Warehouse; QC entry operator; Purchasing; QC Supervisor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The physical delivery and supplier slip are available.

- The current company receiving form is identified in the form register.

- The operator has PERM-QUAR-CREATE for digital entry.

## 4. Procedure

1. Keep the delivered material in the designated receipt area until its identity and status are established. Separate different lots and units so a mixed delivery does not become one ambiguous record.

2. Compare supplier, purchase order, item code, description, lot, unit and quantity with the physical labels and supplier paperwork. Record partial deliveries and discrepancies rather than rewriting the purchase order.

3. Count or measure using the approved receiving practice. Preserve the unit and the decimal quantity as supplied; do not sum pieces, kilograms and lengths together.

4. Check receiving and expiry dates. The server rejects expiry before receiving. Missing, illegible or inconsistent dates require a source clarification, not a guessed date.

5. Create the record at /quarantine/receiving/new using receivingNo, supplier, docNo, itemCode, description, lot, qty, quantityUnit, purchaseOrderNo, receivingDate and expiryDate as applicable.

6. After saving, reopen the record and compare each field against the form. Retain the exact supplier document reference and original evidence file; photographs may show multiple records and must be linked deliberately.

7. Keep the workflow in PENDING until the applicable readiness requirements are satisfied. Marking ready or starting an inspection is a separate action; creation does not establish inspection results.

8. Hand the record and identified lot to the inspection owner. Purchasing resolves supplier and purchase-order discrepancies; QC resolves product or method concerns. Record both decisions when both apply.

## 5. Decisions, errors and stop conditions

- An unresolved identity, lot or quantity discrepancy prevents readiness for inspection; use controlled HOLD where authorized.

- A yellow receiving slip or purchase-order signature is not a product release decision.

## 6. Records and handoff

- Receiving record

- Supplier slip F-7-5-7-1 where applicable

- Purchase-order reconciliation

- Discrepancy and handoff record

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/create-receiving.ts

- src/modules/quarantine/receiving/domain/receiving-item.ts

- src/pages/quarantine/receiving/new.astro

Related work instructions: QC-WI-001

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/receiving

- /quarantine/receiving/new

- /quarantine/receiving/[receivingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
