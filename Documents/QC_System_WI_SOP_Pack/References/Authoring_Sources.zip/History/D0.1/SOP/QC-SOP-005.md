# QC-SOP-005 — Receiving corrections and record conflicts

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Correct recorded receiving facts without overwriting inspection snapshots or historical decisions.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator; QC Supervisor; Record owner

Review: QC entry operator; QC Supervisor; Record owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The original source and reason for correction are available.

- PERM-QUAR-EDIT, scope and expectedVersion permit the action.

- The record is in PENDING, READY_FOR_INSPECTION, HOLD or EXPIRED.

## 4. Procedure

1. Open the receiving detail and read its current workflow state and version. Determine whether the error is a receiving fact or an inspection finding.

2. Use the populated correction entry from the detail page. Compare the opened values with the source; preserve the original record and evidence.

3. Enter corrected supplier, document, item, lot, quantity, unit, purchase-order and date fields only where the source supports the change. Add a meaningful reason identifying the wrong fact and the supporting record.

4. Submit the form with the version it opened. Do not replace the expected version with a freshly fetched value merely to force a stale submission through.

5. Reload after confirmed success and compare the new values, version and correction history. Confirm that the reason was recorded and the original evidence remains retrievable.

6. If another user changed the record, compare both versions before deciding what to enter again. Keep the unsaved proposed correction outside the historical record until it has been reconciled.

7. From UNDER_INSPECTION onward, use the inspection and HOLD disposition process for snapshot-bound facts. RELEASED and CANCELLED history must not be silently edited.

8. When the response is uncertain, look up the existing record and action history before retrying. A network error can occur after the server committed.

## 5. Decisions, errors and stop conditions

- A stale version requires reconciliation, not automatic overwrite.

- If the source is missing or the correction would alter an approved snapshot, stop and escalate to the record owner.

## 6. Records and handoff

- Correction reason

- Original and corrected values

- Version-conflict reconciliation

- Audit event

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/correct-receiving.ts

- src/modules/quarantine/receiving/domain/receiving-state.ts

Related work instructions: QC-WI-002, QC-WI-007

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
