# QC-SOP-010 — Raw data, instrument files and calculation control

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Maintain traceable raw observations, files, calculations and reported values throughout a test.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Laboratory; QC Supervisor; Document Control; IT

Review: Laboratory; QC Supervisor; Document Control; IT

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The approved method specifies required raw data and calculation inputs.

- The permitted storage and file-upload policy is established.

- Each file can be associated with a record, sample and run.

## 4. Procedure

1. Capture raw readings at the time of work. Identify instrument, program, sample, run, operator and time; retain the instrument printout or original electronic file.

2. Register the original file and its stored digest through the supported evidence process. A filename or local path alone is not an approved registered source.

3. Link the file to the correct record and identify which portion supports which observation. If one image shows several forms, retain that relationship in the source register.

4. Record units at acquisition and calculation. Preserve the distinction between gauge and absolute pressure, cm³ and litres, seconds and minutes and N·m versus N/m.

5. For a proposed stable-volume, approximately isothermal pressure-throughput calculation, q = V × abs(Pstart − Pend) / Δt gives Pa·cm³/s when V is cm³ and pressure is Pa. It is a review proposal, not the equipment algorithm or a product acceptance criterion.

6. The method owner must address temperature change, deformation, fixture/background leakage, effective volume, uncertainty, sign convention and standard-state conversion before approving this calculation.

7. Retain all calculation inputs, rule reference/version, calculated value and calculation unit. Compare selected calculations independently without changing the raw readings.

8. Protect historical files and audit records from replacement. If a file is wrong, add a controlled correction and a new traceable file rather than overwriting the original.

## 5. Decisions, errors and stop conditions

- An unreadable file or inconsistent unit blocks the related conclusion.

- A successful upload does not prove malware scan, MIME validation, approved retention or long-term retrieval; those require separate evidence.

## 6. Records and handoff

- Original file and SHA-256

- Record/run/sample link

- Calculation rule and inputs

- Independent check

- File correction history

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/domain/measurement.ts

- Documents/DATA-GOVERNANCE-REGISTER-032.md

- EXT-009

Related work instructions: QC-WI-018, QC-WI-019

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-006 — Leak calculation validation

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
