# QC-SOP-026 — Worklists, search, dashboards and notifications

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Use read models and in-app notifications to find work without treating them as controlled decisions or complete evidence.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized system user; Work owner; Support

Review: Authorized system user; Work owner; Support

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The user is authenticated and has source read permissions.

- The route and selected filters are known.

- The operator understands the bounded-page and source-status display.

## 4. Procedure

1. Open the appropriate dashboard, /work or /search surface and review scope, period and source status before acting on a count.

2. Search uses per-source permissions and supported scope. Keep denied sources distinct from failures; do not infer inaccessible record existence from a missing result.

3. Read the exact total and page boundary. A sampled or fifty-row page is not the whole register; continue through supported pagination when needed.

4. Open the underlying controlled record before performing work. A summary or notification may be older than the record version.

5. Use in-app notifications for personal workflow awareness. The implemented final-approval projections cover inspection/laboratory FINAL_APPROVE with APPROVED; Supervisor stage1 is intentionally silent.

6. Mark only your own notification read through the supported action. Read state is not acknowledgment of a controlled QC decision.

7. Investigate failed source reads through support with a sanitized correlation identifier. Keep available independent sections usable and do not replace unavailable totals with zero.

8. Reconcile overdue or missing work against the source record and owner. Provider email/SMS delivery and worker receipt require separate evidence and are not established by these pages.

## 5. Decisions, errors and stop conditions

- If a source is unavailable, do not conclude the workload is empty.

- A notification delivered in-app does not prove an external provider or operator alert received it.

## 6. Records and handoff

- Source record handoff

- Filter/page context where relevant

- Notification read state

- Sanitized support incident

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/dashboard

- src/modules/tasks

- src/shared/routing/routes.ts

Related work instructions: QC-WI-044

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-022 — Worker, telemetry and alerts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /dashboard

- /work

- /search

- /notifications

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
