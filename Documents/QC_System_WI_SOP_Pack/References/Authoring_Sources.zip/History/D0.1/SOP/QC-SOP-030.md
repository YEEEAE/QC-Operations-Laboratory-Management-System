# QC-SOP-030 — Release governance, verification and human UAT

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Bind release and acceptance evidence to the exact candidate, applied schema, operating environment and real human decisions.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Named owner; Engineering; Verification lead; QMS; Human UAT participants

Review: Named owner; Engineering; Verification lead; QMS; Human UAT participants

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The release authority and nineteen-gate registry are approved.

- An isolated PostgreSQL18 verification environment and valid domain sources are available.

- The candidate SHA and dirty-tree fingerprint are recorded.

## 4. Procedure

1. Freeze HEAD, branch, status and content fingerprint before collecting evidence. Record the current source migration manifest and route inventory; source presence does not prove application in an environment.

2. Plan acceptance by module, route, operation, persona and state, including denied, stale, outage, rollback and ambiguous transport cases. This pack maps 19 source modules and 88 source pages.

3. Use the project verification-run context and supported Node contract before candidate build evidence. Bind build identity and results to the resulting exact tree; later edits can invalidate that binding.

4. Run PostgreSQL18 integrity, atomicity and concurrency checks against a disposable authorized environment. Do not substitute a different database version or synthetic domain approval for scientific authority.

5. Check browser/no-JavaScript, keyboard, accessibility, source outages, performance and screen/export evidence as applicable. Build or unit PASS is not browser, AT, UAT or production acceptance.

6. Real UAT participants record their own role-bound sessions in an authorized isolated cycle. The owner creates cycles/defects; signed QCM/owner acceptance uses its actual ceremony. Do not fabricate persona signatures or human observations.

7. Release intake requires trusted provider evidence, candidate identity and replay protection. Approve only when the canonical nineteen gates and their authority sources are actually satisfied.

8. Deploy, migrate or publish only under separate explicit authorization. Preserve release NO-GO when gates remain unresolved and carry forward open evidence by identifier rather than assigning a readiness percentage.

## 5. Decisions, errors and stop conditions

- A stale candidate, missing trusted evidence or unresolved gate prevents release approval.

- Creating this pack closes no runtime, scientific, signature, provider or UAT gate.

## 6. Records and handoff

- Candidate freeze

- Gate evidence

- Applied schema and runtime identity

- Performance/accessibility results

- Human UAT and release decision

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/RELEASE-RUNBOOK.md

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

- src/modules/release-governance

- src/modules/uat-evidence

Related work instructions: QC-WI-049, QC-WI-061, QC-WI-067, QC-WI-068

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-024 — Release gates, applicability and human acceptance

- DEC-025 — Performance budgets and representative environment

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /governance/releases/[releaseId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
