# QC-SOP-017 — Findings and nonconformance control

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record findings, contain nonconformity and maintain the Finding to NCR link and closure evidence.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC; Supervisor; Quality process owner

Review: QC; Supervisor; Quality process owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The concern can be described with retrievable evidence.

- PERM-FIND-CREATE and PERM-NCR-CREATE apply to creation.

- The approved quality policy defines required containment and investigation.

## 4. Procedure

1. Record the factual observation, location, product or process reference and supporting evidence. Separate what was seen from the suspected cause.

2. Create the Finding with a meaningful title and description. Preserve the affected record identifiers and scope.

3. Assign immediate containment through the approved operational process. Record affected lots and quantities, responsible person and action evidence.

4. Where the approved prerequisites allow an NCR, create it from the persisted Finding link. Caller-supplied flags do not replace persisted prerequisites.

5. Review the NCR classification, owner and investigation requirements under the approved policy. The October quality decision pack contains proposals that must not be treated as approved authority.

6. Link relevant inspection, lab, rejection and task records. Maintain one clear evidence trail rather than copying conflicting summaries.

7. Advance only through actions allowed by the current state and permissions. Record reasons for return, void or closure where required.

8. Hand an NCR requiring causal analysis to RCA/CAPA. Retain the original finding even after the corrective process is complete.

## 5. Decisions, errors and stop conditions

- If containment or a required prerequisite cannot be proven, do not advance the lifecycle.

- QC entry users do not gain close or approval authority by creating the record.

## 6. Records and handoff

- Finding

- NCR and persisted predecessor

- Containment evidence

- Related records and handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/findings/domain/finding.ts

- src/modules/quality/ncr/domain/ncr.ts

- Documents/QUALITY-POLICY-DECISION-PACK-2026-10-02.md

Related work instructions: QC-WI-026, QC-WI-027

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/ncr

- /quality/ncr/new

- /quality/ncr/[ncrId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
