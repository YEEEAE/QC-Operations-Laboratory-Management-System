# QC-SOP-020 — Equipment registration and fitness for use

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Identify assets and prevent use when equipment status, calibration or maintenance makes the asset ineligible.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Equipment owner; Laboratory; Asset administrator

Review: Equipment owner; Laboratory; Asset administrator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The equipment identity and intended method are known.

- Creation and edit permissions are assigned.

- Calibration and maintenance evidence is retrievable.

## 4. Procedure

1. Register equipment through /assets/equipment/new with the supported identification fields. Verify the asset identifier against the label and manufacturer evidence.

2. Record the intended use and method relationship in controlled equipment documentation. A model name alone does not demonstrate suitability.

3. Before each controlled run, check ACTIVE state, absence of blocking maintenance and matching CURRENT calibration that is not overdue.

4. Inspect the equipment condition and required reference checks using the approved manual. Record abnormalities before testing.

5. Bind the run to the exact equipment and calibration context. Historical run snapshots must remain unchanged after later asset updates.

6. If equipment is unsuitable or fails during work, stop it, identify affected work and initiate maintenance and an impact assessment.

7. Only an authorized actor changes asset state through the supported workflow. A page selector or ACTIVE label cannot bypass the eligibility reader.

8. Return to use only after maintenance, calibration and required technical checks are documented and the system reports eligibility.

## 5. Decisions, errors and stop conditions

- An unavailable calibration or eligibility source denies use for controlled work.

- Determine whether earlier results are affected; repairing an instrument does not validate earlier data.

## 6. Records and handoff

- Asset record

- Suitability and reference checks

- Run equipment snapshot

- Failure impact assessment

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/assets/equipment/domain/equipment.ts

- src/modules/assets/equipment/infrastructure/eligibility-reader.ts

Related work instructions: QC-WI-032

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-002 — Leak-test equipment manual and safety

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /assets

- /assets/equipment

- /assets/equipment/new

- /assets/equipment/[equipmentId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
