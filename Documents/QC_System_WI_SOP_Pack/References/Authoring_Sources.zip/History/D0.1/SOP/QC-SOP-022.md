# QC-SOP-022 — Templates, controlled documents and revisions

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Manage approved templates and document revisions with immutable execution snapshots and registered source lineage.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Document Control; Template technical owner; Supervisor; QCM

Review: Document Control; Template technical owner; Supervisor; QCM

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The source document identity, revision, content digest and applicability are available.

- Template authority follows P-06.

- Generic document authority and effectivity decisions must be approved before promotion.

## 4. Procedure

1. Create a document or template with its real identity and scope. Register source files through the permitted evidence workflow rather than entering an arbitrary path as authority.

2. For a scientific template, identify each point, datatype, unit, criteria, precision, rounding and calculation source. Missing scientific authority prevents official evaluation.

3. P-06 template management is limited to Supervisor, Manager or the active named yazeed through explicit permissions. Admin and a non-named SYSTEM_OWNER do not acquire that authority.

4. Edit eligible drafts using the opened version and content hash. On conflict, compare versions and reconcile; do not overwrite a newer author contribution.

5. Create a new revision from the latest EFFECTIVE predecessor through the supported revision process. Respect the single open draft and retain evidence file digests and predecessor history.

6. Submit for the applicable review. Generic document APPROVE remains fail-closed until RD-019/PD-32 authority is established; APPROVED is still distinct from EFFECTIVE.

7. Stop or supersede a template only through supported authorized actions. Old inspection/laboratory executions keep their frozen template and source context.

8. Distribute an effective revision and withdraw superseded working copies only after actual approval/effectivity and training. This pack remains D0.1 draft.

## 5. Decisions, errors and stop conditions

- A stale content hash or missing registered file blocks the edit or transition.

- A source file ACTIVE status does not by itself prove approved scientific effectivity.

## 6. Records and handoff

- Document/version record

- Registered source digest

- Template point definitions

- Revision/CAS history

- Review and distribution evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/documents/domain/document-state.ts

- src/modules/quarantine/templates/domain/template-state.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-066

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-005 — Per-point and overall evaluation

- DEC-016 — Generic signature and document authority

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/admin

- /documents

- /documents/new

- /documents/[documentId]

- /documents/[documentId]/versions/new

- /documents/[documentId]/versions/[versionId]

- /documents/[documentId]/versions/[versionId]/review

- /quarantine/admin/[templateId]

- /documents/[documentId]/versions/[versionId]/edit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
