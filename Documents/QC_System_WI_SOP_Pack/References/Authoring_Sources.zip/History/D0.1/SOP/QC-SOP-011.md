# QC-SOP-011 — Review, approval and electronic signatures

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Review evidence and record decisions with the correct authority, workflow order and binding signature.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Supervisor; QCM; Authorized domain approver; QMS

Review: Supervisor; QCM; Authorized domain approver; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The applicable authority and signature policy is approved.

- The reviewer can read the exact version and its raw evidence.

- Separation-of-duties and scope checks pass.

## 4. Procedure

1. Open the submitted record and compare its identity, version, source applicability and raw evidence. Review the scientific basis and all unresolved exceptions.

2. Return incomplete or inconsistent work with a specific reason. The author corrects through the supported RETURNED and RESUME path; a reviewer must not edit historical evidence to make approval possible.

3. For inspection and laboratory records, Supervisor begins review and records stage-1 approval. This event moves UNDER_REVIEW to PENDING_QCM_APPROVAL and has no formal stage-1 e-signature.

4. QCM reviews the exact pending version, verifies the Supervisor decision and completes reauthentication for FINAL_APPROVE. The server binds actor, meaning, target version/hash and decision to signature and audit in the controlled transaction.

5. After final approval, confirm APPROVED and the displayed signature/decision evidence. An entered name or photographed signature is not an application signature ceremony.

6. Do not apply this inspection/lab authority automatically to generic documents, change requests, CAPA or release. Each workflow has its own policy and permission requirements.

7. Generic approval and change-request decisions remain fail-closed where PD-32 is unresolved. Document approval remains POLICY_SOURCE_REQUIRED. Record the blocked decision and obtain the authority source.

8. An authorized reopen preserves prior approval and returns the record to review. Repeat the required review stages on the changed version.

## 5. Decisions, errors and stop conditions

- QC entry users cannot review, return, approve, sign, close, finalize, void or attest.

- If password confirmation fails, the request is stale or the signature cannot bind, no decision is accepted.

## 6. Records and handoff

- Review checklist and reasons

- Version-bound decision

- Signature evidence

- Audit and reopen history

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- src/modules/laboratory/domain/lab-state.ts

- src/modules/quarantine/inspection/domain/inspection-state.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-063

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /approvals

- /approvals/[approvalId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
