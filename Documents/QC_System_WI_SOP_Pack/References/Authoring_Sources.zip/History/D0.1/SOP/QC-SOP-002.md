# QC-SOP-002 — Personnel training and competency

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Qualify people for physical testing and digital tasks before independent work; maintain a role-specific training record.

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL TRAINING TRACKING REQUIRED

## 2. Responsibilities and review

Responsible specialists: QMS; QC Supervisor; Technical specialists

Review: QMS; QC Supervisor; Technical specialists

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- An effective procedure and the approved role assignment exist.

- The technical reviewer defines a practical competency assessment for the task.

- A controlled training record is available; there is no dedicated digital training module in this source inventory.

## 4. Procedure

1. List the operations the person will perform, including product family, equipment, template revision and review stage. Page access alone does not establish competence.

2. The trainer explains the procedure and demonstrates the task with authorized training material. Use isolated training records; do not create fake production results.

3. The trainee performs a supervised exercise, identifies a deliberately presented discrepancy, preserves raw data and demonstrates the relevant stop condition.

4. The assessor records the observed work and any limitations. For scientific methods, assess instrument setup, units, calculation checks, uncertainty and handling of an invalid run.

5. The technical owner authorizes the permitted tasks after the assessment. Keep competence approval separate from granting application permissions.

6. Document Control records the procedure revision, trainer, assessment evidence, outcome and actual authorization date. Store personal information in the controlled training location.

7. Reassess after a relevant procedure, equipment or method change and after a demonstrated competence concern. QMS must approve the reassessment interval; this draft assigns no interval.

8. Remove the person from independent work when authorization expires or performance is unacceptable. Arrange supervised retraining and record the restoration decision.

## 5. Decisions, errors and stop conditions

- An incomplete assessment requires supervision and prevents independent testing.

- Training attendance does not prove competence, and a typed trainer name does not prove a signature.

## 6. Records and handoff

- Training matrix

- Practical assessment

- Task authorization

- Retraining record

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/ROLE-MATRIX.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Related work instructions: QC-WI-039

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
