# QC-SOP-009 — Laboratory method selection and execution

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Plan and execute laboratory work using approved methods, run context, calibrated equipment and typed observations.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Laboratory operator; Technical method owner; Supervisor; QCM

Review: Laboratory operator; Technical method owner; Supervisor; QCM

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The exact method, product applicability and scientific source are approved.

- The equipment and calibration match the method and are eligible.

- The operator has the lab permissions for creation and measurement entry.

## 4. Procedure

1. Identify the request, receiving source where applicable, product, lot and sample identifiers. Select an approved template whose version and controlled-source context match the task.

2. Confirm NUMERIC, TEXT or BOOLEAN datatype, units, required points, precision, rounding and calculation rule for each parameter. Do not infer a datatype from a value that looks like true or false.

3. Plan the run and record its equipment and calibration context. Equipment must be ACTIVE, not under maintenance and have matching CURRENT, non-overdue calibration.

4. Prepare and verify the instrument using its approved manufacturer manual and method. Record reference checks, environment, fixture and program revision; the exact device manual is still a required source for the photographed leak-test equipment.

5. Acquire raw readings against the correct sample and run. Retain replicates, timestamps and printouts rather than keeping only a calculated average.

6. Enter observations without premature rounding or unit conversion. NUMERIC values are decimal strings, TEXT stays text and BOOLEAN is a real boolean. Remarks require an associated value.

7. Apply only an approved calculation and evaluation rule. The current production evaluator denies missing scientific authority; preserve raw work and seek review rather than manufacture a PASS.

8. Submit for the two-stage review, resolve any return and preserve version-bound final evidence. Deliver the reviewed result to the requesting process; result approval does not establish lot release.

## 5. Decisions, errors and stop conditions

- A missing method, calibration or calculation source prevents controlled evaluation.

- Instrument failure or ambiguous sample identity requires an invalid-run investigation and retest decision, not silent deletion.

## 6. Records and handoff

- Test and template snapshot

- Run and sample context

- Equipment/calibration evidence

- Raw and calculated values

- Review chain

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/domain/measurement.ts

- src/modules/laboratory/application/save-measurements.ts

- src/modules/laboratory/domain/lab-state.ts

Related work instructions: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-050, QC-WI-051

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
