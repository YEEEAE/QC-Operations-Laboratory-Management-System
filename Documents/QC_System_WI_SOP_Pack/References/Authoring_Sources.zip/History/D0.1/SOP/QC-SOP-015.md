# QC-SOP-015 — Daily production and rejection reporting

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Capture daily production/rejection details and interpret analytics with a defined quantity unit and denominator.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Production; QC entry operator; Authorized finalizer; QMS

Review: Production; QC entry operator; Authorized finalizer; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- Production source records identify date, machine, product, lot and quantities.

- PERM-RREJ-CREATE and eligible edit permissions apply.

- QMS approves the reporting metric and denominator before formal use.

## 4. Procedure

1. Open /reject-reports/new?type=daily and identify the production period, section and department. Link the original daily production/rejection form.

2. Enter each line from production evidence with product, lot, unit, good quantity, rejected quantity and reason as supported by the form.

3. Append lines using the current expectedVersion. The repository serializes row position, version, audit and outbox changes; do not renumber stored history manually.

4. Keep decimal quantities as exact text and group analytics by report type and unit. Do not total incompatible units or silently round inputs.

5. The current implementation reports rejected quantity divided by good quantity, multiplied by 100 and rounded to four decimals; good quantity zero yields NULL. This is not automatically a defect proportion of total output.

6. The approved reporting owner must confirm the metric name, denominator and interpretation. Until then, label this behavior as implemented and under review in formal reports.

7. The authorized finalizer advances DRAFT to FINALIZED. QC entry users cannot finalize or void, even when they created the report.

8. Reopen the persisted report and reconcile line totals and displayed percentage with raw source data. Retain explanations for adjustments and the final action history.

## 5. Decisions, errors and stop conditions

- A zero denominator is unavailable/undefined, not zero percent.

- If screen, export and source disagree, stop distribution and use the report-provenance investigation.

## 6. Records and handoff

- Daily report lines

- Original F-7-5-3-12-2 or verified company revision

- Metric definition

- Finalization evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Related work instructions: QC-WI-024

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reject-reports/daily/[reportId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
