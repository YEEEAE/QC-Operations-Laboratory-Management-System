# QC-SOP-028 — Support, security incidents and service interruptions

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Respond to system or equipment interruptions, ambiguous writes and security concerns while preserving records and containment.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Support; Named owner; Security; QC/QMS

Review: Support; Named owner; Security; QC/QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- An incident owner and authorized support path are defined.

- Production changes and sensitive access have explicit authority.

- The operator can preserve sanitized evidence and physical status.

## 4. Procedure

1. Record the symptom, affected operation, time, safe correlation identifier and known record/version. Do not include passwords, tokens, connection strings or full provider exports.

2. Determine whether the problem affects reads, submission, signature, evidence storage or physical testing. Contain affected lots and work when the evidence is uncertain.

3. For an unknown submission result, inspect the existing record and action history first. Avoid a second create or contradictory retry before resolving whether the first request committed.

4. Keep denied, not-found, validation, stale-version, policy-source and unavailable outcomes distinct. Support must investigate the actual boundary rather than weakening a guard.

5. Use owner-only /system/health or /system/control-center only as the active named yazeed with required capabilities. A non-named owner role does not confer that access.

6. Investigate audit/outbox correlation, dependency health and source readiness using authorized read-only tools. Enqueued or processed outbox events do not establish provider receipt.

7. Remediate only under the approved change/incident authority. No direct production patch, migration, permission expansion or restore is authorized by this draft.

8. After recovery, verify affected operations and unresolved write outcomes. QC/QMS assess impact on results, approvals and material disposition before work resumes.

## 5. Decisions, errors and stop conditions

- If the record outcome cannot be established, keep the activity unresolved and escalate.

- A service returning 200 is not enough to validate affected controlled work or raw files.

## 6. Records and handoff

- Incident and impact scope

- Sanitized evidence

- Unknown-result resolution

- Authorized remediation

- Recovery checks

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/INCIDENT-PROBLEM-RUNBOOK.md

- Documents/FIRST-DAY-OPERATING-CHECKLIST.md

- src/modules/system-health

Related work instructions: QC-WI-006, QC-WI-008, QC-WI-046, QC-WI-064

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-022 — Worker, telemetry and alerts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /system/health

- /system/control-center

- /help

- /404

- /500

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
