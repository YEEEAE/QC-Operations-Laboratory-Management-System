# QC-SOP-001 — Document control and approval of this pack

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Control the creation, review, approval, distribution, revision and withdrawal of procedures, work instructions and linked company forms.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Document Control; QMS; QC Manager

Review: Document Control; QMS; QC Manager

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The master register identifies every draft and its reviewer.

- Reviewers have the current source files, original forms and applicable approved policy.

- The approved signature and effectivity policy must exist before controlled use.

## 4. Procedure

1. Document Control assigns the independent QC-SOP or QC-WI number and records D0.1. Keep the company form number unchanged in the form register; these are different identifiers.

2. The author writes the actual workflow, identifies proposed manual work and links each scientific claim to a specific source. A photograph is evidence of a record or printed field, not proof that a method remains effective.

3. A QC specialist checks technical content and applicability. Engineering checks routes, field names, permissions and supported actions. QMS checks authority, retention, change control and the distinction between a result and a release.

4. Resolve comments in a new draft revision and preserve the earlier review history. Record the disposition of each comment; do not silently remove a technical objection.

5. Before approval, the responsible owner resolves the relevant DEC entries. A reviewer may accept the writing while a method remains unapproved; record those outcomes separately.

6. Approve only through the authorized controlled process. Generic document approval is currently blocked by POLICY_SOURCE_REQUIRED while RD-019 and PD-32 are unresolved. Do not use an alternate page or direct database update.

7. Record the actual approval evidence and effective date only after the ceremony occurs. APPROVED is separate from EFFECTIVE. Withdraw superseded copies at the point of use while retaining history.

8. Train affected personnel on the effective revision and verify that the delivered SOP PDF or WI DOCX, archived Markdown and master register have the same revision and content. A draft print remains visibly marked DRAFT FOR REVIEW.

## 5. Decisions, errors and stop conditions

- If a source changes, reassess the affected procedure and update its source binding before continued controlled use.

- If the approval or effectivity policy is missing, retain the document as draft. No automatic promotion is permitted.

## 6. Records and handoff

- Master document register

- Review comment disposition

- Approval and effectivity evidence

- Training and distribution records

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- src/modules/documents/domain/document-state.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

- DEC-020 — Retention, file safety and record storage

- DEC-028 — Source description conflicts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
