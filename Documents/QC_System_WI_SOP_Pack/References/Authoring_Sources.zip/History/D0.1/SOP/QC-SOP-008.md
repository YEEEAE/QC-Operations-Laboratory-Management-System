# QC-SOP-008 — Incoming and product inspection

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Inspect identified products using the correct approved template and preserve per-point evidence and source applicability.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC operator; Supervisor; QCM; Product specialist

Review: QC operator; Supervisor; QCM; Product specialist

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The receiving record is eligible to start inspection.

- The template, source revision and criteria apply to the exact product and size.

- The operator has PERM-QUAR-START-INSPECTION and execution permissions.

## 4. Procedure

1. Review receiving identity, quantity, lot and supplier paperwork. Confirm that any unresolved receiving discrepancy has an approved disposition before starting.

2. Choose the applicable approved inspection template and preserve its snapshot. A later template edit must not change the inspection that already began.

3. Identify the sampled units and the approved plan. Inspect packaging, identification, dimensions and functional points required for that product; family instructions QC-WI-052 through QC-WI-060 provide review proposals.

4. Record the observation for every applicable point, the unit, equipment reference, remarks and raw evidence. Use only an approved rule for not-applicable points; handwritten N/A does not establish a digital datatype.

5. Where a numeric or judgment criterion lacks approved source lineage, stop evaluation and retain the observation for technical review. The system intentionally denies unsupported scientific evaluation.

6. Submit the complete record to Supervisor review. Resolve returns in the author correction path and preserve original evidence.

7. Supervisor stage approval moves UNDER_REVIEW to PENDING_QCM_APPROVAL without a formal stage-1 e-signature. QCM final approval requires the approved FINAL_APPROVE ceremony and produces APPROVED.

8. Hand the official inspection outcome to receiving control. APPROVED inspection and PASS do not themselves release the lot.

## 5. Decisions, errors and stop conditions

- A failed, incomplete or contradictory point requires containment and a documented review decision.

- An approved template status does not substitute for approved scientific source, effectivity or applicability.

## 6. Records and handoff

- Inspection snapshot

- Sample-level observations

- Raw attachments

- Review return and final approval evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/inspection/domain/inspection-state.ts

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-011, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-003 — Sampling plan

- DEC-005 — Per-point and overall evaluation

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
