# QC-SOP-014 — Rejected material and rejection slips

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record rejected material, reasons, disposition and the approved confirmation chain while maintaining segregation.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator; Authorized confirmation actors; Warehouse; QMS

Review: QC entry operator; Authorized confirmation actors; Warehouse; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The material identity, lot, quantity and evidence are known.

- The current rejection slip and approved disposition authority are available.

- PERM-RREJ-CREATE and later action-specific grants apply.

## 4. Procedure

1. Contain and identify the affected material. Link the inspection, laboratory or incident evidence that explains the concern.

2. Create an issue-slip report at /reject-reports/new?type=slip. Enter item descriptions, lots, units, quantities, reasons and proposed disposition with source references.

3. Compare the digital report with the original F-7-5-7-8 Rev4 where applicable. Its printed approval roles are not identical to all application checkpoint labels; QMS must reconcile the mapping.

4. The supported workflow is DRAFT to APPROVAL_TRACKING to COMPLETED, with controlled VOID where authorized. Follow SUPERVISOR, QC_MANAGER and FACTORY_DIRECTOR checkpoint order where the approved server contract applies.

5. QC entry users may create and submit eligible work but cannot record approval confirmations, attest, finalize or void. This newer owner decision overrides older descriptive text that allowed creator confirmation.

6. The authorized actor records only a real completed approval supported by retrievable evidence. A typed approver name is a business field, not an e-signature.

7. Before rework, warehouse transfer, return or destruction, obtain the approved disposition and perform the physical handoff using QC-SOP-016.

8. Confirm the final report state and action history; retain the original slip and quality links. Reconcile affected quantities so no units are lost between rejection and disposition.

## 5. Decisions, errors and stop conditions

- Missing signer authority or disposition keeps the material segregated.

- The warehouse exception printed on one form is a source observation, not a blanket waiver of required approval.

## 6. Records and handoff

- Rejection slip and source

- Affected lot and quantity

- Confirmation evidence

- Disposition and handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Related work instructions: QC-WI-022, QC-WI-023

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reject-reports

- /reject-reports/new

- /reject-reports/issue-slips/[reportId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
