# QC-SOP-012 — Invalid work, retesting and disputed results

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Investigate suspect or invalid test work and authorize a traceable retest without replacing the original outcome.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Technical method owner; Supervisor; QCM

Review: Technical method owner; Supervisor; QCM

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The original test, run and raw data are retained.

- The technical owner has an approved retest policy.

- The actor has the applicable retest permission and eligible source state.

## 4. Procedure

1. Separate an out-of-specification observation from an invalid execution. Record what failed, when it occurred and which samples and runs may be affected.

2. Contain affected material and prevent a release based on disputed evidence. Preserve instrument settings, error messages, prints and environmental records.

3. Investigate identity, fixture, calibration, method, operator and calculation issues. Do not declare a result invalid merely because it failed.

4. The technical owner decides whether additional testing is justified, its sample selection, method and relationship to the original. These rules require approval; this draft sets no maximum retest count.

5. Create the retest through the supported laboratory action and retain the parent link and reason. Preserve the original test and its result.

6. Prepare eligible equipment and a newly identified run. Record each new reading and evidence file as new work rather than editing the prior raw observation.

7. Review the original and retest together. Explain differences and assess the effect on lot disposition and quality follow-up.

8. Close the investigation only through the authorized workflow. An accepted retest does not automatically erase the original failure or release the material.

## 5. Decisions, errors and stop conditions

- Missing retest authority or unexplained disagreement requires HOLD and technical review.

- Never test repeatedly until a passing number appears.

## 6. Records and handoff

- Invalid-run investigation

- Retest authorization and parent link

- New run data

- Combined technical conclusion

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/application/create-retest.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-020, QC-WI-041, QC-WI-042

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
