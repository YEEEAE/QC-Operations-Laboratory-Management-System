# QC-SOP-013 — Laboratory report-form transcription

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Transcribe physical Pressure Decay and Subatmospheric report forms into the draft report surface without treating transcription as controlled evaluation.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator; Laboratory; Document Control

Review: QC entry operator; Laboratory; Document Control

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The original report is legible and its form revision is identified.

- PERM-LAB-VIEW, PERM-LAB-CREATE or PERM-LAB-EDIT-DRAFT apply as needed.

- The original form is listed in the form register.

## 4. Procedure

1. Select /laboratory/report-templates and the matching Pressure Decay or Subatmospheric draft type. Verify the original form identity; FR-MA-018 Rev06 and F-8-2-6-07 Rev4 have materially different printed parameters.

2. Transcribe identification, equipment, assembly, environment, sample rows, remarks and historical result exactly as recorded. Preserve uncertainty instead of guessing an illegible digit.

3. Record the company form number and revision in the external source register. These drafts currently have no controlled source-link or promotion mechanism, so the register is the traceability companion.

4. The digital form has twelve sample rows. This layout is not a sampling plan, and it does not justify twelve tests for every lot.

5. Keep Tested By, Reviewed By and Approved By as historical transcription text. They do not create electronic signatures or prove current signer authority.

6. Save and reopen the draft, compare all entered fields against the original and record discrepancies for correction.

7. Use print only as a convenient draft representation. Do not present it as an approved laboratory result or promote it into qc.lab_tests by an undocumented process.

8. Retain the original record and its hash. Any later controlled test must be separately created with approved source, method, authority and evidence.

## 5. Decisions, errors and stop conditions

- If source values are unreadable or contradict printed limits, flag them for review.

- A transcribed PASS, FAIL or HOLD remains a historical source value and is not a computed outcome.

## 6. Records and handoff

- Report draft

- Original source reference

- Transcription check

- Unresolved field list

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/LABORATORY-REPORT-TEMPLATES.md

- src/modules/laboratory/application/report-drafts.ts

Related work instructions: QC-WI-021

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-004 — Leak-form revision and unit conflict

- DEC-028 — Source description conflicts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory/report-templates

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
