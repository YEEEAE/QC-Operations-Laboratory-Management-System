# QC-SOP-007 — Sampling and sample custody

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Select representative samples, protect lot identity and record sample custody through testing and disposition.

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL CUSTODY AND PLAN CONTROL REQUIRED

## 2. Responsibilities and review

Responsible specialists: QC Supervisor; Sampling operator; Laboratory

Review: QC Supervisor; Sampling operator; Laboratory

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- A technical owner has approved the sampling plan and defect classification.

- The lot boundary and quantity unit are known.

- The site has an approved sample handling and disposal practice.

## 4. Procedure

1. Define the lot by product, size, supplier, lot number and manufacturing or receiving context. Resolve mixed-lot material before selecting samples.

2. Use the approved sampling plan, including lot size, inspection level, AQL or another justified design, code letter, sample size, acceptance/rejection counts and switching rules where applicable.

3. Do not infer a plan from twelve form rows, a handwritten sample size, a historical acceptance mark or this draft. ISO 2859-1:2026 is a candidate attributes-sampling source that requires licensed-text review and owner adoption.

4. Select units using the approved representative method across the lot. Identify each selected unit or defined sample group and record the location and selection method.

5. Label samples with receiving reference, lot, product, sample identifier, date and collector. Preserve packaging conditions and any environmental handling limits from the approved method.

6. Record each handoff: sender, receiver, time, condition, destination and purpose. Use a controlled manual custody record where the application has no dedicated custody function.

7. On laboratory receipt, reconcile identifiers and quantity with the request. Record damage, missing units or broken custody before testing.

8. After testing, identify consumed, retained and returnable samples. Follow the approved retention and disposal instruction; this draft sets no period.

## 5. Decisions, errors and stop conditions

- If the plan or lot boundary is unapproved, stop acceptance sampling.

- A substituted or damaged sample requires a documented technical decision; never replace a failing unit without retaining the original evidence.

## 6. Records and handoff

- Sampling plan and selection log

- Sample identity

- Custody handoffs

- Retention or disposal disposition

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

- src/modules/laboratory/domain/lab-test.ts

- EXT-008

Related work instructions: QC-WI-009, QC-WI-010

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-003 — Sampling plan

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
