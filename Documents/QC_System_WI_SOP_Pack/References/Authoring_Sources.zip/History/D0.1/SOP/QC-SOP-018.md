# QC-SOP-018 — Root cause and CAPA lifecycle

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Investigate cause, implement actions, verify implementation and assess effectiveness without equating closure with successful effectiveness.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Quality process owner; Investigator; Supervisor; QMS

Review: Quality process owner; Investigator; Supervisor; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- A linked NCR and persisted prerequisite evidence exist.

- The quality owner has approved causal, verification and effectiveness criteria.

- The actor has the relevant RCA/CAPA grant and scope.

## 4. Procedure

1. Define the problem from NCR evidence, including affected scope, timing and impact. Collect process evidence before selecting a cause-analysis technique.

2. Develop and test causal explanations. Record evidence that supports or rejects each important explanation; a completed diagram alone does not establish root cause.

3. Create CAPA with its required NCR link, clear title/description and at least one action. Define action owner, due date where approved and objective completion evidence.

4. Execute actions and keep their records. Move to action verification only when persisted action completion and verification prerequisites are satisfied.

5. Verify that the action was implemented as specified. Then assess effectiveness against the pre-approved method and observation window; these are separate judgments.

6. Use DRAFT, OPEN, IN_PROGRESS, AWAITING_VERIFICATION, EFFECTIVENESS_REVIEW and READY_FOR_CLOSURE only through supported transitions.

7. P-04 permits exceptional Supervisor closure with the exact close permission, reason, reauthentication and e-signature, including cases with incomplete actions or failed effectiveness. The closure record must state those limitations.

8. Retain follow-up obligations and the effectiveness outcome after closure. Do not turn CLOSED into a claim that the action worked or that the product is released.

## 5. Decisions, errors and stop conditions

- Missing persisted prerequisites deny advancement; caller flags cannot satisfy them.

- A proposed quality rule remains proposed until the responsible owner approves it.

## 6. Records and handoff

- RCA evidence

- CAPA actions and verification

- Effectiveness assessment

- Signed closure and residual obligations

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/rca/domain/rca.ts

- src/modules/quality/capa/domain/capa.ts

- Documents/QUALITY-POLICY-DECISION-PACK-2026-10-02.md

Related work instructions: QC-WI-028, QC-WI-029, QC-WI-030

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quality/rca

- /quality/rca/[rcaId]

- /quality/capa

- /quality/capa/new

- /quality/capa/[capaId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
