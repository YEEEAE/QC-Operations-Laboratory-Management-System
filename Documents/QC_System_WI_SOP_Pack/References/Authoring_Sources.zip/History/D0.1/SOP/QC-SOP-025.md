# QC-SOP-025 — Reports, provenance and controlled exports

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Produce scoped reports and exports with explicit filters, units, provenance and consistent screen/export data.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Report owner; QC/QMS; Authorized reader

Review: Report owner; QC/QMS; Authorized reader

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- PERM-RPT-VIEW and source domain scope permit access.

- The report purpose and approved metric definition are known.

- Source availability can be distinguished from empty results.

## 4. Procedure

1. Select the report and record its period, filters, quantity unit and requesting purpose. Confirm that scope excludes inaccessible records and counts.

2. Review the source status. Denied, unavailable, missing and empty are different outcomes; unavailable counts must not be presented as zero.

3. Compare displayed rows and totals using the same predicates. Check unit grouping and the approved denominator before interpreting a percentage.

4. Generate export from the supported report action and compare its provenance/filter context with the screen snapshot.

5. If the source changes before export, the current digest check may return REPORT_DATASET_CHANGED. Refresh and review a new coherent dataset rather than distributing a mixed snapshot.

6. Retain the report evidence in the approved location. Current request-local digests are not a durable retained report snapshot or signed certificate.

7. Mark convenience prints and unapproved outputs accordingly. Do not infer approved scientific status from formatting or a logo.

8. Record distribution and any report correction under approved policy. Preserve the original issued version and explain material changes.

## 5. Decisions, errors and stop conditions

- A stale dataset, missing source or unsupported denominator stops formal distribution.

- An export is read-only evidence of the returned dataset, not a new approval or release.

## 6. Records and handoff

- Filters and provenance

- Screen/export reconciliation

- Dataset-change response

- Approved distribution record

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- src/modules/reporting

- Documents/DATA-GOVERNANCE-REGISTER-032.md

Related work instructions: QC-WI-043

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reports

- /reports/[reportCode]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
