# QC-SOP-029 — Backup, restore intent and disaster recovery

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Protect database and files, authorize recovery and demonstrate isolated restoration with measured recovery objectives.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Named owner; IT recovery operator; QMS; Provider

Review: Named owner; IT recovery operator; QMS; Provider

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The owner has approved backup scope, storage, retention, recovery authority and target environment.

- The provider recovery procedure and durable artifacts are available.

- RPO and RTO targets are approved before comparison.

## 4. Procedure

1. Inventory database, file objects, manifests, schema ledger and configuration required for a coherent recovery. Identify responsibility for each provider-held artifact.

2. Use the approved backup mechanism and verify durable manifest/catalog, checksums and retrieval. The local adapter is memory-only, and source configuration alone does not prove durability.

3. Record backup timing and scope without exposing secrets. Keep file and database consistency evidence and provider receipts distinct from job status.

4. In the application, a restore request creates a PLANNED restore intent only. Use the explicit drill permission, GLOBAL scope, reason, backup version/eligibility snapshot and stable idempotency key.

5. Reopen the saved intent and verify PLANNED, audit and request outcome. The current system has no restore executor; never report this as RESTORED.

6. For an authorized isolated exercise, the recovery operator obtains provider artifacts and restores into a separate destination with approved access and no production traffic.

7. Verify schema version/checksums, row relationships, record/signature/audit links, raw files and their digests and key read/write operations in the isolated target.

8. Measure actual recovery point and elapsed recovery time from recorded events, compare with approved RPO/RTO and document exceptions. No numeric objective is supplied by this pack.

## 5. Decisions, errors and stop conditions

- No provider artifact, executor or approved target means no restoration claim.

- Production restore requires separate explicit authority; an isolated intent or source test does not grant it.

## 6. Records and handoff

- Durable backup and manifest

- PLANNED intent

- Provider receipt

- Isolated restore evidence

- Measured RPO/RTO

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/BACKUP-RECOVERY-PLAN.md

- src/modules/backup-recovery

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-047, QC-WI-048, QC-WI-065

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

- DEC-021 — Recovery authority, provider and objectives

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /system/backups

- /system/backups/[backupId]

- /system/backups/[backupId]/restore

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
