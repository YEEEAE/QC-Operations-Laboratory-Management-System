# QC-SOP-024 — Records, audit, retention and corrections

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Maintain accountable records and audit history, manage authorized correction and retain evidence under approved policy.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QMS; Document Control; IT; Record owners

Review: QMS; Document Control; IT; Record owners

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- Record classes, access and retention authority are defined.

- The storage location and restore responsibilities are approved.

- The actor has the record-specific permission and eligible state.

## 4. Procedure

1. Capture facts at the time of work with the record identifier, actor, date, source and version. Preserve the difference between an observation, a calculated value and a decision.

2. Use the application transaction for controlled changes. Domain record, signature where required, audit and outbox must commit together; do not patch history manually.

3. Review corrections for reason, source and affected prior decisions. Use reopened or new-revision paths where records are locked.

4. Store originals and registered digests with controlled links. Identify unreadable, cropped or conflicting forms and obtain the original rather than reconstructing unsupported text.

5. QMS approves retention periods, archival, legal hold, deletion and retrieval requirements per record class. This draft assigns no numeric retention term.

6. Protect audit and signature records from ordinary update/delete access. Support extracts must avoid credentials, tokens and unnecessary personal information.

7. Verify retrieval and restoration in the approved environment with raw files and database records. A local hash list proves file identity, not long-term recoverability.

8. Record discrepancies as an incident or quality concern and assess whether conclusions or released material are affected.

## 5. Decisions, errors and stop conditions

- Missing retention or storage policy is an approval decision, not permission to delete.

- Audit row presence alone does not prove a valid signature, provider delivery or physical activity.

## 6. Records and handoff

- Record-class policy

- Original and digest

- Correction/revision history

- Access and retrieval evidence

- Archive/disposal authorization

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DATA-GOVERNANCE-REGISTER-032.md

- src/shared/authorization/authorize.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-062

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /audit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
