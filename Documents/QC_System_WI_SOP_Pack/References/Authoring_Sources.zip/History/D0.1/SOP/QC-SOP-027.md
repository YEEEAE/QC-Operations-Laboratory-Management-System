# QC-SOP-027 — AI advisory governance

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Use AI only as non-binding advice within approved provider, data and consent boundaries.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Named owner; QMS; Authorized advisory user; Privacy/security reviewer

Review: Named owner; QMS; Authorized advisory user; Privacy/security reviewer

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The owner has approved provider, model, data classes, geography and retention.

- The configuration is valid and enabled under that policy.

- The user gives explicit consent for the particular external request.

## 4. Procedure

1. Confirm the policy and provider status before opening an external request. Default-disabled or POLICY_SOURCE_REQUIRED states must remain closed.

2. Identify the question and minimize its data. Do not send this pack’s real company form images, signatures, personal details or QC evidence to an external AI provider without explicit applicable approval.

3. Review the exact data that will be transmitted and obtain per-request consent. Consent to one question does not cover later requests.

4. Submit using the approved provider boundary. Preserve sanitized request/correlation evidence without recording credentials or unnecessary sensitive prompt data.

5. Treat the response as advisory. Verify factual and scientific claims against controlled sources before using them in an operational decision.

6. AI cannot write controlled business records, establish test PASS, release material, sign approval or close quality work. Use the normal authorized process for those actions.

7. On timeout, refusal or unknown transport outcome, retain the draft locally as permitted and investigate request status before retrying. Renew consent when the request data changes.

8. Review provider recovery, privacy and audit evidence through the approved policy process. A successful demo response does not approve a provider or data class.

## 5. Decisions, errors and stop conditions

- Absent policy, credentials, configuration or consent prevents sending.

- An AI suggestion never replaces a method owner, controlled source or signer.

## 6. Records and handoff

- Approved provider policy

- Request-specific consent

- Sanitized request outcome

- Human source verification

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/AI-PROVIDERS.md

- src/modules/ai-advisory

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-045

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-023 — AI provider/data governance

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /ai-advisory

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
