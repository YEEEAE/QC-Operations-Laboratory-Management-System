# QC-SOP-003 — Account, permission and session management

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Manage account creation, role assignment, activation, deactivation, password recovery and session revocation.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Named System Owner; Authorized identity administrator

Review: Named System Owner; Authorized identity administrator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The approved access request names the person and required work.

- The administrator has the exact identity permission and scope.

- OD-2026-09-23-RBAC-01 is the authority source for QC roles.

## 4. Procedure

1. Confirm the requester and business need before opening the user register. Record the approved role and permission scope; do not grant authority from a job title alone.

2. Map QC 01, QC 02 and QC 03 to EMPLOYEE with the same QC entry bundle. Supervisor is SUPERVISOR; QCM is MANAGER. Owner authority requires the active named loginIdentity yazeed in addition to SYSTEM_OWNER.

3. Create or update the account through the server operation and review the returned safe account details. Do not expose password hashes, credentials or session tokens in support evidence.

4. Check that entry permissions allow eligible creation, editing and submission while review, signing, release, close, attestation, finalization and void remain denied to QC entry users.

5. Activate an eligible account only after approved provisioning. Disable or revoke sessions when access is withdrawn; preserve identity history used by earlier records.

6. Use self-service password change or the authorized administrative reset. Verify success and revoked-session behavior; credential and session changes are transactional with audit.

7. At login, let the pending request resolve. Respect throttle feedback. After expiry, sign in again and reopen the record from a safe local return path.

8. Periodically review actual grants against approved need. QMS and the owner decide the review frequency and evidence location; do not invent a schedule.

## 5. Decisions, errors and stop conditions

- If account identity or requested authority is uncertain, do not provision it.

- Seeing an administrative page is not mutation authorization; every write still requires permission, scope, state and version checks.

## 6. Records and handoff

- Access request

- Safe user record

- Grant review

- Session revocation and credential audit

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- src/shared/authorization/authorize.ts

- src/modules/identity/application/create-user.ts

Related work instructions: QC-WI-040

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

- DEC-024 — Release gates, applicability and human acceptance

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /

- /login

- /admin

- /admin/users

- /admin/users/new

- /admin/users/[userId]

- /admin/roles

- /admin/roles/[roleId]

- /admin/permissions

- /admin/scopes

- /account

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
