# QC-SOP-023 — Controlled change requests

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Evaluate, authorize, implement and verify changes without bypassing the approval transaction or losing source version context.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Change requester; Assigned reviewer; QMS; Named owner

Review: Change requester; Assigned reviewer; QMS; Named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

## 3. Before you start

- The requested change and affected records are identified.

- The applicable change authority and signature policy is approved.

- The request references the opened current version.

## 4. Procedure

1. Create the change request with the proposed change, reason, affected product/process/system and supporting evidence.

2. Assess scientific, workflow, security, data, training, document and operational impact. Identify any new source or approval needed before implementation.

3. Submit and start review through the supported state actions. The review page has native version-bound START_REVIEW; it does not confer direct decision authority.

4. Record review findings and return incomplete work through the authorized process. Keep the reason and exact version.

5. RETURN, APPROVE and REJECT decision paths require approval transaction context. PD-32 remains unresolved; do not call a direct transition to circumvent the block.

6. After actual authorization, plan the implementation, owner, controlled environment, rollback/recovery prerequisites and acceptance criteria.

7. Implement only within the granted scope, preserve baseline evidence and produce verification tied to the resulting candidate and dirty tree.

8. Close or apply the request only through its supported authorized path and retrievable completion evidence. Update affected documents and training after approved changes.

## 5. Decisions, errors and stop conditions

- A blocked authority policy stops the decision and implementation authorization.

- A source test pass is not proof the change was applied in the operating environment.

## 6. Records and handoff

- Change request

- Impact assessment

- Version-bound approval evidence

- Implementation and verification

- Document/training updates

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/change-requests

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Related work instructions: QC-WI-038

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /change-requests

- /change-requests/new

- /change-requests/[changeRequestId]

- /change-requests/[changeRequestId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
