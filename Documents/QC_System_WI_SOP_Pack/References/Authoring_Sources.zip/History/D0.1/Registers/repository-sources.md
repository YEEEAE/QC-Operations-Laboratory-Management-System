# Repository source bindings

D0.1 | DRAFT FOR REVIEW | 2026-10-03

Repository references are bound to the recorded HEAD plus file or directory-manifest SHA-256. Source code behavior does not automatically establish approved policy.

## REPO-001

Path: Documents/AI-PROVIDERS.md

Sha256: a02664136e1346722509f94fb609b116e86e0d4cbd812be325774bbf55ba284a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-002

Path: Documents/BACKUP-RECOVERY-PLAN.md

Sha256: a9c6c0f1160fc4a320b541c24297cae1b36e56567b108551414816c2b5dbd520

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-003

Path: Documents/CONFIGURATION-REFERENCE.md

Sha256: 3d31c04dbfa293f6bd1fc5741132233ed23f6c3c20f8bbdfedb7e56e2774f5b2

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-004

Path: Documents/DATA-GOVERNANCE-REGISTER-032.md

Sha256: 3990b4116a12e6035c8d74a48d7ef05a771b4e91474904687d8fbe937cd87525

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-005

Path: Documents/DECISION-ASSUMPTION-REGISTER-026.md

Sha256: 5ddc0298c1f43dd6a159eabe242cd74a2c74d37266c1f185ac7a22993d26f069

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-006

Path: Documents/FIRST-DAY-OPERATING-CHECKLIST.md

Sha256: 7a0277411a8a16e51939a1e8484449706a2eca5e0f21445fe6032324c4e47958

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-007

Path: Documents/INCIDENT-PROBLEM-RUNBOOK.md

Sha256: 8e021c4d43a62b3d086eda1b1c58c8c2afcc6194a8efcc8ddfa18744fa3008dc

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-008

Path: Documents/LABORATORY-REPORT-TEMPLATES.md

Sha256: 6792ef32905ffd7fd1b22c1d732d77e28ef344f2e2c204f39bc6e5a064f440e8

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-009

Path: Documents/OWNER-DECISION-RBAC-2026-09-23.md

Sha256: fcdc993db20a7344bad4bf19d784a38abdea539b9223be7522f3f91b9f0ffa21

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-010

Path: Documents/QUALITY-POLICY-DECISION-PACK-2026-10-02.md

Sha256: 517518ce5285f3a5b3dc49a15fed1e53b00865684bf7b99ba01eecf3ed4a34f4

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-011

Path: Documents/REJECT-REPORTS.md

Sha256: 14f0d85d1d8ac14173fb27e49163ada5760539f9b93ed38d97244c6a89c95837

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-012

Path: Documents/RELEASE-RUNBOOK.md

Sha256: a3f948261ba13d48a6f899a27b0cba4fed792bd5c66a6f54fbebfe5419bc9128

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-013

Path: Documents/ROLE-MATRIX.md

Sha256: 200fa93f06d67268716cc103d5f7131ac9f0e3df135f037c0946de15aec1747f

Hash kind: file SHA-256

Revision: 1.0

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-014

Path: Documents/STATE-MACHINES.md

Sha256: 8575e4bbe3c787fb984cd8dc040271a16dcd868e466392aaa7035eb98812012a

Hash kind: file SHA-256

Revision: 1.0

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-015

Path: Documents/SYSTEM-INVARIANTS.md

Sha256: 8360117341ba77a6bb5b0ec2fc20c76256d3e10a67e9f076f2094f50529afd57

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-016

Path: src/modules/administration/application/assign-user-scope.ts

Sha256: 5dce13ffc975c8f818b53596fd8e7b3f3b2a527d2e12d99856555136136c82d5

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-017

Path: src/modules/administration/application/dependencies.ts

Sha256: 7dc3ad39dd18adfdc83df2a89d392b7e42aafc1fd9b2382d7d8fd59b49b23d39

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-018

Path: src/modules/administration/application/get-role.ts

Sha256: 40d1ae023557431315ed80d69aaaffef5dcb99ed5ad39b312eb1296833d865b3

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-019

Path: src/modules/administration/application/list-permissions.ts

Sha256: af990822f14ee68b2041fc7d961ebf812bfb7dc835e4a5a96385053d0ca09f8c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-020

Path: src/modules/administration/application/list-role-permissions.ts

Sha256: 5439b7333eaf39813ed5a784125ceac1986c949044f4573a5b81d9f5072b89e1

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-021

Path: src/modules/administration/application/list-roles.ts

Sha256: 725476b0bc8fbb7c7974346273fcf500e9d1011591a127c1d9d2845c16d85ce2

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-022

Path: src/modules/administration/application/list-user-roles.ts

Sha256: 2560ba17f1e3aa3b581ca0a261051ebcc38da6b29de4332d0184ce9bf4592131

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-023

Path: src/modules/administration/application/list-user-scopes.ts

Sha256: b5f80d57d31625a626976cc66cfe4090aa8d0c00e2f9f9526ee48ec7eedbe1de

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-024

Path: src/modules/administration/application/manage-user-role.ts

Sha256: 55790ed9676e0c9eb2635989136c10cb6d2547d0806045f9f57875b8a182f59e

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-025

Path: src/modules/administration/application/manage-user-scopes.ts

Sha256: e3186c80d28b6c9cfb0f07e5a0a3f27bf8b540780046e6ecd52806add7a2aa05

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-026

Path: src/modules/administration/application/remove-user-scope.ts

Sha256: b183247b54de1bb8a26c719a310fb9a84a6609293215ece00cafa2d7d90ab5ee

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-027

Path: src/modules/administration/application/update-role-permissions.ts

Sha256: 0727df194139acbe46f2fc941cdd90bfe671e31ff1b8225c7c0db88329b6b44a

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-028

Path: src/modules/ai-advisory

Sha256: c66ab84845d526ba865dc57f83cbf188592e6ccfab10cf15be7c7d0cca0a3c2e

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-029

Path: src/modules/ai-advisory/application/dependencies.ts

Sha256: 9c0551aa3a0ef52c6e283b4bc043f8c6aa9e4d0c7c34f3253f0707a599ee05fb

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-030

Path: src/modules/ai-advisory/application/get-advisory.ts

Sha256: fcff89690526d505b9d8053061d549f69aae8084af9d560b2ebd219f8d4f74c1

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-031

Path: src/modules/ai-advisory/application/page-availability.ts

Sha256: 232b4f76ae8f16d5b29911e8575f8200c54d6f561cfdc2c8fd2331b15d6017aa

Hash kind: file SHA-256

Revision: processingPolicy.consentVersion,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-032

Path: src/modules/approvals

Sha256: e5e202a6a99fa4d03369df0d68f4d35cb9450f6a45598f59696cc2207a8953da

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-033

Path: src/modules/approvals/application/authorization.ts

Sha256: 3ef406a6eedd4e639af025b9208c006fb9bd8ea3a2ddc109ab57e84fe25eac17

Hash kind: file SHA-256

Revision: record.workItem.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-034

Path: src/modules/approvals/application/decide-approval.ts

Sha256: 17c1ab99f3d4f64d82fd7ef880d0a0f16e17769f45f9f0e264512f1c4713b105

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-035

Path: src/modules/approvals/application/decision-capabilities.ts

Sha256: 686eccd51369d3783a80344792009179a007d13e790c87db25f5fba1a2e89ca9

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-036

Path: src/modules/approvals/application/dependencies.ts

Sha256: 7d1677fd93b5e6d11e115f8009e26b3c60bd0776baa0d76461efc6383b9c391f

Hash kind: file SHA-256

Revision: input.expectedVersion,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-037

Path: src/modules/approvals/application/document-approval-evidence.ts

Sha256: 929247fd4eb64d43fdbfae0629db5c11655197f0179ae129a40db2c1377079eb

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-038

Path: src/modules/approvals/application/get-approval.ts

Sha256: 753f925d895bb9283191bd18eddf0bdefc16711a35e72bb2b99ad28fec59b910

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-039

Path: src/modules/approvals/application/list-my-approvals.ts

Sha256: 65a5527fcd6cfbaa5e17b7ff080addef8e4864fcd8daeae455050eeda48a0281

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-040

Path: src/modules/assets/application/dependencies.ts

Sha256: 982d2c52310a9a159627e6b49fef67eb6e610afcb62c9d50f1d9f7498dcea9cb

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-041

Path: src/modules/assets/calibration/application/create-calibration.ts

Sha256: e64f30bcd7838258b3213a8b15ce3d7a564a110bcb4d6fa895bbabbf089f5f25

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-042

Path: src/modules/assets/calibration/application/get-calibration.ts

Sha256: 1d5db4e03b8c45e5336b469733fe9b532754a26cc52c9ecf893c6689b5ac71a4

Hash kind: file SHA-256

Revision: calibration.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-043

Path: src/modules/assets/calibration/application/list-calibrations.ts

Sha256: eeeec29ecb79c779f2091cc50e52ec2575c6257ed90e456b9e2be8a19352ad0d

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-044

Path: src/modules/assets/calibration/application/transition-calibration.ts

Sha256: e3af2f8756c750a5a3287b6b2a44ff9f38cce480c385a8b2e274fff23be66bfd

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-045

Path: src/modules/assets/calibration/domain/calibration.ts

Sha256: 42d2d65de04329b66b3ca7e4d587ac66affa469a50651ffc5d3ed7ebeba4c4f9

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-046

Path: src/modules/assets/equipment/application/create-equipment.ts

Sha256: 9fcee62feb880d947b965c3fcec0bec4883cde82f9577357d1d1bdd8f4f2cb34

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-047

Path: src/modules/assets/equipment/application/get-equipment-eligibility.ts

Sha256: 59e4c758e11f2f3e129d0fc124ae328274f74a2910c10885d1f4d9ea95eb9cda

Hash kind: file SHA-256

Revision: equipment.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-048

Path: src/modules/assets/equipment/application/get-equipment.ts

Sha256: 3268b00dc6024afb095caf473f4d506b7b611a7fd7254a9eca3b497d1c211d89

Hash kind: file SHA-256

Revision: equipment.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-049

Path: src/modules/assets/equipment/application/list-equipment.ts

Sha256: b3654a2de7afd31ab58059de847b9cfd93cae0eec5114e43982c5be944fdb55e

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-050

Path: src/modules/assets/equipment/application/update-equipment.ts

Sha256: 930b4a9671f9a9708757425bdb2cb64000396cdfc583ed47c6b826fa90544204

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-051

Path: src/modules/assets/equipment/domain/equipment.ts

Sha256: 832b857906206459c405575a79aa1f2f4ab6d172228cd812d6456ac1c4ddf190

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-052

Path: src/modules/assets/equipment/infrastructure/eligibility-reader.ts

Sha256: 7d4cad10a4bed16bf468f2e9979fe83bd1abcef18de72e63b0b1222fcb8ed895

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-053

Path: src/modules/assets/maintenance/application/create-maintenance.ts

Sha256: 4ee3a3068582ea45e3ff867572e1cfbf891e32edb4ddd35c60225378bcdae9da

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-054

Path: src/modules/assets/maintenance/application/get-maintenance.ts

Sha256: 56dfa5abcb3f8c7a709fdd56efc77ba9cd5a250561670f683b7c2f6e3cfe5ba1

Hash kind: file SHA-256

Revision: maintenance.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-055

Path: src/modules/assets/maintenance/application/list-maintenance.ts

Sha256: c81ff33ff175c08161d7efd6445d88647067a7188c3a47bde118dc9be34d92e0

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-056

Path: src/modules/assets/maintenance/application/transition-maintenance.ts

Sha256: d6cdd21a06963351447caaa122b16a92ebc08a30db2345e29bc5c543643e5122

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-057

Path: src/modules/assets/maintenance/domain/maintenance.ts

Sha256: 5754536cc352f2e951d27c81a32a06662a62ed79ea542eee610373c69588d289

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-058

Path: src/modules/backup-recovery

Sha256: cb21683c7190c554b172b28b2d1395f3dcb8418b03c3b6435ddc86c20365c823

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-059

Path: src/modules/backup-recovery/application/dependencies.ts

Sha256: 96396c6954ede4926774ca99ad89f5c1ee819d98b0959cef84c1067eece723ff

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-060

Path: src/modules/backup-recovery/application/get-backup.ts

Sha256: 6f4d94690efb1bb2c16bd713de8630e7914ec522ccd0bdd4da7c47819902108e

Hash kind: file SHA-256

Revision: string;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-061

Path: src/modules/backup-recovery/application/list-backups.ts

Sha256: 04ccb9fedf78c3dd6b97b3f92b54e5aa1e877b842d64868088a452dea91725bf

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-062

Path: src/modules/backup-recovery/application/production-recovery-authorization.ts

Sha256: 3bbd607b25de461618493212db93d55f1fbe44c7d37f425d27a57a080c15418e

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-063

Path: src/modules/backup-recovery/application/request-restore.ts

Sha256: 86975161b640586aa516ce3b5df7fa00c729ce30162bb8b23a3367880441e1bf

Hash kind: file SHA-256

Revision: string;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-064

Path: src/modules/backup-recovery/application/retention.ts

Sha256: 00288d904730432785de78b1c9a3aac8251b50951b0f3a4315ba9e7e1403b6f2

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-065

Path: src/modules/backup-recovery/application/run-backup-job.ts

Sha256: 719c5b6977b45cc4c726eb500080c79d3cd7da77abd439366b3d4cba5d416621

Hash kind: file SHA-256

Revision: execution.postgresVersion || input.release.postgresVersion,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-066

Path: src/modules/backup-recovery/application/schedule-backup-recovery.ts

Sha256: 2402b3e20e0664b54d6f0a62fd585e6b0e6334f0f78343ebea2c02dcd050b809

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-067

Path: src/modules/backup-recovery/application/validate-restore-request.ts

Sha256: 21956206f241bdd24dc72f8deca68610d554c006f216497389d4478ade9f6e88

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-068

Path: src/modules/change-requests

Sha256: b91773e5f1b673162c372fb49fee8c09b6d1a6949a907a724edf7eaa29702c41

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-069

Path: src/modules/change-requests/application/authorization.ts

Sha256: c8522a338c94e8ad27e981e7cd906496122759a03295e8e29dd4649689b9cca1

Hash kind: file SHA-256

Revision: request.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-070

Path: src/modules/change-requests/application/change-target-vocabulary.ts

Sha256: a5a8e3af75e6b42db58851443f5b04f4deef90318b6546720df1e67cfb30c669

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-071

Path: src/modules/change-requests/application/create-change-request.ts

Sha256: 7989cd8969dbdb1329ab389ac3f9f83fa183cee83a36f53392287153f3d29702

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-072

Path: src/modules/change-requests/application/create-document-version-change-request.ts

Sha256: 857524f93cd24cd8cb8d40159f7609a09bb941f0d8c96da3c2bc47c0cd6f0444

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-073

Path: src/modules/change-requests/application/dependencies.ts

Sha256: 90ef9547ff711abb715ae48bb567136fbd7b58ce8574a1364a36c8eda3c8f316

Hash kind: file SHA-256

Revision: new CreateDocumentVersionChangeRequestUseCase(

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-074

Path: src/modules/change-requests/application/document-version-change-fields.ts

Sha256: 084d25703ebbd0942e410b4b98d9fa0e222ae13452aba5381b2de2bd6f9d383f

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-075

Path: src/modules/change-requests/application/get-change-request.ts

Sha256: c37643460ad6fcab8b0f6e2501cdd0e1750a278e706b6cfd5ad5228c33fe3561

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-076

Path: src/modules/change-requests/application/list-change-requests.ts

Sha256: e90d5e8b1da9433130162315c170dafd3dd68ada1c67d065cdfd46e8741d0577

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-077

Path: src/modules/change-requests/application/transition-change-request.ts

Sha256: ccca83a5751888d418bf1cfa304fb28b9362971aca010b624774b54fb8b324db

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-078

Path: src/modules/dashboard

Sha256: 5517f0951a21d3f85a64ad1317fd452e7e8a3fc34524b0351fb0d5e0b8f7a452

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-079

Path: src/modules/dashboard/application/dashboard-attention.ts

Sha256: dbef423bba23530aa93f4379ac6de708d70193997e2ef9e21656b6d79bdd8c71

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-080

Path: src/modules/dashboard/application/dashboard-empty.ts

Sha256: e657ce0672d27c0a5ed8dd35c1136693935826fe7ac4db73ad1478a24c2bdd07

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-081

Path: src/modules/dashboard/application/dashboard-flow.ts

Sha256: d21d327ce49cb782d1b4b8fbd2e0629a9def4d3be7b7bbab6fc08de2fc9993c0

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-082

Path: src/modules/dashboard/application/dashboard-presentation.ts

Sha256: 04be5930a391c43bbea8a3099e9159899cb20aef47b5f60767f91648a1abbab9

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-083

Path: src/modules/dashboard/application/dashboard-series.ts

Sha256: 3597fb36e20e8702d5fa31e09167d7cbb080f1bc05ad096790ab832bafb3784c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-084

Path: src/modules/dashboard/application/dashboard-sources.ts

Sha256: 62164db6713b93d79c32501170c64d44b2e486d8c083ecac6e85fd2c8e32ff19

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-085

Path: src/modules/dashboard/application/dependencies.ts

Sha256: ccccc1cff7408a3e30b2609fbd648940a401ed7daf425605304339f1340d052d

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-086

Path: src/modules/dashboard/application/get-dashboard.ts

Sha256: f85d7978cbc075d8dbb8ae52eb3c85711e784d1c04b7ea00877ed663b7f575d3

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-087

Path: src/modules/dashboard/application/get-my-work.ts

Sha256: 11a9304ee1295e631c75765f655b356852a0bd441ae75b22b7b647f5219faa51

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-088

Path: src/modules/dashboard/application/my-work-definitions.ts

Sha256: a103a9251b7853bdde41565638c746a40bd8bd141f47cd0299d9733a432badc2

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-089

Path: src/modules/dashboard/application/my-work-queue.ts

Sha256: 1031d52400131e414a11adfc0a162934306690f7f0c92819e0af4443ba89832b

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-090

Path: src/modules/documents

Sha256: accba1517ff3a84bfb90d5dcade24f06bef54d4f9c3e676d657c24a6ee97c7ca

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-091

Path: src/modules/documents/application/approve-version.ts

Sha256: f539d0070e5684676867177594e8bfc1ebc239e235b86c28c5678e1014acfcf1

Hash kind: file SHA-256

Revision: bigint; requestId: string; transaction?: DatabaseTransaction }): Promise<never> {

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-092

Path: src/modules/documents/application/authorization.ts

Sha256: 047fe3283d58610386e024cf42a010f23fc5b7b4794f0d8d1ab6450616fe5bce

Hash kind: file SHA-256

Revision: version?.version ?? input.document.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-093

Path: src/modules/documents/application/create-document.ts

Sha256: 9d534de3aa8b662ab7836c6a7574a7d4c3bca3070c440dae53a376275ea98404

Hash kind: file SHA-256

Revision: 1n, expectedVersion: 1n, businessCondition: true }, { throwOnDeny: true });

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-094

Path: src/modules/documents/application/create-version.ts

Sha256: 78a71f5e361ef646e339d642dd3672304aacbff71ecc5a0b7a000d29245dafe5

Hash kind: file SHA-256

Revision: bigint; expectedPredecessor: ReturnType<typeof expectedPredecessorOf>; requestId: string }) {

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-095

Path: src/modules/documents/application/dependencies.ts

Sha256: 25eadb1cb0eee2ece90768a5e8fdba458eec6866359dedb5ea510fd3029d76ee

Hash kind: file SHA-256

Revision: new CreateVersionUseCase(repository),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-096

Path: src/modules/documents/application/document-vocabulary.ts

Sha256: 91a7e747f6feb6b5f93f359f52b02ed2091547fa094a8cb564e531a3fc0f9c8b

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-097

Path: src/modules/documents/application/get-document.ts

Sha256: e6af18f31f1213b0c4102e33d1d028baea8f05236f8cc05d905a05bb16cb238a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-098

Path: src/modules/documents/application/list-documents.ts

Sha256: f4bffc20a08612b403852fa0bde1837bd82ef5ee93e6c183df6ccd63954f6e61

Hash kind: file SHA-256

Revision: 1n, expectedVersion: 1n, businessCondition: true }, { throwOnDeny: true });

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-099

Path: src/modules/documents/application/list-review-queue.ts

Sha256: 98e169b68d8660e9580144f12a33a3dd2471bfb1b9ad88e9358d1e5f01e448d7

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-100

Path: src/modules/documents/application/list-source-files.ts

Sha256: bbe8214fa50b659b5bfbb2aa900dbaf73b7e22b0a52ac9f75185d25b024d8447

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-101

Path: src/modules/documents/application/review-version.ts

Sha256: e2aed456929618a2f25a7eb2d18b0ae81e12ed85f119c67a0aaeabd7abcd3f27

Hash kind: file SHA-256

Revision: bigint; requestId: string }) {

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-102

Path: src/modules/documents/application/submit-version.ts

Sha256: 5c71e11a979add78b797f85fc54bf4555d64595e0280a9c72375a3f9637ccc20

Hash kind: file SHA-256

Revision: bigint; requestId: string }) {

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-103

Path: src/modules/documents/application/supersede-version.ts

Sha256: 15570c32763bb19de09eb13d31166e3ea557c955152e8782092d6de9cda6a526

Hash kind: file SHA-256

Revision: bigint; replacementVersionId: string; replacementExpectedVersion: bigint; effectiveAt?: Date; requestId: string }) {

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-104

Path: src/modules/documents/application/update-version-draft.ts

Sha256: c3e12835cf8049faebbeda19731cb3e36fc8c0d67e3ab75640f60e01dfb62545

Hash kind: file SHA-256

Revision: bigint; expectedContentHash: string; revision: string; changeSummary?: string; requestId: string }) {

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-105

Path: src/modules/documents/application/void-version.ts

Sha256: 2cf9a8931738a870b3d8983a63409348043589ff0e93f586d4e4f87da45d301a

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-106

Path: src/modules/documents/domain/document-state.ts

Sha256: 023ca9d8311e484aa1d557a7a54e63b4b5793919b01a34fdad6c8615de4a36cb

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-107

Path: src/modules/e-signatures/application/final-approval-ceremony.ts

Sha256: be376b0899a926b91e31d1d5395088d8295a16143d9bc89d1bee512ef44670d1

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-108

Path: src/modules/e-signatures/application/reauthentication-verifier.ts

Sha256: 5e66f0604fe5380b484a0167d5431912b15b99ddb599bf98f035f713b08e5f44

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-109

Path: src/modules/e-signatures/application/sign-controlled-action.ts

Sha256: 5fbc47bfeccd2fe577412364c480d114c93a675d78ac0ba9a105f34a4babb78c

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-110

Path: src/modules/identity

Sha256: b92d8b285068b3080f41a69de889ba4ad066dfcdce76ad26fb573a02856b7d6f

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-111

Path: src/modules/identity/application/activate-user.ts

Sha256: 6432a2a26849ea83fcdd2a1752275f9bc1b12a5dbe37a9336f17dd1718651d06

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-112

Path: src/modules/identity/application/admin-dependencies.ts

Sha256: 8aacc1bb452372e3cede2bbc9294a2d5cb7ca3d8a6964a0d98f00c2b3e53080a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-113

Path: src/modules/identity/application/admin-reset-password.ts

Sha256: 53adbc76d655cc1b3f0f40aea7c7a00eaf61b4f6150048248aabe0ed0f6a1768

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-114

Path: src/modules/identity/application/bootstrap-admin-check.ts

Sha256: 7719c591299e9c2be010969d079a3c9f42e4e4e62975970cdf0a0b6cbc87b408

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-115

Path: src/modules/identity/application/bootstrap-initial-admin.ts

Sha256: aa2d3b922a9eda7ee54181d55cbf54485b421122d570d92c4c5ef31c9b5681c4

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-116

Path: src/modules/identity/application/change-password.ts

Sha256: b17c4e762e34dd0fdfee1706495c27a5dfdcb555fcd7e331540842e20c27bdb6

Hash kind: file SHA-256

Revision: user.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-117

Path: src/modules/identity/application/create-user.ts

Sha256: 7c13fc0064fc76e11d2d1857632be93e2142b56530358d8489053efb4819f943

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-118

Path: src/modules/identity/application/disable-user.ts

Sha256: 493930004ff194ea437c11affc39a7d2068be0c5d1c8d130c7dc9679f4eadd16

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-119

Path: src/modules/identity/application/get-account.ts

Sha256: 6dcf8f04b0880b7f5246f7da56aab5c030cc5f5fd2de1470c240707a26c31abc

Hash kind: file SHA-256

Revision: user.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-120

Path: src/modules/identity/application/get-user.ts

Sha256: a1c90eed1c6596d16cf4802f006f8d6b312fd495824358b725c5974ab0233bf3

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-121

Path: src/modules/identity/application/identity-dependencies.ts

Sha256: 588fe01ab1e36a1c0632f967f6ad4c6ee54fea025f07fd26338fe0818e322c04

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-122

Path: src/modules/identity/application/list-users.ts

Sha256: 93216262749d5aacacbf049dbd8fc3d5447a5434cc9650627502a53775c34998

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-123

Path: src/modules/identity/application/login.ts

Sha256: babd749613dd5db8a6f147632c1bbc72ea31c01d9b914dac3e5cf8f75bd1fdfa

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-124

Path: src/modules/identity/application/logout.ts

Sha256: cce89e2476c60ef24a145fd93fd0a659a18729c1d8058186560b459d5136a8f5

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-125

Path: src/modules/identity/application/resolve-session.ts

Sha256: e64b0882a100e1b6a6c2f34c5863b84e79905ba71ae6f14de0544ab34a3ab91e

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-126

Path: src/modules/identity/application/revoke-user-sessions.ts

Sha256: 2e6b7372dc89010e2fe8315aabcea6a797e6af847b4fb431912f8af077e4ee37

Hash kind: file SHA-256

Revision: target.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-127

Path: src/modules/identity/application/safe-user-view.ts

Sha256: 2b9b8a292cae0805273285b01a8dc5645496667676422c3fdc693e5b49a63264

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-128

Path: src/modules/identity/application/session-service.ts

Sha256: 592cd1eb0e167cf0cc3d954247c2885b733341f617b9eef36a8213efc8ae2826

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-129

Path: src/modules/identity/application/update-user.ts

Sha256: e37833e89c0e0566511d52adb55e4dd049a06f627c880b4ebb8518f8fccc7b04

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-130

Path: src/modules/laboratory/application/approve-lab-test.ts

Sha256: 7e5b578b0fa7fa2f2078d4bdc42729a962e29c79234d2d1c268acbc0a278765b

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-131

Path: src/modules/laboratory/application/create-lab-test.ts

Sha256: 1be00f4cc442f60b1bce9a36701f188aa15b7bea760ed2288446d43390a9d064

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-132

Path: src/modules/laboratory/application/create-retest.ts

Sha256: 226ae7742440fca5639cb01dacda9ad3544cc4b482c1d500e88eeb291f230b7d

Hash kind: file SHA-256

Revision: original.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-133

Path: src/modules/laboratory/application/dependencies.ts

Sha256: a5873e232719af2c05d5908436998c914428cbfb09e27dd2720efcfaf921536d

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-134

Path: src/modules/laboratory/application/final-approve-lab-test.ts

Sha256: aaef5e646bb40019475c9589b7ddcf7162895a2e61f100735acb1f4c180e4669

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-135

Path: src/modules/laboratory/application/get-lab-test.ts

Sha256: 35a569f2dfd4365b08d22566ea9f7248afd66a52f62b034383b00bbe255c5f0a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-136

Path: src/modules/laboratory/application/get-lab-workload.ts

Sha256: d7b7d87ce13860f489110c8b1d66806e94d9c657ef87ca202b3fd37cd77ec847

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-137

Path: src/modules/laboratory/application/get-source-receiving.ts

Sha256: acf232a83bf93b04bac3438e14a01782f0c7bb279c5905c87534679657cf7a05

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-138

Path: src/modules/laboratory/application/lab-authorization.ts

Sha256: 16c9492a3ccb5ec429bdc3821db53bbfdece98bbc2f73df101df6b1c9fae95ad

Hash kind: file SHA-256

Revision: bigint,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-139

Path: src/modules/laboratory/application/lab-presentation.ts

Sha256: 612f2f03abb22a43749ab3fbcee95c837d7806db7a424373f7e287f52d9798be

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-140

Path: src/modules/laboratory/application/list-approved-templates.ts

Sha256: 6248f3f113a61136643b64d2f4143c852eaa7613dcf18a56712933668e06d9d7

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-141

Path: src/modules/laboratory/application/list-lab-tests.ts

Sha256: 49b4032026d4563dfdc3727389058bbc4ceba3303f67752d6ce99863400241c4

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-142

Path: src/modules/laboratory/application/record-lab-run.ts

Sha256: 24c56f3d7381f0ee697d67aba5690b5d29b3fcbdc01fb2dd51b5c7c31cfbae91

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-143

Path: src/modules/laboratory/application/record-run-equipment.ts

Sha256: 60c7ac597d06bac81900eca830834f61745a7d719c111579327b3c55b91143fe

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-144

Path: src/modules/laboratory/application/reject-lab-test.ts

Sha256: 2e45b256324aff3b7d998ee0019f4c7c7a8466c6f56ca01d49238dfc0e538fc7

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-145

Path: src/modules/laboratory/application/reopen-lab-test.ts

Sha256: ecf6dbb245a9022f360717ce67494bd22d890132d64fc7488ca3a443ba93e2a2

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-146

Path: src/modules/laboratory/application/report-drafts.ts

Sha256: 231351b8d145976f0ed871914bbbe19135d53460030b758a9df594464cc652fa

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-147

Path: src/modules/laboratory/application/report-template-form.ts

Sha256: c0de119da56f2427939aa5a9254b9bc916102536757387d60a9a4f56e4ce1e5c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-148

Path: src/modules/laboratory/application/resume-lab-test.ts

Sha256: 6f7fc807d1fec095ad034a58df6b42b10502d68fcbd74c0b5b39496b4fe9c8e0

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-149

Path: src/modules/laboratory/application/return-lab-test.ts

Sha256: 9cb6511c3d127e6ff6f18e012a8a161df01a31ba821c9c3e06bdddf47b936460

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-150

Path: src/modules/laboratory/application/review-lab-test.ts

Sha256: 8dd59726baaaa7fc0c579e3fc11b2081e7bf21e4f5998912ef7608a07061c058

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-151

Path: src/modules/laboratory/application/save-measurements.ts

Sha256: efebc64eb52cc2b5ad368ef1d63b4c4f559e3d0d8b0a3f5b3602eaaaf2137fbb

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-152

Path: src/modules/laboratory/application/submit-lab-test.ts

Sha256: 14101353b5fb9c71fed54167ec11ea7b0db7477c689a1c0ccfb988f0ef31c734

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-153

Path: src/modules/laboratory/domain/lab-state.ts

Sha256: caaf1985683ea79e2a7915513930f6e2970b5ec78596f843faf31b47e8921fa7

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-154

Path: src/modules/laboratory/domain/lab-test.ts

Sha256: ec44f9e710a9dc2adf6deeeaf31fe379cff32bb75b9444ab95f98293cdfc49b6

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-155

Path: src/modules/laboratory/domain/measurement.ts

Sha256: ca12bd9437e47cef8614faa5842189c9836a868495c3c610832b57216aee8fb9

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-156

Path: src/modules/quality/application/get-quality-overview.ts

Sha256: e4c90738acedd2f45e6a11ed8d612b2bcdceba0d99bbca69d590bb4d525ddf60

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-157

Path: src/modules/quality/capa/application/close-capa.ts

Sha256: 3f6ca4ddd0d1c9dcf4ea1d43a12dbeca20fa0f3e14f6b6ef616ff8109ae7ed73

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-158

Path: src/modules/quality/capa/application/create-capa.ts

Sha256: ad36c255b201db72b89565746857c16f3be93938be1446ac8e31aa381474fb5f

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-159

Path: src/modules/quality/capa/application/dependencies.ts

Sha256: 277cbe27695747dde481e0a9bd946e98275e83ecfbaf7a8fd97c91986c45b1a4

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-160

Path: src/modules/quality/capa/application/get-capa.ts

Sha256: 2b11ac6483ef2f37d07c8fdbf380e6ae249ff138b2d1c9e2ffcc75001338c1de

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-161

Path: src/modules/quality/capa/application/list-capa.ts

Sha256: a4b3d2f4a4e7b3da93c296b90124ad0e8f568bdb10279660f6f7252782cc12cd

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-162

Path: src/modules/quality/capa/application/related-ncrs.ts

Sha256: 39b4a7b4bb4db05af3860ecd48f3f3a5407ae84f9a19aab410e54c775cd5cc19

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-163

Path: src/modules/quality/capa/application/transition-capa.ts

Sha256: 2f1c5fe71af356e4c99a6818f6d71caacc730fd9ee5d1cec5deade4a1c9864e0

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-164

Path: src/modules/quality/capa/domain/capa.ts

Sha256: 2a367db9c863161c3077e501de6ab5cdef3f52682e6422dd791b1a4807955b89

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-165

Path: src/modules/quality/findings/application/create-finding.ts

Sha256: d5ad2f7a67f725ad1b59531976aa95e90c51e0ecd30e191d3160e7f2c3c282d3

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-166

Path: src/modules/quality/findings/application/dependencies.ts

Sha256: ef6c6e9e6f41c2e2d943298f269407d56ee92aaf83b5ce829def8ab345954e63

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-167

Path: src/modules/quality/findings/application/get-finding.ts

Sha256: 20dc3aee455b4190b2382a5ffaa5c0110fb3b7ea107271b256db2f67a7b945de

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-168

Path: src/modules/quality/findings/application/list-findings-for-actor.ts

Sha256: 43d0ed8b4809ea871e56dfd7dabc358909b20ba61d3d126e9632c55ec021efc0

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-169

Path: src/modules/quality/findings/application/list-findings.ts

Sha256: 358a290b9dd6207488d01bf680cbdce96033db8f7c67348085b1f85371a10f01

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-170

Path: src/modules/quality/findings/application/list-related-ncrs.ts

Sha256: 3d81d06c8e07ba872fbc121665c368e464c6d884eaea59582fe31f844328f7fd

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-171

Path: src/modules/quality/findings/application/transition-finding.ts

Sha256: 35997af1d666c2f99d3dbfaa14fd67af381095a0e0ea5600039d74cd205a4adb

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-172

Path: src/modules/quality/findings/domain/finding.ts

Sha256: b4b5faa7268cf03afa49474cc20842fe38b670ef404178daa8cd9e01f403b664

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-173

Path: src/modules/quality/ncr/application/create-ncr.ts

Sha256: 7b51036950e8262bc393a74b2147bd7e94f5190e608bc5e6d2ce6f601b11833d

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-174

Path: src/modules/quality/ncr/application/dependencies.ts

Sha256: 69b88660019bd19c1b8390a350173d547eb5fa4b67f1092fd793929d5c1d165d

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-175

Path: src/modules/quality/ncr/application/get-ncr.ts

Sha256: 0d7d96f0c1bd7ba7685b974f5a4e7f300b24889986616552069baa2de2369850

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-176

Path: src/modules/quality/ncr/application/list-ncr.ts

Sha256: 48d3a101b2bb716452718d3db86e15ab4c546ece9ded413550cd0942eb1275e9

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-177

Path: src/modules/quality/ncr/application/transition-ncr.ts

Sha256: 9ffef688d5e52040ce821c5f088b973c150f2aa5278a384d43e479df4d8b3130

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-178

Path: src/modules/quality/ncr/domain/ncr.ts

Sha256: 13d82271f4f61dddf8dbab21821598d875ca7497f67cbaab3715b3b9a3b2ba73

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-179

Path: src/modules/quality/rca/application/dependencies.ts

Sha256: b480f20ecf70824be0c159a7b747f8b01b8e5a03125c196d607befa6294ce358

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-180

Path: src/modules/quality/rca/application/get-rca.ts

Sha256: 4c1e73f014c2a7f9e5fc1d93f68d3c8855e1d659e76ecc7df8668a23361280a0

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-181

Path: src/modules/quality/rca/application/list-rca.ts

Sha256: 6b0cbd9498564c12dbbb66b6e9ac5ad8e720915cccbda76ad991e1212ff3335e

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-182

Path: src/modules/quality/rca/application/transition-rca.ts

Sha256: 7a4574c0b6afc0a43ba82d54bfd69120dfb6c2c07889c201815285e42522e674

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-183

Path: src/modules/quality/rca/application/update-rca.ts

Sha256: bc6e80b69b3a43324aa4ee1a8d707ffeadd58ae15b2dfb4672deed5ae18fc2b2

Hash kind: file SHA-256

Revision: r.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-184

Path: src/modules/quality/rca/domain/rca.ts

Sha256: d01034d1f2ef0f96b14f1b96e6cc513c85444332aa483732c7cdc2bd69faeae1

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-185

Path: src/modules/quarantine/application/dependencies.ts

Sha256: 681c28bd5da5f9b2d3769df23a749a97629ad4971841a4ec2989f4d7e44020c6

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-186

Path: src/modules/quarantine/application/get-quarantine-admin.ts

Sha256: ebcece38f1093422f830e9e52633b6e3fe1fa5e14bae245d333defcb6a17610d

Hash kind: file SHA-256

Revision: string | null;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-187

Path: src/modules/quarantine/application/get-quarantine-overview.ts

Sha256: 96438d20f78960307cf205ca579514f62921bc9a0717d94c3af1097b2d11190f

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-188

Path: src/modules/quarantine/application/get-receiving-trend.ts

Sha256: 9d83e347d19e2f02691a2bd180c78bf02b50510c701a3690bc892cf7a882a3dd

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-189

Path: src/modules/quarantine/inspection/application/approve-inspection.ts

Sha256: 6d77cbc8008fafdd748327f825e061c0f60d8a578084f1dc315dd2ea7af9ed2a

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-190

Path: src/modules/quarantine/inspection/application/final-approve-inspection.ts

Sha256: 3118fc4a985972dca83926b9814c087d1526cd17efa3b970644bec6f65e5c8aa

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-191

Path: src/modules/quarantine/inspection/application/get-inspection.ts

Sha256: d6bbf61bbbf7923d0ac30747b2076ae0c4c0b5ae203a88b2ef70eeb297ca921a

Hash kind: file SHA-256

Revision: x.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-192

Path: src/modules/quarantine/inspection/application/inspection-aql-equipment.ts

Sha256: 59aff6b1700a89298919e432fc2d0cf147a0d50df38cdc37215a5af802ec125a

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-193

Path: src/modules/quarantine/inspection/application/inspection-equipment.ts

Sha256: 6cd56ffe6a7d4c94ad8a5671d0852289122b82c853d62f7c048f86c8fe4a1107

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-194

Path: src/modules/quarantine/inspection/application/inspection-result-options.ts

Sha256: 9211287293b8d1b8efa0a18503a043b08fc010e670ae966dc0e437b5585fcdef

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-195

Path: src/modules/quarantine/inspection/application/list-inspections.ts

Sha256: 797a4ac31bdc7ef95808caa18fd9fbdd4db998c22227e712a78008524fcc1fd0

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-196

Path: src/modules/quarantine/inspection/application/record-inspection-results.ts

Sha256: 76580bc1c6955cc5cfdfc39b9c4002b33a30d1b14153f8f990f3af07426cf9f6

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-197

Path: src/modules/quarantine/inspection/application/reject-inspection.ts

Sha256: f236ed0b8e23f91d809766ed2c879f4adb49f5eda02d77e8a536d7e45badbaab

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-198

Path: src/modules/quarantine/inspection/application/reopen-inspection.ts

Sha256: 823558d206efcb20a3fb9c130103d22113d3d65c13343a921631a0e26a0ade32

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-199

Path: src/modules/quarantine/inspection/application/resolve-inspection-template.ts

Sha256: a8c08ef4d9538510b46fa575fee9afa8d23e49db9d68877dfb3fc04f4ef94047

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-200

Path: src/modules/quarantine/inspection/application/resume-inspection.ts

Sha256: d654169d1397495482de50a9abf03d1f9007881d5adf43cfc86579601ff5085a

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-201

Path: src/modules/quarantine/inspection/application/return-inspection.ts

Sha256: f2333477d438efed257e51f904a62f4ff5072874816205a3a0c522f501aa3aa2

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-202

Path: src/modules/quarantine/inspection/application/review-inspection.ts

Sha256: bc2c0ab19c88f55f0bf1d0b17b2e7dc7d6edcc7ecbcc1f1332dcd510fed8b13b

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-203

Path: src/modules/quarantine/inspection/application/save-inspection-draft.ts

Sha256: 662d06e08b4c14ea1c734170dad2433616d5b546096712b4f81d1574d166bd98

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-204

Path: src/modules/quarantine/inspection/application/start-inspection.ts

Sha256: d1b62fa4762369b3a6b9d0193e74951b44db8cba90e197feb42be2527cbb3e70

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-205

Path: src/modules/quarantine/inspection/application/submit-inspection.ts

Sha256: dc0891fc8145b6411d564ac98bbefbec2137d507177ff77be346662405813983

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-206

Path: src/modules/quarantine/inspection/application/void-inspection.ts

Sha256: b662cea708a1685789fda1ecb72441f6ba350477a444bc6428d4528faf497540

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-207

Path: src/modules/quarantine/inspection/domain/inspection-state.ts

Sha256: eb92ba6907fc91dc09b3fabdc0d5e9aabb6aa31a18161492e1d08b24fb85c719

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-208

Path: src/modules/quarantine/receiving/application/correct-receiving.ts

Sha256: 70cf22f9ac341777b35cb95fc3dba7a4a8e0b3a49354e9289b75cb008ac1773a

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-209

Path: src/modules/quarantine/receiving/application/create-inspection-from-receiving.ts

Sha256: c21363a0a6b76fb34eb85caeee1c0c5582c9bc10ed89e765b5239fade8d18c59

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-210

Path: src/modules/quarantine/receiving/application/create-receiving.ts

Sha256: ef68b2839814b6293f797a334ff87160dd7d4ebf2daee93cdc2b7d54d516b585

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-211

Path: src/modules/quarantine/receiving/application/get-receiving.ts

Sha256: 407aacfa2c7add73779837df6b1f70bd42c2bee9706126a3e0d5be9f29b823b2

Hash kind: file SHA-256

Revision: x.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-212

Path: src/modules/quarantine/receiving/application/hold-receiving.ts

Sha256: 81131e7c1b05e15dbac4a233dc0f555caab3de3bfbfa6771a8a4ec3876907b0a

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-213

Path: src/modules/quarantine/receiving/application/list-receiving.ts

Sha256: 4ec8e5f317830d85bcf32c39d39fc16a894fb0a9633c5b77b8d9e20e2df23dff

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-214

Path: src/modules/quarantine/receiving/application/presentation.ts

Sha256: d9d98a4cf32b9d2f59360c804a7eaef52c18aee7a11529162154dbe240552775

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-215

Path: src/modules/quarantine/receiving/application/receiving-filters.ts

Sha256: 39f717ca04d2eb8320b106870cd5875145b6e4fb59aad96a9d80025fded69dc2

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-216

Path: src/modules/quarantine/receiving/application/release-receiving.ts

Sha256: 30714f44c08aed7aa1794b796220168d25874014484f89edbce342b6de956555

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-217

Path: src/modules/quarantine/receiving/application/transition-receiving.ts

Sha256: da956764bcd332c32ef3af10fc3fa114c262813b0f3f05e0dc93f3526cdfcede

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-218

Path: src/modules/quarantine/receiving/application/update-receiving-draft.ts

Sha256: 5a60ceb480079ef910126d4e06c37f65917d61f1fe2e52559c089d66cd7e479b

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-219

Path: src/modules/quarantine/receiving/domain/receiving-item.ts

Sha256: 86ae5841312fa48114c8c96671ae2378a9ed4eabbbd04577a9b3bf3306c896d9

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-220

Path: src/modules/quarantine/receiving/domain/receiving-state.ts

Sha256: 52a39641f94d249f1b85af3d1e406a27bf48729630058a6615efd90ca1bbb307

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-221

Path: src/modules/quarantine/templates

Sha256: ec63eef2d80a8c28738076a40bf68f4b1855f66158e201cc202d94894182fa6e

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-222

Path: src/modules/quarantine/templates/application/create-template.ts

Sha256: fd7bfdd22e8c4e6abeb4dba494d2ba944436b78a38f4109702723908d71fbfcd

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-223

Path: src/modules/quarantine/templates/application/dependencies.ts

Sha256: b6c005c173050731b9be0da4166f232d988fd18646784fb26e3be9c2bc646686

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-224

Path: src/modules/quarantine/templates/application/lifecycle.ts

Sha256: e039b278526d0e1e6f0bc6140d232cbb29441d78382d4a66760fdedeb275da8b

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-225

Path: src/modules/quarantine/templates/application/revise-and-read.ts

Sha256: 766bf7c2f205c83859ca7a69f115fb55068ef4ea707e4ea7e826f50bc9522ae0

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-226

Path: src/modules/quarantine/templates/application/template-authority.ts

Sha256: 215c2e5b85c7e48d661f2588db17d45c521064ce0775d7c35ac47f0723738422

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-227

Path: src/modules/quarantine/templates/application/template-ceremony.ts

Sha256: f1c4a5be3e935b70d793d96ccdb4e4d9a53fa9a8a5b684db0fe39042ad97d7fc

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-228

Path: src/modules/quarantine/templates/domain/template-state.ts

Sha256: fa872e0d546589be174d2e0b593143bf804f8cd9ec6f738e253817a1f4f5b476

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-229

Path: src/modules/reject-reports/application/append-daily-reject-entry.ts

Sha256: ce72d17a8f9af5722b42cee964003920f93390200c886482d341e6deae5bb8c1

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-230

Path: src/modules/reject-reports/application/confirm-issue-slip-approval.ts

Sha256: 0d58d11934590a011b7569735dcb3556245f9194f092748596434032e446e23e

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-231

Path: src/modules/reject-reports/application/create-daily-reject.ts

Sha256: 8cb52f68e063757f493eaec9c716e78275c2443fdde2d6085252a0a0d494bf96

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-232

Path: src/modules/reject-reports/application/create-issue-slip.ts

Sha256: ff295880426eae8192de726c2023a277166cae9bb2f03f90b5afb04e90c90cc5

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-233

Path: src/modules/reject-reports/application/dependencies.ts

Sha256: 3d0117f104ea325db2133dc8a55a05fde09d0909a464bab064d885c2851757c5

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-234

Path: src/modules/reject-reports/application/finalize-daily-reject.ts

Sha256: 872961174af154f650d0320097bf5b217e98620dadd450a3f4613ea8fc36e2b7

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-235

Path: src/modules/reject-reports/application/get-daily-reject.ts

Sha256: 2f1eaec615c59daa763ece0a7f40de86d51e18a2108e08e61bab8e8ae67efd16

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-236

Path: src/modules/reject-reports/application/get-issue-slip.ts

Sha256: 9bc4259109314df72c787e29b7858c0db0577ba5075859d53ecfd35ca1c76893

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-237

Path: src/modules/reject-reports/application/get-reject-dashboard.ts

Sha256: ae4ebc829c280ba517e5e9e1c2401c8c83c47e658a2b9b2f7cfb68e13dd324f0

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-238

Path: src/modules/reject-reports/application/get-reject-report-availability.ts

Sha256: 784166bcc4dfd759565a5fd46de78c8c7843fb93ceff9db48502eed690a43cd5

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-239

Path: src/modules/reject-reports/application/issue-issue-slip.ts

Sha256: bcfac396d42fc0660c33864a7f457b649cfa2ca00b191d57fd07f061833331ab

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-240

Path: src/modules/reject-reports/application/list-daily-rejects.ts

Sha256: 6cfbdda930665e78ee09c38220c15c7964b97577b0a81219b25ecfa357248b4c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-241

Path: src/modules/reject-reports/application/list-issue-slips.ts

Sha256: e8d653e56809218bb701d2e890ed304718d362ac4580bfc870484ee654434e2b

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-242

Path: src/modules/reject-reports/application/reverse-issue-slip-approval.ts

Sha256: a5400af4d9ad72117f21d868337bd873f1aa70e0a74dda79601071aeda27f840

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-243

Path: src/modules/reject-reports/application/update-issue-slip-draft.ts

Sha256: 704266d9170769be854228b5f15568710aa6146b80daf4791e4b68e58e1ca185

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-244

Path: src/modules/reject-reports/application/view-model.ts

Sha256: 6215d388c88d9656c4f77fe76486be084d3066c3ac6ca1028bb610ab71c723a7

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-245

Path: src/modules/reject-reports/application/void-reject-report.ts

Sha256: 621b450a725562db3f862564653b2e492f37fc676745a4d79242ba5b625f48fc

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-246

Path: src/modules/release-governance

Sha256: 1bbb45ffec55b1a351e11ae302237b7979a0cd4b672fc035a5a8738abdac36e6

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-247

Path: src/modules/release-governance/application/approve-release.ts

Sha256: 896f25689a3fd6f31bc50fa069b13761f13d6d798385afd75338b8e8c71ed41a

Hash kind: file SHA-256

Revision: input.expectedVersion,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-248

Path: src/modules/release-governance/application/capability.ts

Sha256: 5428ebaf34654a84e167b64fa1689ffe6460fa299ffdc7c7a4dd02988aaa54c4

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-249

Path: src/modules/release-governance/application/dependencies.ts

Sha256: 7f2b9ad64d781823c06aa8adf3b01194cda4f25920892a47edd6fb6a4fe3f01a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-250

Path: src/modules/release-governance/application/ingest-provider-evidence.ts

Sha256: c8e84bab9ce7ecce65e9956272b6a3a21334d1a5720a187f064e45d3a276238a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-251

Path: src/modules/release-governance/application/ports/provider-attestation.ts

Sha256: 1ca09c8def078f14edd4868b7bae0979ffaf0f3f26abee9a986b5cf05f1c1b23

Hash kind: file SHA-256

Revision: bigint };

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-252

Path: src/modules/release-governance/application/provider-evidence-intake-dependencies.ts

Sha256: a3c86bf7098b359689fc3e95fd53717b0c9cc5ca37c0d6f112e8582f3f6218ec

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-253

Path: src/modules/release-governance/application/runtime-identity-check.ts

Sha256: df09d807c9e4d874e7e0836b8ad873ccc6335ca0966a23564e302e9417d54ad6

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-254

Path: src/modules/release-governance/application/verify-provider-attestation.ts

Sha256: 4efdc98c2a67a8300ad2559e0bfc51920528c61d30901ea7f5a043068abee1b6

Hash kind: file SHA-256

Revision: identity.applicationVersion,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-255

Path: src/modules/reporting

Sha256: bb7e68b2ec43d8d5a62edd15fabce0c9b0bd866ed21a9d4263d6d57a8f093be3

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-256

Path: src/modules/reporting/application/dependencies.ts

Sha256: f3eee30f03d0360c14017b0eb5a2f4866523b2f3b737a246cf76a5cb0bdb6f90

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-257

Path: src/modules/reporting/application/export-report.ts

Sha256: 428ded18041b23058bbb189fe39dd8a705cbe581e3e533c036aa26fb7b454552

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-258

Path: src/modules/reporting/application/parse-report-filters.ts

Sha256: fe5119ffd92960b6874dfd0c1bd36e37373b45a8cf82ab34fdb58d217183840f

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-259

Path: src/modules/reporting/application/report-provenance.ts

Sha256: 43bd4c42d1a308c6b0c75da3f40a03443a700712e172ad64ba0019856ec7dbb3

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-260

Path: src/modules/reporting/application/report-registry.ts

Sha256: ced5b818913ffcf99919bd356032e8192b91a42f3a5f49cefe2e8b3db46cf4a7

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-261

Path: src/modules/reporting/application/report-snapshot.ts

Sha256: e215714deba90904dc2bd9e1ee304e5ab027ff7198b57dcfc26a0d570c2964fa

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-262

Path: src/modules/reporting/application/run-report.ts

Sha256: d87c95b3a56be6da74a203137fe4c2a4937325f76af0aacf2611544372b5bd2e

Hash kind: file SHA-256

Revision: 1,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-263

Path: src/modules/system-health

Sha256: bbf1a6b63b7fcf329a55bfcb66ab1d3f80cd73e7b2aaf18486edfc1b537a1be2

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-264

Path: src/modules/system-health/application/dependencies.ts

Sha256: b920e933cd3afb42a50d607234d4d03ff499ac9db524fdb8ed41c31aba496454

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-265

Path: src/modules/system-health/application/get-control-center-overview.ts

Sha256: d35153e284fbf615aa9161a3f44f847ade4506af3e5689c130eba9730854f499

Hash kind: file SHA-256

Revision: release.serviceVersion } : {}),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-266

Path: src/modules/system-health/application/get-performance-snapshot.ts

Sha256: b181dfa018574dc4e1a453247ee37c2722e8c840f89265c3a80178ee3e96b01f

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-267

Path: src/modules/system-health/application/get-release-identity.ts

Sha256: 2ed9c3925b80a1c819df423be2eff968f24560265991467a8ddcd92b22f3fd49

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-268

Path: src/modules/system-health/application/get-system-health.ts

Sha256: 389aaf36a449d5d749f883048558490c6201650c99e834c6a05963edc3adde3d

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-269

Path: src/modules/tasks

Sha256: cfe300980897cfeea736a2be2040b6237ac2c8da6501eedf95dc046450d20642

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-270

Path: src/modules/tasks/application/create.ts

Sha256: a0ed3a9d32e02b61b886858f151b5d4572731efdf26c6773c267d8be1bb866c5

Hash kind: file SHA-256

Revision: 1n,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-271

Path: src/modules/tasks/application/delete-draft.ts

Sha256: 3f00fc6183997d8798c43913971a9680e660f104acfad405151fbefd479c706c

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-272

Path: src/modules/tasks/application/dependencies.ts

Sha256: 6bf5d95845c5cad47923c91ca143f7b2afb7d5ce7c266687e03c812fdea93f71

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-273

Path: src/modules/tasks/application/get.ts

Sha256: 804c4a5f11536a532c3dec36676953588941c5caf7502a7c0d0971770b49df95

Hash kind: file SHA-256

Revision: task.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-274

Path: src/modules/tasks/application/list.ts

Sha256: 933bcad919c5f625b95e87f1ba5d0be70249c3d9ab99ef2aba7caca09a355ef8

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-275

Path: src/modules/tasks/application/ports/task-list-item.ts

Sha256: 45b11dd874cf0c674554df8e2261a9e788dd31ac23d00f543414a38d9e05c0f5

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-276

Path: src/modules/tasks/application/transition.ts

Sha256: d014601c34a30193c3ac6e13563201526e2e79f305d662d6974917a82acbf002

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-277

Path: src/modules/tasks/application/update-draft.ts

Sha256: 5834ba0b7415df960e1cc0c027553fb10c50a91d69ef157b3f919ddb3507bcab

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-278

Path: src/modules/tasks/domain/state.ts

Sha256: 5b624b56fbb947b72f032359841d41ad8735e025c68dad250b0e26c600b010a1

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-279

Path: src/modules/uat-evidence

Sha256: d93f5a01dd6d0c641eac5328ed1a0c52d2db46c62d827a6f6352a2aff394f4d1

Hash kind: directory manifest digest

Revision: Directory snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-280

Path: src/modules/uat-evidence/application/dependencies.ts

Sha256: bfc85230e5c1e75d2c84bee30b35ab8efa6b3894635ab41df296ecbf2ec74080

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-281

Path: src/modules/uat-evidence/application/input-vocabulary.ts

Sha256: 9ac1f26061261b88d49687875d97f12dedbd80dd2f80ab082dc8ebcf4dac449c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-282

Path: src/modules/uat-evidence/application/use-cases.ts

Sha256: d17f3e87e73a1a8e8595dd3944766b0d3f59ec18f4baf8435271fdb25e4f38ef

Hash kind: file SHA-256

Revision: bigint;

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-283

Path: src/pages/404.astro

Sha256: 92309a0216f8a19175724b4e839ca61adaad96219410336a9b3868c0adcf69b0

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-284

Path: src/pages/500.astro

Sha256: a60d54bc4f70d1e8ad994a047a1d1e86f5b771f72c4b32517cf8fceb31bc21ef

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-285

Path: src/pages/account.astro

Sha256: b11a75312e3a4813e1f6adf14c88e91b087dca9b2aaad324249e2565f81d42a6

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-286

Path: src/pages/admin/index.astro

Sha256: 65c208894491042fbd69426770db004aa3bac5cc2952c947f62310c9fe9c086f

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-287

Path: src/pages/admin/permissions/index.astro

Sha256: c3967d5d84fbf17718fa32054dff3d4c1e1094ba46302c5513795e6a436fc5f8

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-288

Path: src/pages/admin/roles/[roleId].astro

Sha256: 869e592a9bb05bee5640ede719dc5f323e7c8857b14c483d037159fe96b22703

Hash kind: file SHA-256

Revision: BigInt(form.dataset.version ?? '0') });

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-289

Path: src/pages/admin/roles/index.astro

Sha256: c4bcd34c4f363c602eeea8eb6ab3a16e4ff9157b23f3dbad7612968b14fe65ce

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-290

Path: src/pages/admin/scopes/index.astro

Sha256: 981eb52fd0acfce8c93b4cb553d6114817eaade7a6771ba8ee3f661ce0a1581d

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-291

Path: src/pages/admin/users/[userId].astro

Sha256: 8407522cdb47f4723f80d7aacdd0cae237991559a87fae065fc4b6741ce628de

Hash kind: file SHA-256

Revision: version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-292

Path: src/pages/admin/users/index.astro

Sha256: d89cb4362ea3c26aea52ba80bf8da4068e2cce4a87d69492496edb8bbc0de069

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-293

Path: src/pages/admin/users/new.astro

Sha256: c4abeef0b689f75a71c23d2fc7f83d15946db8354b80549988c051fe2683e5ff

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-294

Path: src/pages/ai-advisory.astro

Sha256: 3b09dd25ac1798e848879687239584529a7be9d0a01366bb12cc478b8834153d

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-295

Path: src/pages/approvals/[approvalId].astro

Sha256: 76114a8c90006a0b1c94ee6e9c86c6f32f5e74bdb4344fd542476ce11a9834fe

Hash kind: file SHA-256

Revision: BigInt(String(data.get('subjectVersion'))), decision: String(data.get('decision')) as 'APPROVE' | 'RETURN' | 'REJECT', reason: String(data.get('reason') ?? '') || undefined, reauthenticationSecret: String(data.get('reauthenticationSecret') ?? '') || undefined });

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-296

Path: src/pages/approvals/index.astro

Sha256: f63728a870a21eff00425b6962b7abfb94dd4d061a48094c18f87d09e499bc89

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-297

Path: src/pages/assets/calibrations/[calibrationId].astro

Sha256: 4ef2868c740e1c37a834d60d7029da03e1f2dad7dc6c07f0d3c8af0cc1ce3e50

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-298

Path: src/pages/assets/calibrations/index.astro

Sha256: 9e7d3a60c52e64ec2f9dc80d124721ef36946d96214cc451883b6d2eca333f11

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-299

Path: src/pages/assets/calibrations/new.astro

Sha256: e97efcfd4b3194eb00bdc9fd02672b57132b27ca594055a5d9c2039b105c4847

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-300

Path: src/pages/assets/equipment/[equipmentId].astro

Sha256: 0dbfe222e4d19b00af93f1664fe9c95e4f48d4a8e3f807bc790959ac655ded71

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-301

Path: src/pages/assets/equipment/index.astro

Sha256: abbdabb83816417960d23971fb221870efb088d257b56d6652333e1637b486c6

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-302

Path: src/pages/assets/equipment/new.astro

Sha256: b072cfa082f3043d2487c60993d1ed71175c39299d9b99fb1d95f97f4ef8316a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-303

Path: src/pages/assets/index.astro

Sha256: c1f0d30cc649bb02919159bea9bfe324d73d8474ca66451180b477bddbc829fb

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-304

Path: src/pages/assets/maintenance/[maintenanceId].astro

Sha256: c4d2690a666460ec4937e90f05a165b9f7db88dc6ff2a2f46e1db8f2801896d3

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-305

Path: src/pages/assets/maintenance/index.astro

Sha256: 6aeba9de67c9d826fde1c41e253485c4b6472e53df335a96d26909eb20e3ea88

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-306

Path: src/pages/assets/maintenance/new.astro

Sha256: 85bdb24ba1a430b659476b2eb8f342f63f9de515aeba71db4a8931022a78e14c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-307

Path: src/pages/audit.astro

Sha256: abaec2b92b2a160f196889259e8ed49a1598f28dae0464a6539dc16837d9d156

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-308

Path: src/pages/change-requests/[changeRequestId]/index.astro

Sha256: a214b3cba8b9c50a30298561246a00dcff74f4b7a6e3dbd724df3451ade09daf

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-309

Path: src/pages/change-requests/[changeRequestId]/review.astro

Sha256: b2c267b09e1e4ef751809261374989ed1cd30ade3ec91a5ef4bd87a878d66b5e

Hash kind: file SHA-256

Revision: BigInt(postedVersion),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-310

Path: src/pages/change-requests/index.astro

Sha256: bc8feaf57eae0d63e1f49f87da6c9bdeb9cecb29e53a1fa5650e68992b2b855f

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-311

Path: src/pages/change-requests/new.astro

Sha256: 9df644786d3bb66f14db6c6e0722c138edd796ab7b6db454dfbe5a2a1e0e2caa

Hash kind: file SHA-256

Revision: preselected.id ? (targetVersions[preselected.id] ?? '') : '',

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-312

Path: src/pages/dashboard/index.astro

Sha256: 672d0501c5f895b798e1996a6ef81471c60b37126d483f059431044fe346f1ee

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-313

Path: src/pages/documents/[documentId]/index.astro

Sha256: 7f4d602e26ac707bf426e212689a98d7defcdf852e50253fdf94dd7cc2566bd2

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-314

Path: src/pages/documents/[documentId]/versions/[versionId]/edit.astro

Sha256: 13d1c5fd0dc677f7f972da9f034379710bccb99a8708db48fe296801a82f7ce8

Hash kind: file SHA-256

Revision: BigInt(submittedExpectedVersion), expectedContentHash: submittedContentHash, revision: values.revision, changeSummary: values.changeSummary || undefined });

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-315

Path: src/pages/documents/[documentId]/versions/[versionId]/index.astro

Sha256: 192caf957bd4226d3297d8242eabc70805672a784f8c57bbb034fdc3b49edd1c

Hash kind: file SHA-256

Revision: BigInt(button.dataset.expectedVersion!)});if(result.data)window.location.reload();else{status.textContent='Submission was not accepted. Refresh the version and check its current state and your permissions before trying again.';status.focus?.();button.disabled=false;}}catch{status.textContent='The service did not confirm the result. Refresh this version and its history before deciding whether to try again.';status.focus?.();button.disabled=false;}finally{section?.removeAttribute('aria-busy');}});

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-316

Path: src/pages/documents/[documentId]/versions/[versionId]/review.astro

Sha256: c76344a702086043ae41db16af0eb8e86d0a59b3ca20190278b1873c070e6475

Hash kind: file SHA-256

Revision: BigInt(review.dataset.expectedVersion!)}),'Recording review…'));

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-317

Path: src/pages/documents/[documentId]/versions/new.astro

Sha256: db17b770af14f7eb1514045c4b6fc9944cb9985d5b10aaa5d4cf95d0a4b12939

Hash kind: file SHA-256

Revision: String(formData?.get('expectedDocumentVersion') ?? document.version),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-318

Path: src/pages/documents/index.astro

Sha256: e834fa7fbd5b84d93fd54b78c1d518f43d013c0416ba1b9ff7e91ecbe92ae9bc

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-319

Path: src/pages/documents/new.astro

Sha256: e03577e98829c2c94368e284dc760b72e39a820872bc456c1763ce11fecdf73b

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-320

Path: src/pages/governance/releases/[releaseId].astro

Sha256: aed4ca8f57941baa4cec45d708fbd418bfb3af5c0ab7317a8032b0f4ff50b39c

Hash kind: file SHA-256

Revision: {candidate.version.toString()}</p>

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-321

Path: src/pages/help/index.astro

Sha256: faf4f70c9e6178ccf9a4163899a7f7e700dfd7e1c8645c161484bad43fd82206

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-322

Path: src/pages/index.astro

Sha256: 5a629664fc5ae70fae532f09fa139849d30cbd53afee3d90d7eb56639d81ac93

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-323

Path: src/pages/laboratory/index.astro

Sha256: 15a244c0ab5b456d181745fd800d58321482f90ad73600d9634075b0edf1fa3e

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-324

Path: src/pages/laboratory/report-templates.astro

Sha256: 1d29ae770b5188b7eda693cc348f3642bb50951b1f242b1ffa44e52bc2be9d13

Hash kind: file SHA-256

Revision: id && /^\d+$/.test(text('version')) ? BigInt(text('version')) : undefined,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-325

Path: src/pages/laboratory/tests/[labTestId]/execute.astro

Sha256: cc5624c33461c39b9a918b344b169427d4791da51cf32783bcc7b5639503366b

Hash kind: file SHA-256

Revision: BigInt(form.dataset.expectedVersion || '0'),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-326

Path: src/pages/laboratory/tests/[labTestId]/index.astro

Sha256: b8616c9f0d52564f3cab2bf60c3e8870329fe34c1865c9934fe9afb0bf63c9ad

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-327

Path: src/pages/laboratory/tests/[labTestId]/retests/new.astro

Sha256: 134d21b7a05eb98502a98b9e0ff30f3d034e9e161ca571c9a5a0633ef84a338c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-328

Path: src/pages/laboratory/tests/[labTestId]/review.astro

Sha256: ca3257239a8b0fba330def8fe13258afd6cd02494cfa965ac0ab26de2e2db02f

Hash kind: file SHA-256

Revision: BigInt(version)});if(result.data)location.reload();else{btn.textContent='Not applied — refresh and verify the current version.';btn.disabled=false;}}catch{btn.textContent='The service did not confirm the result. Refresh the test and its history before deciding whether to try again.';btn.disabled=false;}finally{busy(form,false);}}));

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-329

Path: src/pages/laboratory/tests/index.astro

Sha256: bd1c5e3c1bbab4eebf528b88ec882a10df2eadf1c342700e03d1a5ca5f797811

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-330

Path: src/pages/laboratory/tests/new.astro

Sha256: 63e4e4ba041a748d51506ae47e1cc966ae057141a63aded59e62d8f1e6be4257

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-331

Path: src/pages/login.astro

Sha256: b26b5d0a7b79791750594bb4c237ec05d938f03f99eb0bebf7a530a7154c152a

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-332

Path: src/pages/notifications.astro

Sha256: 6f6098b28c260014e3bfa7a270874a92da9c5db1aa9807250a673b942157b525

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-333

Path: src/pages/quality/capa/[capaId].astro

Sha256: 430a09ef43c030709f3a1f70b33d3c17c7652f6edab55c163da967c095a7f6a5

Hash kind: file SHA-256

Revision: {capa.version}</p>

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-334

Path: src/pages/quality/capa/index.astro

Sha256: 32f8e7cd3c2adc55bcbefdf247036080453d05515fefebd454ed1954e90b03ba

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-335

Path: src/pages/quality/capa/new.astro

Sha256: fd00ca40ddc5bb8fafba5383ddedeec7bbb1ebda3a21155cf4fb74a5f7d16440

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-336

Path: src/pages/quality/findings/[findingId].astro

Sha256: 72051884c445abb0504ba6866c215a4e9e9183bb9b7b95ea25b97500fe89a080

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-337

Path: src/pages/quality/findings/index.astro

Sha256: fa0f437d2c2bce959c5e84465c3236a0bb254a938a09d6d5c4fbae71a5fd8987

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-338

Path: src/pages/quality/findings/new.astro

Sha256: 74c83d6f18564d3bcd3535f87252c800023704a6dc10065ceb46181e21200ebc

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-339

Path: src/pages/quality/index.astro

Sha256: 59b01041edd83940c4ae12256b05ac4f212b6bf31bceda9e9e437d0310e59882

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-340

Path: src/pages/quality/ncr/[ncrId].astro

Sha256: 0ec3aa3eed2da1b3a163992987245740a73e87c80fcc3179b0fb3bc84dac76f1

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-341

Path: src/pages/quality/ncr/index.astro

Sha256: 70ec21c319be17fe42dd64790d67437ac7660bc7a2bf276b617ba985e9fb3c4c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-342

Path: src/pages/quality/ncr/new.astro

Sha256: 2a380960c6dfa7c40b6ec78dd30a00b578c2c1fb317961e2d6ee59a33a282462

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-343

Path: src/pages/quality/rca/[rcaId].astro

Sha256: 9b67adeffe0086f4f428a871c9a19e612e754e73d61a27e25f386a9ac1bbb92c

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-344

Path: src/pages/quality/rca/index.astro

Sha256: a435d56dfd814780768f995b0f2c524795d9adb5474be9ae12f463f09efd7480

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-345

Path: src/pages/quarantine/admin/[templateId].astro

Sha256: 2c8c4680819f683a7d23a25255a73a12ff7fdda35dadd54a74eb05207bcaab22

Hash kind: file SHA-256

Revision: template.version.toString(),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-346

Path: src/pages/quarantine/admin/index.astro

Sha256: 8dc52c7b94ea56658a41db07358721d861cdafdad558cb49d31a1943c519fccb

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-347

Path: src/pages/quarantine/index.astro

Sha256: a75e3b8454ecaf24ab8aea816fba51e47d667ff5ff0a3c8c666200f0272107f9

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-348

Path: src/pages/quarantine/inspections/[inspectionId]/execute.astro

Sha256: f75d0de0e5020a3d4c679d3fc16a8f18cc5324cc528234d813abf75d89fa52fb

Hash kind: file SHA-256

Revision: inspection.version, expectedVersion: inspection.version, businessCondition: true,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-349

Path: src/pages/quarantine/inspections/[inspectionId]/index.astro

Sha256: 191927e929c2c65e8f463aef30a61c576bc50b57df0c62326485c2bc92e635d8

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-350

Path: src/pages/quarantine/inspections/[inspectionId]/review.astro

Sha256: 3276e8c9bf82db8ffcd33b6807d98be6e67c9163282fabfbe5a517431c0020f9

Hash kind: file SHA-256

Revision: BigInt(version) }))));

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-351

Path: src/pages/quarantine/inspections/index.astro

Sha256: 973c27f38b35e138ab4ab9a452eeca5f29c91b88cf5aecc9d360be22eb425214

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-352

Path: src/pages/quarantine/receiving/[receivingId].astro

Sha256: 2a17abf63ae3f9fd9832cdebfdaf2c663c4ac7577b29de19f502dba086d8b0be

Hash kind: file SHA-256

Revision: item.version,

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-353

Path: src/pages/quarantine/receiving/index.astro

Sha256: e7144da91319b1bf11fa9b65b9da203ae328663e3568196be0dff819bd3db5cc

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-354

Path: src/pages/quarantine/receiving/new.astro

Sha256: f915db2889ca17365927637b6d622e89cf1b52a6dceb2c6463bc0a7c12d0ee4f

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-355

Path: src/pages/reject-reports/daily/[reportId].astro

Sha256: 4da73f27fdb522ef60dc12c83e5a2fd5b7cdfc2268dbe0bce9566ad2aedbcb23

Hash kind: file SHA-256

Revision: BigInt(addForm.dataset.version || '0'),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-356

Path: src/pages/reject-reports/index.astro

Sha256: 6bc20b5fa5ac81cac40844ccb5d5870175b637cfc1cfc9b046ebc430dbc20c77

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-357

Path: src/pages/reject-reports/issue-slips/[reportId].astro

Sha256: 72a02c17b9ae5d9862f2a61f46e9905adcf1839d5bf0e7cf727f4068abfe6b56

Hash kind: file SHA-256

Revision: BigInt(form.dataset.version || '0'),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-358

Path: src/pages/reject-reports/new.astro

Sha256: 9f34c673b2f3240820c949784b2b0baccf2ba01364a6bbb9c648290a079a6175

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-359

Path: src/pages/reports/[reportCode].astro

Sha256: 90053511971000b321fd2e7dd968c055c6d5099d5e0d8e63d232fd2de713c903

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-360

Path: src/pages/reports/index.astro

Sha256: 97653e035979756048aa006e7c8fc01d976153013552ac3d22a13959f013aae1

Hash kind: file SHA-256

Revision: 1, expectedVersion: 1, businessCondition: true }).allowed);

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-361

Path: src/pages/search.astro

Sha256: 481cf413019b734eb8806d834760ac683248c00aacd39dea8da9cf6cdac44954

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-362

Path: src/pages/system/backups/[backupId]/index.astro

Sha256: fddd3974e156dcda7b3ce61364c6e21e8af17123cf4aa3c46a597c7763e26161

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-363

Path: src/pages/system/backups/[backupId]/restore.astro

Sha256: 03474e1ee7141984106e60efcee3ae1728377887db7cd88d430731e2ee4915ae

Hash kind: file SHA-256

Revision: field(formData, 'expectedVersion'),

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-364

Path: src/pages/system/backups/index.astro

Sha256: 8fcba528b3f8100257bd7883183e4c8460f497fdbfbc2042ffcadb1ee1a059c2

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-365

Path: src/pages/system/control-center.astro

Sha256: cfd06cbdace99107cfa648a253d8ca07bedcf5c4b64c8106d436cd952610e9c8

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-366

Path: src/pages/system/health.astro

Sha256: 3dfada74ea40dd872ef00eb9ed439e5c191b0f42219afdaa05d00ba33cc0be23

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-367

Path: src/pages/tasks/[taskId].astro

Sha256: 60144e6d13eafde67ded101a1a98cced9f0c32bb158460bb45a62c0973354266

Hash kind: file SHA-256

Revision: '', reason: '' };

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-368

Path: src/pages/tasks/index.astro

Sha256: c82c5854a755fef2bd4d79dca3e3a1081b49b1eda0fa02133a17d08372d2aee7

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-369

Path: src/pages/tasks/new.astro

Sha256: f090ed79d1ac722737c03086bf2e00a6d6c29d56fd4a9677b85055c2ebe4e812

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-370

Path: src/pages/work/index.astro

Sha256: 28b82c38cab1c37a1c4a217ee70c7ef2bdfa5de26e6d8bd0748c56b19d3874ac

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-371

Path: src/shared/authorization/authorize.ts

Sha256: 6a87e1c25fadcdf167d953301c75cfd7332a4b0a0c35e6fa8779d8bff1addf75

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-372

Path: src/shared/authorization/p05-authority.ts

Sha256: 1ba147d6855aa47266d5bd110b6ce17c95e6ea9ea1827e283f1674697117c565

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-373

Path: src/shared/authorization/permissions.ts

Sha256: 8da9acc7e2e9ea76758b0232df87d709670031ee1094fbc1c1b1669509993507

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03

## REPO-374

Path: src/shared/routing/routes.ts

Sha256: 27e5909175f2fa6f1efaf6629d224cb7b5f97077f73f6a9caf66bfbe15bf8338

Hash kind: file SHA-256

Revision: Source snapshot at recorded HEAD

Head: 435f9f704049dee4916223b24b96866d7fa9af2e

Accessed: 2026-10-03
