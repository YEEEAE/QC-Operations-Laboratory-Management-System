# Application operation coverage

D0.1 | DRAFT FOR REVIEW | 2026-10-03

All application-layer TypeScript files found under the 19 modules are mapped to process owners. Helper/query files are included; this is a source inventory, not a claim that every file is a business mutation.

## administration

Module: administration

Source: src/modules/administration/application/assign-user-scope.ts

Sha256: 5dce13ffc975c8f818b53596fd8e7b3f3b2a527d2e12d99856555136136c82d5

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-ADM-SCOPE-ASSIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/dependencies.ts

Sha256: 7dc3ad39dd18adfdc83df2a89d392b7e42aafc1fd9b2382d7d8fd59b49b23d39

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/get-role.ts

Sha256: 40d1ae023557431315ed80d69aaaffef5dcb99ed5ad39b312eb1296833d865b3

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/list-permissions.ts

Sha256: af990822f14ee68b2041fc7d961ebf812bfb7dc835e4a5a96385053d0ca09f8c

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/list-role-permissions.ts

Sha256: 5439b7333eaf39813ed5a784125ceac1986c949044f4573a5b81d9f5072b89e1

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/list-roles.ts

Sha256: 725476b0bc8fbb7c7974346273fcf500e9d1011591a127c1d9d2845c16d85ce2

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/list-user-roles.ts

Sha256: 2560ba17f1e3aa3b581ca0a261051ebcc38da6b29de4332d0184ce9bf4592131

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/list-user-scopes.ts

Sha256: b5f80d57d31625a626976cc66cfe4090aa8d0c00e2f9f9526ee48ec7eedbe1de

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/manage-user-role.ts

Sha256: 55790ed9676e0c9eb2635989136c10cb6d2547d0806045f9f57875b8a182f59e

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-ADM-ROLE-ASSIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/manage-user-scopes.ts

Sha256: e3186c80d28b6c9cfb0f07e5a0a3f27bf8b540780046e6ecd52806add7a2aa05

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-ADM-SCOPE-ASSIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/remove-user-scope.ts

Sha256: b183247b54de1bb8a26c719a310fb9a84a6609293215ece00cafa2d7d90ab5ee

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-ADM-SCOPE-ASSIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## administration

Module: administration

Source: src/modules/administration/application/update-role-permissions.ts

Sha256: 0727df194139acbe46f2fc941cdd90bfe671e31ff1b8225c7c0db88329b6b44a

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-ADM-PERMISSION-ASSIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## ai-advisory

Module: ai-advisory

Source: src/modules/ai-advisory/application/dependencies.ts

Sha256: 9c0551aa3a0ef52c6e283b4bc043f8c6aa9e4d0c7c34f3253f0707a599ee05fb

Sop: QC-SOP-027

Wi: QC-WI-045

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## ai-advisory

Module: ai-advisory

Source: src/modules/ai-advisory/application/get-advisory.ts

Sha256: fcff89690526d505b9d8053061d549f69aae8084af9d560b2ebd219f8d4f74c1

Sop: QC-SOP-027

Wi: QC-WI-045

Permissions: PERM-AI-DRAFT, PERM-AI-SUGGEST, PERM-AI-SUMMARIZE, PERM-AI-USE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## ai-advisory

Module: ai-advisory

Source: src/modules/ai-advisory/application/page-availability.ts

Sha256: 232b4f76ae8f16d5b29911e8575f8200c54d6f561cfdc2c8fd2331b15d6017aa

Sop: QC-SOP-027

Wi: QC-WI-045

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## approvals

Module: approvals

Source: src/modules/approvals/application/authorization.ts

Sha256: 3ef406a6eedd4e639af025b9208c006fb9bd8ea3a2ddc109ab57e84fe25eac17

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Permissions: PERM-APR-, PERM-APR-REVIEW, PERM-APR-VIEW-ASSIGNED, PERM-APR-VIEW-HISTORY

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## approvals

Module: approvals

Source: src/modules/approvals/application/decide-approval.ts

Sha256: 17c1ab99f3d4f64d82fd7ef880d0a0f16e17769f45f9f0e264512f1c4713b105

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## approvals

Module: approvals

Source: src/modules/approvals/application/decision-capabilities.ts

Sha256: 686eccd51369d3783a80344792009179a007d13e790c87db25f5fba1a2e89ca9

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## approvals

Module: approvals

Source: src/modules/approvals/application/dependencies.ts

Sha256: 7d1677fd93b5e6d11e115f8009e26b3c60bd0776baa0d76461efc6383b9c391f

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## approvals

Module: approvals

Source: src/modules/approvals/application/document-approval-evidence.ts

Sha256: 929247fd4eb64d43fdbfae0629db5c11655197f0179ae129a40db2c1377079eb

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## approvals

Module: approvals

Source: src/modules/approvals/application/get-approval.ts

Sha256: 753f925d895bb9283191bd18eddf0bdefc16711a35e72bb2b99ad28fec59b910

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## approvals

Module: approvals

Source: src/modules/approvals/application/list-my-approvals.ts

Sha256: 65a5527fcd6cfbaa5e17b7ff080addef8e4864fcd8daeae455050eeda48a0281

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/application/dependencies.ts

Sha256: 982d2c52310a9a159627e6b49fef67eb6e610afcb62c9d50f1d9f7498dcea9cb

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/calibration/application/create-calibration.ts

Sha256: e64f30bcd7838258b3213a8b15ce3d7a564a110bcb4d6fa895bbabbf089f5f25

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-CAL-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/calibration/application/get-calibration.ts

Sha256: 1d5db4e03b8c45e5336b469733fe9b532754a26cc52c9ecf893c6689b5ac71a4

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-CAL-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/calibration/application/list-calibrations.ts

Sha256: eeeec29ecb79c779f2091cc50e52ec2575c6257ed90e456b9e2be8a19352ad0d

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-CAL-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/calibration/application/transition-calibration.ts

Sha256: e3af2f8756c750a5a3287b6b2a44ff9f38cce480c385a8b2e274fff23be66bfd

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-CAL-APPROVE, PERM-CAL-EDIT-DRAFT, PERM-CAL-REVIEW, PERM-CAL-SUBMIT, PERM-CAL-VOID

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/equipment/application/create-equipment.ts

Sha256: 9fcee62feb880d947b965c3fcec0bec4883cde82f9577357d1d1bdd8f4f2cb34

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-EQP-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/equipment/application/get-equipment-eligibility.ts

Sha256: 59e4c758e11f2f3e129d0fc124ae328274f74a2910c10885d1f4d9ea95eb9cda

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-CAL-VIEW, PERM-EQP-VIEW, PERM-MNT-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/equipment/application/get-equipment.ts

Sha256: 3268b00dc6024afb095caf473f4d506b7b611a7fd7254a9eca3b497d1c211d89

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-EQP-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/equipment/application/list-equipment.ts

Sha256: b3654a2de7afd31ab58059de847b9cfd93cae0eec5114e43982c5be944fdb55e

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-EQP-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/equipment/application/update-equipment.ts

Sha256: 930b4a9671f9a9708757425bdb2cb64000396cdfc583ed47c6b826fa90544204

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-EQP-CHANGE-STATUS, PERM-EQP-DECOMMISSION, PERM-EQP-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/maintenance/application/create-maintenance.ts

Sha256: 4ee3a3068582ea45e3ff867572e1cfbf891e32edb4ddd35c60225378bcdae9da

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-MNT-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/maintenance/application/get-maintenance.ts

Sha256: 56dfa5abcb3f8c7a709fdd56efc77ba9cd5a250561670f683b7c2f6e3cfe5ba1

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-MNT-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/maintenance/application/list-maintenance.ts

Sha256: c81ff33ff175c08161d7efd6445d88647067a7188c3a47bde118dc9be34d92e0

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-MNT-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## assets

Module: assets

Source: src/modules/assets/maintenance/application/transition-maintenance.ts

Sha256: d6cdd21a06963351447caaa122b16a92ebc08a30db2345e29bc5c543643e5122

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Permissions: PERM-MNT-COMPLETE, PERM-MNT-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/dependencies.ts

Sha256: 96396c6954ede4926774ca99ad89f5c1ee819d98b0959cef84c1067eece723ff

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/get-backup.ts

Sha256: 6f4d94690efb1bb2c16bd713de8630e7914ec522ccd0bdd4da7c47819902108e

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: PERM-BKP-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/list-backups.ts

Sha256: 04ccb9fedf78c3dd6b97b3f92b54e5aa1e877b842d64868088a452dea91725bf

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: PERM-BKP-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/production-recovery-authorization.ts

Sha256: 3bbd607b25de461618493212db93d55f1fbe44c7d37f425d27a57a080c15418e

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/request-restore.ts

Sha256: 86975161b640586aa516ce3b5df7fa00c729ce30162bb8b23a3367880441e1bf

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: PERM-BKP-RESTORE-DRILL, PERM-BKP-RESTORE-PRODUCTION

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/retention.ts

Sha256: 00288d904730432785de78b1c9a3aac8251b50951b0f3a4315ba9e7e1403b6f2

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/run-backup-job.ts

Sha256: 719c5b6977b45cc4c726eb500080c79d3cd7da77abd439366b3d4cba5d416621

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/schedule-backup-recovery.ts

Sha256: 2402b3e20e0664b54d6f0a62fd585e6b0e6334f0f78343ebea2c02dcd050b809

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## backup-recovery

Module: backup-recovery

Source: src/modules/backup-recovery/application/validate-restore-request.ts

Sha256: 21956206f241bdd24dc72f8deca68610d554c006f216497389d4478ade9f6e88

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/authorization.ts

Sha256: c8522a338c94e8ad27e981e7cd906496122759a03295e8e29dd4649689b9cca1

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: PERM-APR-APPROVE, PERM-APR-REJECT, PERM-APR-RETURN, PERM-APR-REVIEW, PERM-CHG-APPROVE, PERM-CHG-CANCEL, PERM-CHG-EDIT-DRAFT, PERM-CHG-REJECT, PERM-CHG-RETURN, PERM-CHG-REVIEW, PERM-CHG-SUBMIT, PERM-CHG-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/change-target-vocabulary.ts

Sha256: a5a8e3af75e6b42db58851443f5b04f4deef90318b6546720df1e67cfb30c669

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/create-change-request.ts

Sha256: 7989cd8969dbdb1329ab389ac3f9f83fa183cee83a36f53392287153f3d29702

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: PERM-CHG-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/create-document-version-change-request.ts

Sha256: 857524f93cd24cd8cb8d40159f7609a09bb941f0d8c96da3c2bc47c0cd6f0444

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: PERM-CHG-CREATE, PERM-DOC-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/dependencies.ts

Sha256: 90ef9547ff711abb715ae48bb567136fbd7b58ce8574a1364a36c8eda3c8f316

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/document-version-change-fields.ts

Sha256: 084d25703ebbd0942e410b4b98d9fa0e222ae13452aba5381b2de2bd6f9d383f

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/get-change-request.ts

Sha256: c37643460ad6fcab8b0f6e2501cdd0e1750a278e706b6cfd5ad5228c33fe3561

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/list-change-requests.ts

Sha256: e90d5e8b1da9433130162315c170dafd3dd68ada1c67d065cdfd46e8741d0577

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## change-requests

Module: change-requests

Source: src/modules/change-requests/application/transition-change-request.ts

Sha256: ccca83a5751888d418bf1cfa304fb28b9362971aca010b624774b54fb8b324db

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/dashboard-attention.ts

Sha256: dbef423bba23530aa93f4379ac6de708d70193997e2ef9e21656b6d79bdd8c71

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/dashboard-empty.ts

Sha256: e657ce0672d27c0a5ed8dd35c1136693935826fe7ac4db73ad1478a24c2bdd07

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/dashboard-flow.ts

Sha256: d21d327ce49cb782d1b4b8fbd2e0629a9def4d3be7b7bbab6fc08de2fc9993c0

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/dashboard-presentation.ts

Sha256: 04be5930a391c43bbea8a3099e9159899cb20aef47b5f60767f91648a1abbab9

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/dashboard-series.ts

Sha256: 3597fb36e20e8702d5fa31e09167d7cbb080f1bc05ad096790ab832bafb3784c

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/dashboard-sources.ts

Sha256: 62164db6713b93d79c32501170c64d44b2e486d8c083ecac6e85fd2c8e32ff19

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/dependencies.ts

Sha256: ccccc1cff7408a3e30b2609fbd648940a401ed7daf425605304339f1340d052d

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/get-dashboard.ts

Sha256: f85d7978cbc075d8dbb8ae52eb3c85711e784d1c04b7ea00877ed663b7f575d3

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: PERM-DASH-ADMIN, PERM-DASH-MANAGEMENT, PERM-DASH-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/get-my-work.ts

Sha256: 11a9304ee1295e631c75765f655b356852a0bd441ae75b22b7b647f5219faa51

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/my-work-definitions.ts

Sha256: a103a9251b7853bdde41565638c746a40bd8bd141f47cd0299d9733a432badc2

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## dashboard

Module: dashboard

Source: src/modules/dashboard/application/my-work-queue.ts

Sha256: 1031d52400131e414a11adfc0a162934306690f7f0c92819e0af4443ba89832b

Sop: QC-SOP-026

Wi: QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/approve-version.ts

Sha256: f539d0070e5684676867177594e8bfc1ebc239e235b86c28c5678e1014acfcf1

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/authorization.ts

Sha256: 047fe3283d58610386e024cf42a010f23fc5b7b4794f0d8d1ab6450616fe5bce

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/create-document.ts

Sha256: 9d534de3aa8b662ab7836c6a7574a7d4c3bca3070c440dae53a376275ea98404

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/create-version.ts

Sha256: 78a71f5e361ef646e339d642dd3672304aacbff71ecc5a0b7a000d29245dafe5

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-CREATE, PERM-DOC-REVISE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/dependencies.ts

Sha256: 25eadb1cb0eee2ece90768a5e8fdba458eec6866359dedb5ea510fd3029d76ee

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/document-vocabulary.ts

Sha256: 91a7e747f6feb6b5f93f359f52b02ed2091547fa094a8cb564e531a3fc0f9c8b

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/get-document.ts

Sha256: e6af18f31f1213b0c4102e33d1d028baea8f05236f8cc05d905a05bb16cb238a

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/list-documents.ts

Sha256: f4bffc20a08612b403852fa0bde1837bd82ef5ee93e6c183df6ccd63954f6e61

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/list-review-queue.ts

Sha256: 98e169b68d8660e9580144f12a33a3dd2471bfb1b9ad88e9358d1e5f01e448d7

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-APR-REVIEW, PERM-DOC-REVIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/list-source-files.ts

Sha256: bbe8214fa50b659b5bfbb2aa900dbaf73b7e22b0a52ac9f75185d25b024d8447

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/review-version.ts

Sha256: e2aed456929618a2f25a7eb2d18b0ae81e12ed85f119c67a0aaeabd7abcd3f27

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-APR-REVIEW, PERM-DOC-REVIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/submit-version.ts

Sha256: 5c71e11a979add78b797f85fc54bf4555d64595e0280a9c72375a3f9637ccc20

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-SUBMIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/supersede-version.ts

Sha256: 15570c32763bb19de09eb13d31166e3ea557c955152e8782092d6de9cda6a526

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-SUPERSEDE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/update-version-draft.ts

Sha256: c3e12835cf8049faebbeda19731cb3e36fc8c0d67e3ab75640f60e01dfb62545

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-EDIT-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## documents

Module: documents

Source: src/modules/documents/application/void-version.ts

Sha256: 2cf9a8931738a870b3d8983a63409348043589ff0e93f586d4e4f87da45d301a

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Permissions: PERM-DOC-VOID

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## e-signatures

Module: e-signatures

Source: src/modules/e-signatures/application/final-approval-ceremony.ts

Sha256: be376b0899a926b91e31d1d5395088d8295a16143d9bc89d1bee512ef44670d1

Sop: QC-SOP-011

Wi: QC-WI-013, QC-WI-030, QC-WI-063

Permissions: PERM-ESIG-SIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## e-signatures

Module: e-signatures

Source: src/modules/e-signatures/application/reauthentication-verifier.ts

Sha256: 5e66f0604fe5380b484a0167d5431912b15b99ddb599bf98f035f713b08e5f44

Sop: QC-SOP-011

Wi: QC-WI-013, QC-WI-030, QC-WI-063

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## e-signatures

Module: e-signatures

Source: src/modules/e-signatures/application/sign-controlled-action.ts

Sha256: 5fbc47bfeccd2fe577412364c480d114c93a675d78ac0ba9a105f34a4babb78c

Sop: QC-SOP-011

Wi: QC-WI-013, QC-WI-030, QC-WI-063

Permissions: PERM-ESIG-SIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/activate-user.ts

Sha256: 6432a2a26849ea83fcdd2a1752275f9bc1b12a5dbe37a9336f17dd1718651d06

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-ACTIVATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/admin-dependencies.ts

Sha256: 8aacc1bb452372e3cede2bbc9294a2d5cb7ca3d8a6964a0d98f00c2b3e53080a

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/admin-reset-password.ts

Sha256: 53adbc76d655cc1b3f0f40aea7c7a00eaf61b4f6150048248aabe0ed0f6a1768

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-RESET-PASSWORD

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/bootstrap-admin-check.ts

Sha256: 7719c591299e9c2be010969d079a3c9f42e4e4e62975970cdf0a0b6cbc87b408

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-MANAGE-USERS

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/bootstrap-initial-admin.ts

Sha256: aa2d3b922a9eda7ee54181d55cbf54485b421122d570d92c4c5ef31c9b5681c4

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/change-password.ts

Sha256: b17c4e762e34dd0fdfee1706495c27a5dfdcb555fcd7e331540842e20c27bdb6

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-CHANGE-OWN-PASSWORD

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/create-user.ts

Sha256: 7c13fc0064fc76e11d2d1857632be93e2142b56530358d8489053efb4819f943

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-ADM-ROLE-ASSIGN, PERM-ADM-SCOPE-ASSIGN, PERM-IDN-MANAGE-USERS

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/disable-user.ts

Sha256: 493930004ff194ea437c11affc39a7d2068be0c5d1c8d130c7dc9679f4eadd16

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-DEACTIVATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/get-account.ts

Sha256: 6dcf8f04b0880b7f5246f7da56aab5c030cc5f5fd2de1470c240707a26c31abc

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-VIEW-SELF

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/get-user.ts

Sha256: a1c90eed1c6596d16cf4802f006f8d6b312fd495824358b725c5974ab0233bf3

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/identity-dependencies.ts

Sha256: 588fe01ab1e36a1c0632f967f6ad4c6ee54fea025f07fd26338fe0818e322c04

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/list-users.ts

Sha256: 93216262749d5aacacbf049dbd8fc3d5447a5434cc9650627502a53775c34998

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/login.ts

Sha256: babd749613dd5db8a6f147632c1bbc72ea31c01d9b914dac3e5cf8f75bd1fdfa

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/logout.ts

Sha256: cce89e2476c60ef24a145fd93fd0a659a18729c1d8058186560b459d5136a8f5

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/resolve-session.ts

Sha256: e64b0882a100e1b6a6c2f34c5863b84e79905ba71ae6f14de0544ab34a3ab91e

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/revoke-user-sessions.ts

Sha256: 2e6b7372dc89010e2fe8315aabcea6a797e6af847b4fb431912f8af077e4ee37

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-REVOKE-SESSIONS

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/safe-user-view.ts

Sha256: 2b9b8a292cae0805273285b01a8dc5645496667676422c3fdc693e5b49a63264

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/session-service.ts

Sha256: 592cd1eb0e167cf0cc3d954247c2885b733341f617b9eef36a8213efc8ae2826

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## identity

Module: identity

Source: src/modules/identity/application/update-user.ts

Sha256: e37833e89c0e0566511d52adb55e4dd049a06f627c880b4ebb8518f8fccc7b04

Sop: QC-SOP-003

Wi: QC-WI-040

Permissions: PERM-IDN-MANAGE-USERS

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/approve-lab-test.ts

Sha256: 7e5b578b0fa7fa2f2078d4bdc42729a962e29c79234d2d1c268acbc0a278765b

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-APPROVE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/create-lab-test.ts

Sha256: 1be00f4cc442f60b1bce9a36701f188aa15b7bea760ed2288446d43390a9d064

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/create-retest.ts

Sha256: 226ae7742440fca5639cb01dacda9ad3544cc4b482c1d500e88eeb291f230b7d

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-AUTHORIZE-RETEST, PERM-LAB-RETEST

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/dependencies.ts

Sha256: a5873e232719af2c05d5908436998c914428cbfb09e27dd2720efcfaf921536d

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/final-approve-lab-test.ts

Sha256: aaef5e646bb40019475c9589b7ddcf7162895a2e61f100735acb1f4c180e4669

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-APR-APPROVE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/get-lab-test.ts

Sha256: 35a569f2dfd4365b08d22566ea9f7248afd66a52f62b034383b00bbe255c5f0a

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/get-lab-workload.ts

Sha256: d7b7d87ce13860f489110c8b1d66806e94d9c657ef87ca202b3fd37cd77ec847

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/get-source-receiving.ts

Sha256: acf232a83bf93b04bac3438e14a01782f0c7bb279c5905c87534679657cf7a05

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/lab-authorization.ts

Sha256: 16c9492a3ccb5ec429bdc3821db53bbfdece98bbc2f73df101df6b1c9fae95ad

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/lab-presentation.ts

Sha256: 612f2f03abb22a43749ab3fbcee95c837d7806db7a424373f7e287f52d9798be

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/list-approved-templates.ts

Sha256: 6248f3f113a61136643b64d2f4143c852eaa7613dcf18a56712933668e06d9d7

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/list-lab-tests.ts

Sha256: 49b4032026d4563dfdc3727389058bbc4ceba3303f67752d6ce99863400241c4

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/record-lab-run.ts

Sha256: 24c56f3d7381f0ee697d67aba5690b5d29b3fcbdc01fb2dd51b5c7c31cfbae91

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-EDIT-DRAFT, PERM-LAB-ENTER-MEASUREMENT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/record-run-equipment.ts

Sha256: 60c7ac597d06bac81900eca830834f61745a7d719c111579327b3c55b91143fe

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-EDIT-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/reject-lab-test.ts

Sha256: 2e45b256324aff3b7d998ee0019f4c7c7a8466c6f56ca01d49238dfc0e538fc7

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-APR-REJECT, PERM-LAB-REJECT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/reopen-lab-test.ts

Sha256: ecf6dbb245a9022f360717ce67494bd22d890132d64fc7488ca3a443ba93e2a2

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-APR-APPROVE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/report-drafts.ts

Sha256: 231351b8d145976f0ed871914bbbe19135d53460030b758a9df594464cc652fa

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-CREATE, PERM-LAB-EDIT-DRAFT, PERM-LAB-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/report-template-form.ts

Sha256: c0de119da56f2427939aa5a9254b9bc916102536757387d60a9a4f56e4ce1e5c

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/resume-lab-test.ts

Sha256: 6f7fc807d1fec095ad034a58df6b42b10502d68fcbd74c0b5b39496b4fe9c8e0

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-EDIT-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/return-lab-test.ts

Sha256: 9cb6511c3d127e6ff6f18e012a8a161df01a31ba821c9c3e06bdddf47b936460

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-RETURN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/review-lab-test.ts

Sha256: 8dd59726baaaa7fc0c579e3fc11b2081e7bf21e4f5998912ef7608a07061c058

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-APR-REVIEW, PERM-LAB-REVIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/save-measurements.ts

Sha256: efebc64eb52cc2b5ad368ef1d63b4c4f559e3d0d8b0a3f5b3602eaaaf2137fbb

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-EDIT-DRAFT, PERM-LAB-ENTER-MEASUREMENT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## laboratory

Module: laboratory

Source: src/modules/laboratory/application/submit-lab-test.ts

Sha256: 14101353b5fb9c71fed54167ec11ea7b0db7477c689a1c0ccfb988f0ef31c734

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Permissions: PERM-LAB-SUBMIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/application/get-quality-overview.ts

Sha256: e4c90738acedd2f45e6a11ed8d612b2bcdceba0d99bbca69d590bb4d525ddf60

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-FIND-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/capa/application/close-capa.ts

Sha256: 3f6ca4ddd0d1c9dcf4ea1d43a12dbeca20fa0f3e14f6b6ef616ff8109ae7ed73

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-CAPA-CLOSE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/capa/application/create-capa.ts

Sha256: ad36c255b201db72b89565746857c16f3be93938be1446ac8e31aa381474fb5f

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-CAPA-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/capa/application/dependencies.ts

Sha256: 277cbe27695747dde481e0a9bd946e98275e83ecfbaf7a8fd97c91986c45b1a4

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-CAPA-CLOSE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/capa/application/get-capa.ts

Sha256: 2b11ac6483ef2f37d07c8fdbf380e6ae249ff138b2d1c9e2ffcc75001338c1de

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/capa/application/list-capa.ts

Sha256: a4b3d2f4a4e7b3da93c296b90124ad0e8f568bdb10279660f6f7252782cc12cd

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/capa/application/related-ncrs.ts

Sha256: 39b4a7b4bb4db05af3860ecd48f3f3a5407ae84f9a19aab410e54c775cd5cc19

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/capa/application/transition-capa.ts

Sha256: 2f1c5fe71af356e4c99a6818f6d71caacc730fd9ee5d1cec5deade4a1c9864e0

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-CAPA-CLOSE, PERM-CAPA-EDIT, PERM-CAPA-VERIFY, PERM-CAPA-VOID

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/findings/application/create-finding.ts

Sha256: d5ad2f7a67f725ad1b59531976aa95e90c51e0ecd30e191d3160e7f2c3c282d3

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-FIND-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/findings/application/dependencies.ts

Sha256: ef6c6e9e6f41c2e2d943298f269407d56ee92aaf83b5ce829def8ab345954e63

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/findings/application/get-finding.ts

Sha256: 20dc3aee455b4190b2382a5ffaa5c0110fb3b7ea107271b256db2f67a7b945de

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/findings/application/list-findings-for-actor.ts

Sha256: 43d0ed8b4809ea871e56dfd7dabc358909b20ba61d3d126e9632c55ec021efc0

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/findings/application/list-findings.ts

Sha256: 358a290b9dd6207488d01bf680cbdce96033db8f7c67348085b1f85371a10f01

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/findings/application/list-related-ncrs.ts

Sha256: 3d81d06c8e07ba872fbc121665c368e464c6d884eaea59582fe31f844328f7fd

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/findings/application/transition-finding.ts

Sha256: 35997af1d666c2f99d3dbfaa14fd67af381095a0e0ea5600039d74cd205a4adb

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-FIND-CLOSE, PERM-FIND-REVIEW, PERM-FIND-SUBMIT, PERM-FIND-VOID

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/ncr/application/create-ncr.ts

Sha256: 7b51036950e8262bc393a74b2147bd7e94f5190e608bc5e6d2ce6f601b11833d

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-NCR-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/ncr/application/dependencies.ts

Sha256: 69b88660019bd19c1b8390a350173d547eb5fa4b67f1092fd793929d5c1d165d

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/ncr/application/get-ncr.ts

Sha256: 0d7d96f0c1bd7ba7685b974f5a4e7f300b24889986616552069baa2de2369850

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/ncr/application/list-ncr.ts

Sha256: 48d3a101b2bb716452718d3db86e15ab4c546ece9ded413550cd0942eb1275e9

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/ncr/application/transition-ncr.ts

Sha256: 9ffef688d5e52040ce821c5f088b973c150f2aa5278a384d43e479df4d8b3130

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-NCR-CLOSE, PERM-NCR-EDIT, PERM-NCR-REVIEW, PERM-NCR-SUBMIT, PERM-NCR-VOID

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/rca/application/dependencies.ts

Sha256: b480f20ecf70824be0c159a7b747f8b01b8e5a03125c196d607befa6294ce358

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/rca/application/get-rca.ts

Sha256: 4c1e73f014c2a7f9e5fc1d93f68d3c8855e1d659e76ecc7df8668a23361280a0

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/rca/application/list-rca.ts

Sha256: 6b0cbd9498564c12dbbb66b6e9ac5ad8e720915cccbda76ad991e1212ff3335e

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/rca/application/transition-rca.ts

Sha256: 7a4574c0b6afc0a43ba82d54bfd69120dfb6c2c07889c201815285e42522e674

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-RCA-APPROVE, PERM-RCA-EDIT, PERM-RCA-REVIEW, PERM-RCA-SUBMIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quality

Module: quality

Source: src/modules/quality/rca/application/update-rca.ts

Sha256: bc6e80b69b3a43324aa4ee1a8d707ffeadd58ae15b2dfb4672deed5ae18fc2b2

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Permissions: PERM-RCA-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/application/dependencies.ts

Sha256: 681c28bd5da5f9b2d3769df23a749a97629ad4971841a4ec2989f4d7e44020c6

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/application/get-quarantine-admin.ts

Sha256: ebcece38f1093422f830e9e52633b6e3fe1fa5e14bae245d333defcb6a17610d

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-ADM-TEMPLATES

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/application/get-quarantine-overview.ts

Sha256: 96438d20f78960307cf205ca579514f62921bc9a0717d94c3af1097b2d11190f

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/application/get-receiving-trend.ts

Sha256: 9d83e347d19e2f02691a2bd180c78bf02b50510c701a3690bc892cf7a882a3dd

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/approve-inspection.ts

Sha256: 6d77cbc8008fafdd748327f825e061c0f60d8a578084f1dc315dd2ea7af9ed2a

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-APPROVE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/final-approve-inspection.ts

Sha256: 3118fc4a985972dca83926b9814c087d1526cd17efa3b970644bec6f65e5c8aa

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-APR-APPROVE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/get-inspection.ts

Sha256: d6bbf61bbbf7923d0ac30747b2076ae0c4c0b5ae203a88b2ef70eeb297ca921a

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/inspection-aql-equipment.ts

Sha256: 59aff6b1700a89298919e432fc2d0cf147a0d50df38cdc37215a5af802ec125a

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-EDIT-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/inspection-equipment.ts

Sha256: 6cd56ffe6a7d4c94ad8a5671d0852289122b82c853d62f7c048f86c8fe4a1107

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/inspection-result-options.ts

Sha256: 9211287293b8d1b8efa0a18503a043b08fc010e670ae966dc0e437b5585fcdef

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/list-inspections.ts

Sha256: 797a4ac31bdc7ef95808caa18fd9fbdd4db998c22227e712a78008524fcc1fd0

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/record-inspection-results.ts

Sha256: 76580bc1c6955cc5cfdfc39b9c4002b33a30d1b14153f8f990f3af07426cf9f6

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-EDIT-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/reject-inspection.ts

Sha256: f236ed0b8e23f91d809766ed2c879f4adb49f5eda02d77e8a536d7e45badbaab

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-APR-REJECT, PERM-INSP-REJECT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/reopen-inspection.ts

Sha256: 823558d206efcb20a3fb9c130103d22113d3d65c13343a921631a0e26a0ade32

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-APR-APPROVE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/resolve-inspection-template.ts

Sha256: a8c08ef4d9538510b46fa575fee9afa8d23e49db9d68877dfb3fc04f4ef94047

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-ADM-TEMPLATES

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/resume-inspection.ts

Sha256: d654169d1397495482de50a9abf03d1f9007881d5adf43cfc86579601ff5085a

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-EDIT-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/return-inspection.ts

Sha256: f2333477d438efed257e51f904a62f4ff5072874816205a3a0c522f501aa3aa2

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-APR-RETURN, PERM-INSP-RETURN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/review-inspection.ts

Sha256: bc2c0ab19c88f55f0bf1d0b17b2e7dc7d6edcc7ecbcc1f1332dcd510fed8b13b

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-APR-REVIEW, PERM-INSP-REVIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/save-inspection-draft.ts

Sha256: 662d06e08b4c14ea1c734170dad2433616d5b546096712b4f81d1574d166bd98

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-EDIT-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/start-inspection.ts

Sha256: d1b62fa4762369b3a6b9d0193e74951b44db8cba90e197feb42be2527cbb3e70

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/submit-inspection.ts

Sha256: dc0891fc8145b6411d564ac98bbefbec2137d507177ff77be346662405813983

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-SUBMIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/inspection/application/void-inspection.ts

Sha256: b662cea708a1685789fda1ecb72441f6ba350477a444bc6428d4528faf497540

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-VOID

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/correct-receiving.ts

Sha256: 70cf22f9ac341777b35cb95fc3dba7a4a8e0b3a49354e9289b75cb008ac1773a

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/create-inspection-from-receiving.ts

Sha256: c21363a0a6b76fb34eb85caeee1c0c5582c9bc10ed89e765b5239fade8d18c59

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-INSP-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/create-receiving.ts

Sha256: ef68b2839814b6293f797a334ff87160dd7d4ebf2daee93cdc2b7d54d516b585

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/get-receiving.ts

Sha256: 407aacfa2c7add73779837df6b1f70bd42c2bee9706126a3e0d5be9f29b823b2

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/hold-receiving.ts

Sha256: 81131e7c1b05e15dbac4a233dc0f555caab3de3bfbfa6771a8a4ec3876907b0a

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/list-receiving.ts

Sha256: 4ec8e5f317830d85bcf32c39d39fc16a894fb0a9633c5b77b8d9e20e2df23dff

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/presentation.ts

Sha256: d9d98a4cf32b9d2f59360c804a7eaef52c18aee7a11529162154dbe240552775

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/receiving-filters.ts

Sha256: 39f717ca04d2eb8320b106870cd5875145b6e4fb59aad96a9d80025fded69dc2

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/release-receiving.ts

Sha256: 30714f44c08aed7aa1794b796220168d25874014484f89edbce342b6de956555

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-RELEASE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/transition-receiving.ts

Sha256: da956764bcd332c32ef3af10fc3fa114c262813b0f3f05e0dc93f3526cdfcede

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-EDIT, PERM-QUAR-HOLD, PERM-QUAR-RELEASE, PERM-QUAR-START-INSPECTION

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/receiving/application/update-receiving-draft.ts

Sha256: 5a60ceb480079ef910126d4e06c37f65917d61f1fe2e52559c089d66cd7e479b

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-QUAR-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/templates/application/create-template.ts

Sha256: fd7bfdd22e8c4e6abeb4dba494d2ba944436b78a38f4109702723908d71fbfcd

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-ADM-TEMPLATES

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/templates/application/dependencies.ts

Sha256: b6c005c173050731b9be0da4166f232d988fd18646784fb26e3be9c2bc646686

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/templates/application/lifecycle.ts

Sha256: e039b278526d0e1e6f0bc6140d232cbb29441d78382d4a66760fdedeb275da8b

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-ADM-TEMPLATES

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/templates/application/revise-and-read.ts

Sha256: 766bf7c2f205c83859ca7a69f115fb55068ef4ea707e4ea7e826f50bc9522ae0

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-ADM-TEMPLATES

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/templates/application/template-authority.ts

Sha256: 215c2e5b85c7e48d661f2588db17d45c521064ce0775d7c35ac47f0723738422

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## quarantine

Module: quarantine

Source: src/modules/quarantine/templates/application/template-ceremony.ts

Sha256: f1c4a5be3e935b70d793d96ccdb4e4d9a53fa9a8a5b684db0fe39042ad97d7fc

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Permissions: PERM-ESIG-SIGN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/append-daily-reject-entry.ts

Sha256: ce72d17a8f9af5722b42cee964003920f93390200c886482d341e6deae5bb8c1

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/confirm-issue-slip-approval.ts

Sha256: 0d58d11934590a011b7569735dcb3556245f9194f092748596434032e446e23e

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-CONFIRM-APPROVAL

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/create-daily-reject.ts

Sha256: 8cb52f68e063757f493eaec9c716e78275c2443fdde2d6085252a0a0d494bf96

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/create-issue-slip.ts

Sha256: ff295880426eae8192de726c2023a277166cae9bb2f03f90b5afb04e90c90cc5

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/dependencies.ts

Sha256: 3d0117f104ea325db2133dc8a55a05fde09d0909a464bab064d885c2851757c5

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/finalize-daily-reject.ts

Sha256: 872961174af154f650d0320097bf5b217e98620dadd450a3f4613ea8fc36e2b7

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-FINALIZE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/get-daily-reject.ts

Sha256: 2f1eaec615c59daa763ece0a7f40de86d51e18a2108e08e61bab8e8ae67efd16

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/get-issue-slip.ts

Sha256: 9bc4259109314df72c787e29b7858c0db0577ba5075859d53ecfd35ca1c76893

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/get-reject-dashboard.ts

Sha256: ae4ebc829c280ba517e5e9e1c2401c8c83c47e658a2b9b2f7cfb68e13dd324f0

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/get-reject-report-availability.ts

Sha256: 784166bcc4dfd759565a5fd46de78c8c7843fb93ceff9db48502eed690a43cd5

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/issue-issue-slip.ts

Sha256: bcfac396d42fc0660c33864a7f457b649cfa2ca00b191d57fd07f061833331ab

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/list-daily-rejects.ts

Sha256: 6cfbdda930665e78ee09c38220c15c7964b97577b0a81219b25ecfa357248b4c

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/list-issue-slips.ts

Sha256: e8d653e56809218bb701d2e890ed304718d362ac4580bfc870484ee654434e2b

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/reverse-issue-slip-approval.ts

Sha256: a5400af4d9ad72117f21d868337bd873f1aa70e0a74dda79601071aeda27f840

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-ADMIN-CORRECT, PERM-RREJ-CONFIRM-APPROVAL

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/update-issue-slip-draft.ts

Sha256: 704266d9170769be854228b5f15568710aa6146b80daf4791e4b68e58e1ca185

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/view-model.ts

Sha256: 6215d388c88d9656c4f77fe76486be084d3066c3ac6ca1028bb610ab71c723a7

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reject-reports

Module: reject-reports

Source: src/modules/reject-reports/application/void-reject-report.ts

Sha256: 621b450a725562db3f862564653b2e492f37fc676745a4d79242ba5b625f48fc

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Permissions: PERM-RREJ-VOID

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/approve-release.ts

Sha256: 896f25689a3fd6f31bc50fa069b13761f13d6d798385afd75338b8e8c71ed41a

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: PERM-APR-APPROVE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/capability.ts

Sha256: 5428ebaf34654a84e167b64fa1689ffe6460fa299ffdc7c7a4dd02988aaa54c4

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/dependencies.ts

Sha256: 7f2b9ad64d781823c06aa8adf3b01194cda4f25920892a47edd6fb6a4fe3f01a

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/ingest-provider-evidence.ts

Sha256: c8e84bab9ce7ecce65e9956272b6a3a21334d1a5720a187f064e45d3a276238a

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/ports/provider-attestation.ts

Sha256: 1ca09c8def078f14edd4868b7bae0979ffaf0f3f26abee9a986b5cf05f1c1b23

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/provider-evidence-intake-dependencies.ts

Sha256: a3c86bf7098b359689fc3e95fd53717b0c9cc5ca37c0d6f112e8582f3f6218ec

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/runtime-identity-check.ts

Sha256: df09d807c9e4d874e7e0836b8ad873ccc6335ca0966a23564e302e9417d54ad6

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## release-governance

Module: release-governance

Source: src/modules/release-governance/application/verify-provider-attestation.ts

Sha256: 4efdc98c2a67a8300ad2559e0bfc51920528c61d30901ea7f5a043068abee1b6

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reporting

Module: reporting

Source: src/modules/reporting/application/dependencies.ts

Sha256: f3eee30f03d0360c14017b0eb5a2f4866523b2f3b737a246cf76a5cb0bdb6f90

Sop: QC-SOP-025

Wi: QC-WI-043

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reporting

Module: reporting

Source: src/modules/reporting/application/export-report.ts

Sha256: 428ded18041b23058bbb189fe39dd8a705cbe581e3e533c036aa26fb7b454552

Sop: QC-SOP-025

Wi: QC-WI-043

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reporting

Module: reporting

Source: src/modules/reporting/application/parse-report-filters.ts

Sha256: fe5119ffd92960b6874dfd0c1bd36e37373b45a8cf82ab34fdb58d217183840f

Sop: QC-SOP-025

Wi: QC-WI-043

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reporting

Module: reporting

Source: src/modules/reporting/application/report-provenance.ts

Sha256: 43bd4c42d1a308c6b0c75da3f40a03443a700712e172ad64ba0019856ec7dbb3

Sop: QC-SOP-025

Wi: QC-WI-043

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reporting

Module: reporting

Source: src/modules/reporting/application/report-registry.ts

Sha256: ced5b818913ffcf99919bd356032e8192b91a42f3a5f49cefe2e8b3db46cf4a7

Sop: QC-SOP-025

Wi: QC-WI-043

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reporting

Module: reporting

Source: src/modules/reporting/application/report-snapshot.ts

Sha256: e215714deba90904dc2bd9e1ee304e5ab027ff7198b57dcfc26a0d570c2964fa

Sop: QC-SOP-025

Wi: QC-WI-043

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## reporting

Module: reporting

Source: src/modules/reporting/application/run-report.ts

Sha256: d87c95b3a56be6da74a203137fe4c2a4937325f76af0aacf2611544372b5bd2e

Sop: QC-SOP-025

Wi: QC-WI-043

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## system-health

Module: system-health

Source: src/modules/system-health/application/dependencies.ts

Sha256: b920e933cd3afb42a50d607234d4d03ff499ac9db524fdb8ed41c31aba496454

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046, QC-WI-064

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## system-health

Module: system-health

Source: src/modules/system-health/application/get-control-center-overview.ts

Sha256: d35153e284fbf615aa9161a3f44f847ade4506af3e5689c130eba9730854f499

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046, QC-WI-064

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## system-health

Module: system-health

Source: src/modules/system-health/application/get-performance-snapshot.ts

Sha256: b181dfa018574dc4e1a453247ee37c2722e8c840f89265c3a80178ee3e96b01f

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046, QC-WI-064

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## system-health

Module: system-health

Source: src/modules/system-health/application/get-release-identity.ts

Sha256: 2ed9c3925b80a1c819df423be2eff968f24560265991467a8ddcd92b22f3fd49

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046, QC-WI-064

Permissions: PERM-HLTH-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## system-health

Module: system-health

Source: src/modules/system-health/application/get-system-health.ts

Sha256: 389aaf36a449d5d749f883048558490c6201650c99e834c6a05963edc3adde3d

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046, QC-WI-064

Permissions: PERM-BKP-VIEW, PERM-HLTH-AI, PERM-HLTH-DATABASE, PERM-HLTH-READINESS, PERM-HLTH-STORAGE, PERM-HLTH-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/create.ts

Sha256: a0ed3a9d32e02b61b886858f151b5d4572731efdf26c6773c267d8be1bb866c5

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: PERM-TASK-ASSIGN, PERM-TASK-CREATE

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/delete-draft.ts

Sha256: 3f00fc6183997d8798c43913971a9680e660f104acfad405151fbefd479c706c

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: PERM-TASK-DELETE-DRAFT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/dependencies.ts

Sha256: 6bf5d95845c5cad47923c91ca143f7b2afb7d5ce7c266687e03c812fdea93f71

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/get.ts

Sha256: 804c4a5f11536a532c3dec36676953588941c5caf7502a7c0d0971770b49df95

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: PERM-TASK-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/list.ts

Sha256: 933bcad919c5f625b95e87f1ba5d0be70249c3d9ab99ef2aba7caca09a355ef8

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: PERM-TASK-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/ports/task-list-item.ts

Sha256: 45b11dd874cf0c674554df8e2261a9e788dd31ac23d00f543414a38d9e05c0f5

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/transition.ts

Sha256: d014601c34a30193c3ac6e13563201526e2e79f305d662d6974917a82acbf002

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: PERM-TASK-BLOCK, PERM-TASK-COMPLETE, PERM-TASK-CREATE, PERM-TASK-EDIT, PERM-TASK-REOPEN

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## tasks

Module: tasks

Source: src/modules/tasks/application/update-draft.ts

Sha256: 5834ba0b7415df960e1cc0c027553fb10c50a91d69ef157b3f919ddb3507bcab

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Permissions: PERM-TASK-EDIT

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## uat-evidence

Module: uat-evidence

Source: src/modules/uat-evidence/application/dependencies.ts

Sha256: bfc85230e5c1e75d2c84bee30b35ab8efa6b3894635ab41df296ecbf2ec74080

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-068

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## uat-evidence

Module: uat-evidence

Source: src/modules/uat-evidence/application/input-vocabulary.ts

Sha256: 9ac1f26061261b88d49687875d97f12dedbd80dd2f80ab082dc8ebcf4dac449c

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-068

Permissions: 

Coverage: APPLICATION FILE MAPPED; source contract still governs each action

## uat-evidence

Module: uat-evidence

Source: src/modules/uat-evidence/application/use-cases.ts

Sha256: d17f3e87e73a1a8e8595dd3944766b0d3f59ec18f4baf8435271fdb25e4f38ef

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-068

Permissions: PERM-APR-APPROVE, PERM-RPT-VIEW

Coverage: APPLICATION FILE MAPPED; source contract still governs each action
