# Original company forms and image register

D0.1 | DRAFT FOR REVIEW | Final layout review 2026-10-04

All 84 originals are preserved unchanged in Original_Company_Forms.zip. The visual reference PDF contains one labelled page per image in this register order. Visual derivatives are not signed or approved replacements.

## IMG-001

File: 01D2413C-B61A-42FC-88EE-BC9E2C7A063C.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/01D2413C-B61A-42FC-88EE-BC9E2C7A063C.JPEG

Sha256: 1bb3383f41948e8a4e8495f9fc172394471e6d8dae03752d50a70a2af2fd9cdb

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 1

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/01D2413C-B61A-42FC-88EE-BC9E2C7A063C.JPEG

## IMG-002

File: 07D84358-7E7B-467B-BC04-773540A70667.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/07D84358-7E7B-467B-BC04-773540A70667.JPG

Sha256: 62c2c5c4a26569f82dce7379e240badc3c2eedb34405bd40ebd1ecbe1500c6a9

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 2

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/07D84358-7E7B-467B-BC04-773540A70667.JPG

## IMG-003

File: 12E764A7-368A-49BB-B99A-523182658227.PNG

Original path: QC_Controlled_Forms_and_Operational_Evidence/12E764A7-368A-49BB-B99A-523182658227.PNG

Sha256: 22cb4cc65535a1c36afda65c139233754895ee3e7c0280014eeb772a8c7dba2a

Format: .png

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 3

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/12E764A7-368A-49BB-B99A-523182658227.PNG

## IMG-004

File: 16741A6D-F072-4D17-906E-D621947D71B7.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/16741A6D-F072-4D17-906E-D621947D71B7.JPG

Sha256: 6c31658ce65521893f567123cf4a6cef7b10c892ba7c53dd147dd172340356fb

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 4

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/16741A6D-F072-4D17-906E-D621947D71B7.JPG

## IMG-005

File: 19A7B240-6261-4C78-9F53-8763F38F07DD.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/19A7B240-6261-4C78-9F53-8763F38F07DD.JPG

Sha256: a48f70bd2f3008e7128c9d2adfb47fe674fe5af1123de5f8d3c2ebe1abad849c

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 5

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/19A7B240-6261-4C78-9F53-8763F38F07DD.JPG

## IMG-006

File: 2060FC83-C7AC-493D-B5C9-FF5B9C99CE2F.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/2060FC83-C7AC-493D-B5C9-FF5B9C99CE2F.JPG

Sha256: 67ce8e45a6385756435ee4e0f4c85268cadcc02c90c735238dec4557bb43b5ea

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 6

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/2060FC83-C7AC-493D-B5C9-FF5B9C99CE2F.JPG

## IMG-007

File: 24B61406-9684-4B7E-901F-7FDC1874593F.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/24B61406-9684-4B7E-901F-7FDC1874593F.JPG

Sha256: 4c72a7a0e8d56486647c0cebb8b7baa703cfd535ac3a6908335a52d344eb8e94

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-004

Preview: References/Company_Forms_Visual_Reference.pdf — page 7

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/24B61406-9684-4B7E-901F-7FDC1874593F.JPG

## IMG-008

File: 291321EB-BE85-4D7A-B90F-60C172E08109.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/291321EB-BE85-4D7A-B90F-60C172E08109.JPEG

Sha256: 8834a9857f928b7821e587dbf20f9cd4a291d3b6c857f3bbde2f923abdb8857a

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 8

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/291321EB-BE85-4D7A-B90F-60C172E08109.JPEG

## IMG-009

File: 3701e170-9511-444a-9973-1864377a1d65.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/3701e170-9511-444a-9973-1864377a1d65.JPG

Sha256: a8acc2e352deb5e421a57284395bc4dc824ad0c647bebd9292168e98755d8020

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 9

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/3701e170-9511-444a-9973-1864377a1d65.JPG

## IMG-010

File: 373dad92-7bbc-44ee-ad2b-7254ec0576eb.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/373dad92-7bbc-44ee-ad2b-7254ec0576eb.JPG

Sha256: ad688937fb2cc4784f5e49bde1225401602f6a7b9360b077eb2fafc094866b16

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 10

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/373dad92-7bbc-44ee-ad2b-7254ec0576eb.JPG

## IMG-011

File: 37E3E4EF-4982-408C-BB26-38CD010FF6B5.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/37E3E4EF-4982-408C-BB26-38CD010FF6B5.JPEG

Sha256: 2750b8c0790b505cde2b7464abf0a9da5139d4f2ab101aa3346cc1b4b7102a71

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 11

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/37E3E4EF-4982-408C-BB26-38CD010FF6B5.JPEG

## IMG-012

File: 3a1031d4-1791-49fc-9186-155f3cd9e6ef.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/3a1031d4-1791-49fc-9186-155f3cd9e6ef.JPG

Sha256: a6b463af3985d50b1ebde87b176c5727fe1a78d5fb5d4710cc25930088d5b9f2

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 12

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/3a1031d4-1791-49fc-9186-155f3cd9e6ef.JPG

## IMG-013

File: 4EB9D719-355F-422C-B045-46EFAD6E4498.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/4EB9D719-355F-422C-B045-46EFAD6E4498.JPG

Sha256: 5899567271ed8b1794cfb49c7a1747cd49dd7c649a4e6ece377845183a7cc88a

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 13

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/4EB9D719-355F-422C-B045-46EFAD6E4498.JPG

## IMG-014

File: 5391E029-D214-44A0-B041-8E061F1910B6.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/5391E029-D214-44A0-B041-8E061F1910B6.JPG

Sha256: 4e92ec0a272cb1c059c8deeee8994b9a6e5142900b9e7d6af8f62627cdbf7f8a

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-007

Preview: References/Company_Forms_Visual_Reference.pdf — page 14

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/5391E029-D214-44A0-B041-8E061F1910B6.JPG

## IMG-015

File: 54763D07-AB91-4000-8FD8-B569739BE553.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/54763D07-AB91-4000-8FD8-B569739BE553.JPG

Sha256: 9e61f1352044c2a00fad843999a285a54a1c112f0354a8eab830a1906b64b33c

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-013

Preview: References/Company_Forms_Visual_Reference.pdf — page 15

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/54763D07-AB91-4000-8FD8-B569739BE553.JPG

## IMG-016

File: 55215897-154E-4FCE-BD1D-9128750BA560.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/55215897-154E-4FCE-BD1D-9128750BA560.JPEG

Sha256: 6bda1fb92cd55c760e18eb00121b32a1c433e1e15f63ab8c1050c4bf4478a3ae

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-014

Preview: References/Company_Forms_Visual_Reference.pdf — page 16

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/55215897-154E-4FCE-BD1D-9128750BA560.JPEG

## IMG-017

File: 5734F374-70A6-406B-B5D8-286EECD92FA1.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/5734F374-70A6-406B-B5D8-286EECD92FA1.JPEG

Sha256: 2e50027ae6cbf401867b1669bd73ec71beaf4466adfb2b4be783fb538cfd9560

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 17

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/5734F374-70A6-406B-B5D8-286EECD92FA1.JPEG

## IMG-018

File: 5734F374-70A6-406B-B5D8-286EECD92FA1.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/5734F374-70A6-406B-B5D8-286EECD92FA1.JPG

Sha256: 1895a89e3cb6a6f7e863ecd675d8b3a5955932ef280fad9e3624b7c6e41582aa

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 18

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/5734F374-70A6-406B-B5D8-286EECD92FA1.JPG

## IMG-019

File: 58E57A9A-2037-4B9B-9B44-6309BC52CE0A.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/58E57A9A-2037-4B9B-9B44-6309BC52CE0A.JPG

Sha256: dec0fb047c102a9d6ebd521bf57405d72a558bd201785e3eeeed2713236082f5

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 19

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/58E57A9A-2037-4B9B-9B44-6309BC52CE0A.JPG

## IMG-020

File: 64033573-A314-458C-85AE-EC1334673A93.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/64033573-A314-458C-85AE-EC1334673A93.JPG

Sha256: 24d1b7e0cdedcec9d7cdb58a95e09ee8af2385d03d359ac5a64cf0d955f8801c

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 20

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/64033573-A314-458C-85AE-EC1334673A93.JPG

## IMG-021

File: 7E5F6DCB-A790-4859-A806-5F5A84CD0F59.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/7E5F6DCB-A790-4859-A806-5F5A84CD0F59.JPG

Sha256: 83d503b4026b4b3d62568259739a43b0796282455420ff7492f595dd680f7fa8

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 21

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/7E5F6DCB-A790-4859-A806-5F5A84CD0F59.JPG

## IMG-022

File: 7EC7C60B-C3B9-45E8-8CB8-68AB142DADEA.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/7EC7C60B-C3B9-45E8-8CB8-68AB142DADEA.JPG

Sha256: 55ce77f60bfb2f2bbd477be56eb70d79ed7e42cd981da01d22a142cb5d2973c7

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 22

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/7EC7C60B-C3B9-45E8-8CB8-68AB142DADEA.JPG

## IMG-023

File: 808C9271-800E-4738-B2B7-E65CCEBFFBE3.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/808C9271-800E-4738-B2B7-E65CCEBFFBE3.JPG

Sha256: a6d08327cd07d2c102d348d2fdaba90487508416c78f959fca92146bc4f11979

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 23

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/808C9271-800E-4738-B2B7-E65CCEBFFBE3.JPG

## IMG-024

File: 93C7AB4A-49E1-4F3F-8E05-FE31AF889D7B.PNG

Original path: QC_Controlled_Forms_and_Operational_Evidence/93C7AB4A-49E1-4F3F-8E05-FE31AF889D7B.PNG

Sha256: b0148567f28695db29eeea24d1e1c6c792aba6abdc8b5070039c67fdbffa5aa6

Format: .png

Decoded: True

Decode method: Pillow

Form: FORM-013

Preview: References/Company_Forms_Visual_Reference.pdf — page 24

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/93C7AB4A-49E1-4F3F-8E05-FE31AF889D7B.PNG

## IMG-025

File: 95491052-6658-4BD9-8B7C-B42B611D88E1.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/95491052-6658-4BD9-8B7C-B42B611D88E1.JPG

Sha256: 365e53c4b4fb16d224207177ede85e922a22b5ee11d7e10d2e7cbabb7a021508

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-007

Preview: References/Company_Forms_Visual_Reference.pdf — page 25

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/95491052-6658-4BD9-8B7C-B42B611D88E1.JPG

## IMG-026

File: A95F8F47-435D-4AFA-8BDB-707C85FF8FF2.PNG

Original path: QC_Controlled_Forms_and_Operational_Evidence/A95F8F47-435D-4AFA-8BDB-707C85FF8FF2.PNG

Sha256: c8f6cc13e89e859d67e9e49736e223c1cf00617b221a19018562348215116f60

Format: .png

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 26

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/A95F8F47-435D-4AFA-8BDB-707C85FF8FF2.PNG

## IMG-027

File: ABB0CE9F-4BFB-40A4-9D9A-D9305C4C05A2.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/ABB0CE9F-4BFB-40A4-9D9A-D9305C4C05A2.JPEG

Sha256: e0e7ca30e3a397b53fcb428ceaffb3668f1acd897598b7c35ff74586663505af

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-004

Preview: References/Company_Forms_Visual_Reference.pdf — page 27

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/ABB0CE9F-4BFB-40A4-9D9A-D9305C4C05A2.JPEG

## IMG-028

File: B3C2B7BB-E747-43E6-A727-FD3603D2995D.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/B3C2B7BB-E747-43E6-A727-FD3603D2995D.JPEG

Sha256: d9699e124389789c63d087cbcc43d0672d9a0e4208670240c166222fe36082e8

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 28

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/B3C2B7BB-E747-43E6-A727-FD3603D2995D.JPEG

## IMG-029

File: B5BB44F6-39EC-4709-82BD-4ABA93345C3E.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/B5BB44F6-39EC-4709-82BD-4ABA93345C3E.JPG

Sha256: f16db32c78b069ec91ec86b84363f124705df73fa44564d997d3cea937fa26d4

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 29

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/B5BB44F6-39EC-4709-82BD-4ABA93345C3E.JPG

## IMG-030

File: BF3C4557-5A58-4033-9FC6-EC5ADA15E9F0.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/BF3C4557-5A58-4033-9FC6-EC5ADA15E9F0.JPEG

Sha256: ed360429a9c55685fefa8cd5a4b428d82abfe6a896d2d3426bd1cf236aca3ae0

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 30

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/BF3C4557-5A58-4033-9FC6-EC5ADA15E9F0.JPEG

## IMG-031

File: C616FED4-6C9D-466B-9585-A13786DC63B0.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/C616FED4-6C9D-466B-9585-A13786DC63B0.JPG

Sha256: 69df761388e4e025b76df7ceb15dd720057b777ca40a5f16a4a654fbe53a61ac

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-013

Preview: References/Company_Forms_Visual_Reference.pdf — page 31

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/C616FED4-6C9D-466B-9585-A13786DC63B0.JPG

## IMG-032

File: CC47165B-47CB-42ED-A2DB-CD8C4A025AF8.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/CC47165B-47CB-42ED-A2DB-CD8C4A025AF8.JPEG

Sha256: 8774ed0c72d1429a33f55b87782f28eadf645a8922d70f08b2e2fe55224c7ccc

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-013

Preview: References/Company_Forms_Visual_Reference.pdf — page 32

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/CC47165B-47CB-42ED-A2DB-CD8C4A025AF8.JPEG

## IMG-033

File: D3EC40FF-9B19-47BB-88A7-F68B5B65F5F4.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/D3EC40FF-9B19-47BB-88A7-F68B5B65F5F4.JPEG

Sha256: a3bf73b6ad21f39dd75944dd81c92700d729f880eb10fcad2fbe02b01cec39ff

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 33

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/D3EC40FF-9B19-47BB-88A7-F68B5B65F5F4.JPEG

## IMG-034

File: D67499F5-D291-4CBB-A8B5-3AD31A71CC42.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/D67499F5-D291-4CBB-A8B5-3AD31A71CC42.JPG

Sha256: 10f42ff039a510428d97a31128a2ec2e6d2ef6063000b4794e31ffe49ff975ad

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-013

Preview: References/Company_Forms_Visual_Reference.pdf — page 34

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/D67499F5-D291-4CBB-A8B5-3AD31A71CC42.JPG

## IMG-035

File: DE344F5C-EAEE-4B6C-87D8-34DABBA9F783.PNG

Original path: QC_Controlled_Forms_and_Operational_Evidence/DE344F5C-EAEE-4B6C-87D8-34DABBA9F783.PNG

Sha256: e3f78e4f5711e5dca415d430ec94bd2dad3cd6495fa3ac806dbd5cffcfa31869

Format: .png

Decoded: True

Decode method: Pillow

Form: FORM-011

Preview: References/Company_Forms_Visual_Reference.pdf — page 35

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/DE344F5C-EAEE-4B6C-87D8-34DABBA9F783.PNG

## IMG-036

File: E7B7B6BE-DCB5-4124-BE79-8F42EA8AF92E.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/E7B7B6BE-DCB5-4124-BE79-8F42EA8AF92E.JPG

Sha256: 62b448a0d637ccac44c6df66499d510348b4b534ccf9f2a2da3126b0509c524f

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-014

Preview: References/Company_Forms_Visual_Reference.pdf — page 36

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/E7B7B6BE-DCB5-4124-BE79-8F42EA8AF92E.JPG

## IMG-037

File: F0DF597E-9E38-4F09-B3AF-2598AF284F30.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/F0DF597E-9E38-4F09-B3AF-2598AF284F30.JPG

Sha256: a650952eed8aed7b1ecb1597958d634998ad324d140a119d09e844729ee7b442

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 37

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/F0DF597E-9E38-4F09-B3AF-2598AF284F30.JPG

## IMG-038

File: FC267EFE-F40D-46D6-B1B7-6C9CC2C9454C.JPEG

Original path: QC_Controlled_Forms_and_Operational_Evidence/FC267EFE-F40D-46D6-B1B7-6C9CC2C9454C.JPEG

Sha256: 1f94fd771d6fa3526ab5a19672991dfd1bb72c755063223925b59edb58ac97a5

Format: .jpeg

Decoded: True

Decode method: Pillow

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 38

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/FC267EFE-F40D-46D6-B1B7-6C9CC2C9454C.JPEG

## IMG-039

File: FFAE0C89-6A00-4F8B-9DAA-8412914B9D2D.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/FFAE0C89-6A00-4F8B-9DAA-8412914B9D2D.JPG

Sha256: 1c2fdc3107d48b8eeb46ce5ae621a41d0b5761fe1c1b831327548ac424dea5df

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 39

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/FFAE0C89-6A00-4F8B-9DAA-8412914B9D2D.JPG

## IMG-040

File: IMG_0242.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0242.HEIC

Sha256: 48751735d8a1ad3c81b07da39d831b33974afc11dd51af314b60a35c721e596a

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-004

Preview: References/Company_Forms_Visual_Reference.pdf — page 40

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0242.HEIC

## IMG-041

File: IMG_0243.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0243.HEIC

Sha256: d0c6f651dacd063d22e8b150c8ecf0e9b8f7fd02cf201bdfec79803fe7abeede

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 41

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0243.HEIC

## IMG-042

File: IMG_0244.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0244.HEIC

Sha256: 64c201b432aa3ab651fe684e56bc3874800d40dc1c52aed5a74ebb858d387070

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 42

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0244.HEIC

## IMG-043

File: IMG_0245.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0245.HEIC

Sha256: 0c287112663096dc6149d931a0640dec1dc3bd5624dc57651cad8b323765cf10

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 43

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0245.HEIC

## IMG-044

File: IMG_0246.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0246.HEIC

Sha256: 9438d33af25dd414b58be18c14f532292d25676f7cbc52e65c242acbcb8f3991

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 44

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0246.HEIC

## IMG-045

File: IMG_0247.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0247.HEIC

Sha256: 3a1362e003e1455f1c736c2ac0c4b7a4deb8743477915d92e83a28214b7b486e

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 45

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0247.HEIC

## IMG-046

File: IMG_0248.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0248.HEIC

Sha256: 6a7218398b154f586ecb2eb27801eabc342a3906429eb44ca6568ceddfae2ce1

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 46

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0248.HEIC

## IMG-047

File: IMG_0249.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0249.HEIC

Sha256: 5f16ff24c7055e7be827ff52fe3a1dacf31b577bb0ad259d87b40507df5fc250

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 47

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0249.HEIC

## IMG-048

File: IMG_0265.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0265.HEIC

Sha256: a6db8910db9578cd0bb57c31e849889af4abc4f1d20554bdfaec825f71024f56

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 48

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0265.HEIC

## IMG-049

File: IMG_0266.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0266.HEIC

Sha256: 7dee13e60bec9c5427087958de42a2a1326eb83af291d0ce0071146500e6d2e9

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 49

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0266.HEIC

## IMG-050

File: IMG_0267.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_0267.HEIC

Sha256: 5decc6417d17002570a6232f8d282de8b446accb88d44d89b8755fbe9d8807b1

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-003

Preview: References/Company_Forms_Visual_Reference.pdf — page 50

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_0267.HEIC

## IMG-051

File: IMG_1215.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1215.HEIC

Sha256: a5e99af2de86910ca630374c12ffcb08398c13392c6dbb2c8aa9b184cd7c09b1

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 51

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1215.HEIC

## IMG-052

File: IMG_1216.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1216.HEIC

Sha256: ef50c080934df5f8b2600f498127a92381baea7dbdf51de7aa8657446455ab71

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 52

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1216.HEIC

## IMG-053

File: IMG_1217.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1217.HEIC

Sha256: 8193422e773e46a85e8d29d33a83001766094ce9e090e95bc423f9c082d4d105

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 53

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1217.HEIC

## IMG-054

File: IMG_1218.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1218.HEIC

Sha256: f10c60b24ad398eb9ec6aa66144afe6f8ad9f2cc2efcf8daf2a5b75e154ff23d

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 54

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1218.HEIC

## IMG-055

File: IMG_1219.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1219.HEIC

Sha256: a97d9ed5cd98f710eb3308cd559f83de91fdf9f49a1f4bd4c8fec147b54492d7

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 55

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1219.HEIC

## IMG-056

File: IMG_1220.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1220.HEIC

Sha256: ff0abec8418db81fc2b784a2ac8cf7efec65f74980f15db4934ecff53d67b166

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 56

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1220.HEIC

## IMG-057

File: IMG_1503.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1503.HEIC

Sha256: 952ea816ff78baa5edb661e68ee0a9887c8a11e801c30c192a8e527e9cc11fe7

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 57

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1503.HEIC

## IMG-058

File: IMG_1504.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1504.HEIC

Sha256: 226707abd913e9f74428cf89cfe366511c7a530128806dfacc0a2b973eb00075

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 58

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1504.HEIC

## IMG-059

File: IMG_1505.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1505.HEIC

Sha256: 1529fef86a42b7010f7813c12f724fc13e49336f1df5f63a573c78469e86dd1d

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 59

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1505.HEIC

## IMG-060

File: IMG_1506.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1506.HEIC

Sha256: f51615f8147a5bd6fe76ee1c6395f2dfa599bb070b07d7138875adbeda8afb41

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 60

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1506.HEIC

## IMG-061

File: IMG_1507.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1507.HEIC

Sha256: 49fd0768ce55d6baeec42b920c161b763355504f1b7b1dd192549aaaf07aba67

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 61

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1507.HEIC

## IMG-062

File: IMG_1512.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1512.JPG

Sha256: d34cfa18cce8ec7389ea7a7b40b3aeb5661e41b39330a0fdcdaccfe8f402c5c8

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 62

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1512.JPG

## IMG-063

File: IMG_1513.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1513.JPG

Sha256: abeac10a0df32d95045e46ce8b5d9eab55e2ca3b4da2bcbb3c22878d73d19c8e

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 63

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1513.JPG

## IMG-064

File: IMG_1587.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1587.JPG

Sha256: a9ff9f14cc1627aaf23ada62742b50bfe89c247224e339099a5e78307dfbe2b2

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-016

Preview: References/Company_Forms_Visual_Reference.pdf — page 64

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1587.JPG

## IMG-065

File: IMG_1637.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_1637.HEIC

Sha256: fe55a95489feadc6dcafc83537059a5479b47ac7d5ad5157c621fc6bffd3cd16

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 65

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_1637.HEIC

## IMG-066

File: IMG_2005.heic

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_2005.heic

Sha256: d54abb244d49f12bf07bb1099f4797dcb53d2ec747f307d82d336599ea2726e6

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-015

Preview: References/Company_Forms_Visual_Reference.pdf — page 66

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_2005.heic

## IMG-067

File: IMG_2006.heic

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_2006.heic

Sha256: 239aa0dd2c3d770ff53f9665f190f143bc0bdb9f506f2cf3e6affdf813fb64bb

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-015

Preview: References/Company_Forms_Visual_Reference.pdf — page 67

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_2006.heic

## IMG-068

File: IMG_2007.heic

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_2007.heic

Sha256: cb5a68a2046db20019ed05f0fefa9d1f1bcafb12727453cb2b79a2d9a6e1de24

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-015

Preview: References/Company_Forms_Visual_Reference.pdf — page 68

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_2007.heic

## IMG-069

File: IMG_2042.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_2042.HEIC

Sha256: 64cbff51f5765f35f3e53309e289fbb4fb78946e8fb21870ef3b14387d294828

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-015

Preview: References/Company_Forms_Visual_Reference.pdf — page 69

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_2042.HEIC

## IMG-070

File: IMG_2077.jpg

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_2077.jpg

Sha256: 64865822f8f1c320e53593651e2032bdc85be80a347b9300cd91c2a4bee9a2eb

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-005

Preview: References/Company_Forms_Visual_Reference.pdf — page 70

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_2077.jpg

## IMG-071

File: IMG_6989.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_6989.HEIC

Sha256: ca2dae8e1fa22bc2325f286213671afec80a3376256d19f51149546608ccdb9c

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 71

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_6989.HEIC

## IMG-072

File: IMG_6990.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_6990.HEIC

Sha256: 20c66512daddc6c0b304f7cd5fc36a7ee50193e3527cde894ee0043964f3c128

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 72

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_6990.HEIC

## IMG-073

File: IMG_6991.HEIC

Original path: QC_Controlled_Forms_and_Operational_Evidence/IMG_6991.HEIC

Sha256: d3b2ffaaf5c2f375d1b394daef29afade5e8baa19bba16dc6fc8600766283376

Format: .heic

Decoded: True

Decode method: ffmpeg HEIC

Form: FORM-002

Preview: References/Company_Forms_Visual_Reference.pdf — page 73

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/IMG_6991.HEIC

## IMG-074

File: PHOTO-2026-09-14-12-53-56.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/PHOTO-2026-09-14-12-53-56.JPG

Sha256: e3f08de5894c22d61d6ad837fe117d08c95a51d6ed5b49ed2edc552dc092079b

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-006

Preview: References/Company_Forms_Visual_Reference.pdf — page 74

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/PHOTO-2026-09-14-12-53-56.JPG

## IMG-075

File: PHOTO-2026-09-14-12-53-59.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/PHOTO-2026-09-14-12-53-59.JPG

Sha256: e97012e0834dcc3ff14ebca6599f5330e56fb06e65237cbd91a7c4d5a98c1e1d

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-006

Preview: References/Company_Forms_Visual_Reference.pdf — page 75

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/PHOTO-2026-09-14-12-53-59.JPG

## IMG-076

File: PHOTO-2026-09-14-15-12-59.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/PHOTO-2026-09-14-15-12-59.JPG

Sha256: 5dc97a8a7396ab5947dfa8b24588f473fec67bcf61339fb734d574ede24f7a15

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-010

Preview: References/Company_Forms_Visual_Reference.pdf — page 76

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/PHOTO-2026-09-14-15-12-59.JPG

## IMG-077

File: PHOTO-2026-09-23-23-42-30 2.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/PHOTO-2026-09-23-23-42-30 2.JPG

Sha256: d1438b53e1fb42ef05016b7edad1aae9dee215b16e5d86aef2f414c8a7e5a82d

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-009

Preview: References/Company_Forms_Visual_Reference.pdf — page 77

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/PHOTO-2026-09-23-23-42-30 2.JPG

## IMG-078

File: PHOTO-2026-09-23-23-42-30 3.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/PHOTO-2026-09-23-23-42-30 3.JPG

Sha256: f4d7764ca6d5fb9a7a49eaeaed6f6dac65d86fdfd3a5cf6faa31fb5e1494d303

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-009

Preview: References/Company_Forms_Visual_Reference.pdf — page 78

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/PHOTO-2026-09-23-23-42-30 3.JPG

## IMG-079

File: PHOTO-2026-09-23-23-42-30 4.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/PHOTO-2026-09-23-23-42-30 4.JPG

Sha256: 76b54f416130f8881c9c47d9990a84c9dc1f2f9daa4f01459c835f867a3c4e7c

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-008

Preview: References/Company_Forms_Visual_Reference.pdf — page 79

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/PHOTO-2026-09-23-23-42-30 4.JPG

## IMG-080

File: PHOTO-2026-09-23-23-42-30.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/PHOTO-2026-09-23-23-42-30.JPG

Sha256: 22e84096cc0264b00eddc1b82591bec46b89bca35c83ec5d9a8f784e5dcce5b6

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-009

Preview: References/Company_Forms_Visual_Reference.pdf — page 80

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/PHOTO-2026-09-23-23-42-30.JPG

## IMG-081

File: dd8d9ca6-1af0-41af-b0d3-154f0002b88d.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/dd8d9ca6-1af0-41af-b0d3-154f0002b88d.JPG

Sha256: 14e845d799bcc821c7d3d7c679062b32f42cb544958a62087a933b3bb19b7512

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 81

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/dd8d9ca6-1af0-41af-b0d3-154f0002b88d.JPG

## IMG-082

File: edac174b-7b75-4ef6-b528-08dcfb9a0bee.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/edac174b-7b75-4ef6-b528-08dcfb9a0bee.JPG

Sha256: a7e7b0b4b3e6b3ec0c7a403ba82cae62d54a6a557b899500ebc999aeceebc0d3

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 82

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/edac174b-7b75-4ef6-b528-08dcfb9a0bee.JPG

## IMG-083

File: f3cf0fb9-cf5c-481a-acf1-c1e98804967a.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/f3cf0fb9-cf5c-481a-acf1-c1e98804967a.JPG

Sha256: 1045bca1c8c44d1f35e395337b93675b32d74350c982c7a082cc89b303f23e84

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 83

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/f3cf0fb9-cf5c-481a-acf1-c1e98804967a.JPG

## IMG-084

File: ff9f9a1b-c636-4497-8169-35cbbd2198d9.JPG

Original path: QC_Controlled_Forms_and_Operational_Evidence/ff9f9a1b-c636-4497-8169-35cbbd2198d9.JPG

Sha256: 5aa723e6e694a2c7194c01ef7dbcd7b36c8951419f676b0b6b887f3035b9e6f3

Format: .jpg

Decoded: True

Decode method: Pillow

Form: FORM-001

Preview: References/Company_Forms_Visual_Reference.pdf — page 84

Review: VISUAL FAMILY REVIEW; metadata from representative originals; not every handwritten value transcribed

Approval: NO CURRENT EFFECTIVITY OR SIGNER AUTHORITY INFERRED

Archive member: References/Original_Company_Forms.zip!/ff9f9a1b-c636-4497-8169-35cbbd2198d9.JPG
