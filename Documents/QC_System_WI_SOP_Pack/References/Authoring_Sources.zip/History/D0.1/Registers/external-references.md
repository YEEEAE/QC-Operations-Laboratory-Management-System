# Official external reference register

D0.1 | DRAFT FOR REVIEW | 2026-10-03

Official catalogs/manufacturer overviews were reviewed on 2026-10-03. Licensed full standards and the actual equipment manual are still required before controlled method adoption.

## EXT-001

Title: ISO 80369-20:2024

Edition: Edition 2, 2024-11

Url: https://www.iso.org/standard/82712.html

Accessed: 2026-10-03

Review scope: Common connector test methods; official catalog scope reviewed, licensed full method clauses not reviewed.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-002

Title: ISO 80369-7:2021

Edition: Edition 2, 2021-05; review stage 90.60 observed

Url: https://www.iso.org/standard/79173.html

Accessed: 2026-10-03

Review scope: Candidate for intravascular/hypodermic connectors; does not establish every product requirement.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-003

Title: ISO 7886-1:2017

Edition: Edition 2; corrected 2019-08; replacement FDIS pending

Url: https://www.iso.org/standard/64790.html

Accessed: 2026-10-03

Review scope: Empty sterile manual hypodermic syringe design tests; catalog excludes several types and does not provide lot-release requirements.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-004

Title: ISO 20695:2020

Edition: Edition 1, 2020-03

Url: https://www.iso.org/standard/68853.html

Accessed: 2026-10-03

Review scope: Enteral system candidate. Catalog expressly excludes oral syringes.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-005

Title: ISO 20696:2018

Edition: Edition 1; corrected 2019-12; confirmed 2023

Url: https://www.iso.org/standard/68854.html

Accessed: 2026-10-03

Review scope: Single-use sterile urethral catheters; excluded drainage catheter classes require another source.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-006

Title: ISO 23368:2022

Edition: Edition 1, 2022-07

Url: https://www.iso.org/standard/75350.html

Accessed: 2026-10-03

Review scope: Low-flow nasal cannula oxygen therapy candidate; not an assumed high-flow method.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-007

Title: ISO 16321-1:2021 and Amd1:2024

Edition: Edition 1; amendment 2024-07; revision under development

Url: https://www.iso.org/standard/62527.html

Accessed: 2026-10-03

Review scope: Occupational eye/face protection candidate; specific goggle claims and applicability require review.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-008

Title: ISO 2859-1:2026

Edition: Edition 3, 2026-01

Url: https://www.iso.org/standard/2859-1

Accessed: 2026-10-03

Review scope: Attributes sampling candidate. No AQL, inspection level, sample size or switching plan adopted here.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-009

Title: ATEQ manufacturer pressure/vacuum decay overview

Edition: Undated web overview; accessed 2026-10-03

Url: https://ateq.co.uk/faq-items/how-does-pressure-decay-testing-work/

Accessed: 2026-10-03

Review scope: Supports general prepare/stabilize/test/vent sequence; not an identified manual for the photographed instrument.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-010

Title: ISO 80369-3:2016

Edition: 2016 edition; current amendments/adoption need owner check

Url: https://www.iso.org/standard/50731.html

Accessed: 2026-10-03

Review scope: Enteral connector candidate; full licensed clauses and amendments are not reviewed here.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-011

Title: ISO 5361:2023 and Amd1:2026

Edition: Edition 4; corrected 2023-11; amendment 2026

Url: https://www.iso.org/standard/77497.html

Accessed: 2026-10-03

Review scope: Tracheal tube/connectors candidate; catalog exclusions and variant applicability must be checked.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-012

Title: FDA Quality Management System Regulation

Edition: Effective 2026-02-02

Url: https://www.fda.gov/medical-devices/postmarket-requirements-devices/quality-management-system-regulation-qmsr

Accessed: 2026-10-03

Review scope: Regulatory context only. US market applicability has not been established and no compliance claim is made.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-013

Title: ATEQ leak-rate calculation overview

Edition: Undated web overview; accessed 2026-10-03

Url: https://www.ateq-leaktesting.com/products/leak-tester/

Accessed: 2026-10-03

Review scope: Qualitative support for volume/pressure/time and ideal-gas dependence. Pack equation is a dimensional technical proposal, not a copied device algorithm.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED

## EXT-014

Title: ISO 16321-1:2021/Amd1:2024

Edition: Edition 1 amendment, 2024-07

Url: https://www.iso.org/standard/84835.html

Accessed: 2026-10-03

Review scope: Amendment identity verified from official catalog; full clauses not reviewed.

Approval: CANDIDATE FOR TECHNICAL REVIEW; NOT ADOPTED
