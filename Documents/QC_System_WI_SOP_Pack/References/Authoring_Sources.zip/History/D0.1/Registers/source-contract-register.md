# Source state, field and permission references

D0.1 | DRAFT FOR REVIEW | 2026-10-03

Exact source strings supplement the step-by-step instructions. Conditional states/actions remain governed by actual server authority and open policy decisions.

## STATE-001

Source: src/modules/approvals/domain/approval.ts

Sha256: 2f95a1d911e9b59e77c2435c76c3a46938884c7e3da92d4bd7cd7e064c91cb9f

Values: APPROVAL_CASE_STATES: PENDING, IN_PROGRESS, COMPLETED, RETURNED, CANCELLED, EXPIRED, APPROVAL_WORK_STATES: PENDING, IN_PROGRESS, COMPLETED, RETURNED, CANCELLED, EXPIRED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-002

Source: src/modules/assets/calibration/domain/calibration.ts

Sha256: 42d2d65de04329b66b3ca7e4d587ac66affa469a50651ffc5d3ed7ebeba4c4f9

Values: CALIBRATION_STATES: DRAFT, SCHEDULED, SUBMITTED, APPROVED, CURRENT, DUE, OVERDUE, COMPLETED, FAILED, SUPERSEDED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-003

Source: src/modules/assets/equipment/domain/equipment.ts

Sha256: 832b857906206459c405575a79aa1f2f4ab6d172228cd812d6456ac1c4ddf190

Values: EQUIPMENT_STATES: DRAFT, ACTIVE, OUT_OF_SERVICE, UNDER_MAINTENANCE, DECOMMISSIONED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-004

Source: src/modules/assets/maintenance/domain/maintenance.ts

Sha256: 5754536cc352f2e951d27c81a32a06662a62ed79ea542eee610373c69588d289

Values: MAINTENANCE_STATES: DRAFT, PLANNED, IN_PROGRESS, COMPLETED, CANCELLED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-005

Source: src/modules/backup-recovery/domain/backup-record.ts

Sha256: 7925af8fb786e7aadd1811bef7f847e9378b74f31137e41e17d233abb5c1f089

Values: BACKUP_RUN_STATES: REQUESTED, RUNNING, CREATED, VERIFYING, VERIFIED, FAILED, EXPIRED, DELETED, RESTORE_RUN_STATES: PLANNED, AUTHORIZED, IN_PROGRESS, VALIDATING, SUCCEEDED, FAILED, ABORTED, RESTORABLE_BACKUP_STATES: CREATED, VERIFIED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-006

Source: src/modules/change-requests/domain/change-request.ts

Sha256: e7682da7c1b898f01ff4b5fe6b083d0b2632a2acc676c9db56cbfbb71dcfe916

Values: CHANGE_REQUEST_STATES: DRAFT, SUBMITTED, UNDER_REVIEW, RETURNED, APPROVED, REJECTED, APPLYING, APPLIED, APPLICATION_FAILED, CANCELLED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-007

Source: src/modules/documents/domain/document-version.ts

Sha256: 51298a64117a4b8854b71dd886a52d153558dcd32331850b66d14464c6fe47ca

Values: DOCUMENT_VERSION_STATES: CATALOG_ONLY, DRAFT, IN_REVIEW, RETURNED, APPROVED, EFFECTIVE, SUPERSEDED, ARCHIVED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-008

Source: src/modules/identity/domain/account-state.ts

Sha256: 4b0981980256dbf3b0b1a0adb2c66cc3fc73ca8ea4948fb85fa3297a289bc6c9

Values: ACCOUNT_STATES: ACTIVE, INACTIVE, DISABLED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-009

Source: src/modules/laboratory/domain/lab-state.ts

Sha256: caaf1985683ea79e2a7915513930f6e2970b5ec78596f843faf31b47e8921fa7

Values: labStates: DRAFT, SUBMITTED, UNDER_REVIEW, PENDING_QCM_APPROVAL, RETURNED, APPROVED, REJECTED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-010

Source: src/modules/quality/capa/domain/capa.ts

Sha256: 2a367db9c863161c3077e501de6ab5cdef3f52682e6422dd791b1a4807955b89

Values: CAPA_STATES: DRAFT, OPEN, IN_PROGRESS, AWAITING_VERIFICATION, EFFECTIVENESS_REVIEW, READY_FOR_CLOSURE, CLOSED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-011

Source: src/modules/quality/findings/domain/finding.ts

Sha256: b4b5faa7268cf03afa49474cc20842fe38b670ef404178daa8cd9e01f403b664

Values: FINDING_STATES: DRAFT, OPEN, UNDER_REVIEW, CLOSED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-012

Source: src/modules/quality/ncr/domain/ncr.ts

Sha256: 13d82271f4f61dddf8dbab21821598d875ca7497f67cbaab3715b3b9a3b2ba73

Values: NCR_STATES: DRAFT, OPEN, UNDER_INVESTIGATION, RCA_IN_PROGRESS, CAPA_IN_PROGRESS, READY_FOR_CLOSURE, CLOSED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-013

Source: src/modules/quality/rca/domain/rca.ts

Sha256: d01034d1f2ef0f96b14f1b96e6cc513c85444332aa483732c7cdc2bd69faeae1

Values: RCA_STATES: DRAFT, IN_PROGRESS, SUBMITTED, APPROVED, RETURNED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-014

Source: src/modules/quarantine/inspection/domain/inspection-item-mapping.ts

Sha256: bf57149a9bd7e85728236ed324fa4d39c4e492167836aad5753104b5fd04e3fe

Values: MAPPING_STATES: ACTIVE, STOPPED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-015

Source: src/modules/quarantine/inspection/domain/inspection-state.ts

Sha256: eb92ba6907fc91dc09b3fabdc0d5e9aabb6aa31a18161492e1d08b24fb85c719

Values: INSPECTION_STATES: DRAFT, SUBMITTED, UNDER_REVIEW, PENDING_QCM_APPROVAL, RETURNED, APPROVED, REJECTED, VOID

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-016

Source: src/modules/quarantine/receiving/domain/receiving-state.ts

Sha256: 52a39641f94d249f1b85af3d1e406a27bf48729630058a6615efd90ca1bbb307

Values: RECEIVING_WORKFLOW_STATES: PENDING, READY_FOR_INSPECTION, UNDER_INSPECTION, INSPECTION_COMPLETE, RELEASE_PENDING, RELEASED, HOLD, EXPIRED, CANCELLED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-017

Source: src/modules/quarantine/templates/domain/template-state.ts

Sha256: fa872e0d546589be174d2e0b593143bf804f8cd9ec6f738e253817a1f4f5b476

Values: TEMPLATE_VERSION_STATES: DRAFT, UNDER_REVIEW, APPROVED, STOPPED, VOID, SUPERSEDED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## STATE-018

Source: src/modules/tasks/domain/model.ts

Sha256: 5eb74888881cd60e013cc42e83301a6226e9e2b9fa98bdad191785f470f75a13

Values: TASK_STATES: DRAFT, OPEN, IN_PROGRESS, ON_HOLD, COMPLETED, CANCELLED

Interpretation: Declared states are not proof that every transition is implemented or authorized. Read application guards and current owner decisions.

## PAGE-RT-AUTH-001

Source: src/pages/login.astro

Sha256: b26b5d0a7b79791750594bb4c237ec05d938f03f99eb0bebf7a530a7154c152a

Values: Fields: loginIdentity, password, returnTo, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-TASK-001

Source: src/pages/tasks/index.astro

Sha256: c82c5854a755fef2bd4d79dca3e3a1081b49b1eda0fa02133a17d08372d2aee7

Values: Fields: assignee, direction, due, open, q, sort, state, Page-source permissions: PERM-TASK-BLOCK, PERM-TASK-COMPLETE, PERM-TASK-CREATE, PERM-TASK-EDIT, PERM-TASK-REOPEN

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-TASK-002

Source: src/pages/tasks/new.astro

Sha256: f090ed79d1ac722737c03086bf2e00a6d6c29d56fd4a9677b85055c2ebe4e812

Values: Fields: description, dueAt, priority, taskNo, title, Page-source permissions: PERM-TASK-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-TASK-003

Source: src/pages/tasks/[taskId].astro

Sha256: 60144e6d13eafde67ded101a1a98cced9f0c32bb158460bb45a62c0973354266

Values: Fields: action, expectedVersion, reason, Page-source permissions: PERM-TASK-BLOCK, PERM-TASK-COMPLETE, PERM-TASK-CREATE, PERM-TASK-EDIT, PERM-TASK-REOPEN

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-FIND-001

Source: src/pages/quality/findings/index.astro

Sha256: fa0f437d2c2bce959c5e84465c3236a0bb254a938a09d6d5c4fbae71a5fd8987

Values: Fields: state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-FIND-002

Source: src/pages/quality/findings/new.astro

Sha256: 74c83d6f18564d3bcd3535f87252c800023704a6dc10065ceb46181e21200ebc

Values: Fields: description, findingNo, severity, title, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-NCR-001

Source: src/pages/quality/ncr/index.astro

Sha256: 70ec21c319be17fe42dd64790d67437ac7660bc7a2bf276b617ba985e9fb3c4c

Values: Fields: state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-RCA-001

Source: src/pages/quality/rca/index.astro

Sha256: a435d56dfd814780768f995b0f2c524795d9adb5474be9ae12f463f09efd7480

Values: Fields: ncrId, state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CAPA-001

Source: src/pages/quality/capa/index.astro

Sha256: 32f8e7cd3c2adc55bcbefdf247036080453d05515fefebd454ed1954e90b03ba

Values: Fields: ncrId, state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CAPA-003

Source: src/pages/quality/capa/[capaId].astro

Sha256: 430a09ef43c030709f3a1f70b33d3c17c7652f6edab55c163da967c095a7f6a5

Values: Fields: reason, reauthenticationSecret, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REC-001

Source: src/pages/quarantine/receiving/index.astro

Sha256: e7144da91319b1bf11fa9b65b9da203ae328663e3568196be0dff819bd3db5cc

Values: Fields: expiryFrom, expiryTo, inspectionResult, inspectionStatus, itemCode, lot, ownership, purchaseOrderNo, q, quarantine, receivedFrom, receivedOn, receivedTo, releaseState, state, supplier, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REC-002

Source: src/pages/quarantine/receiving/new.astro

Sha256: f915db2889ca17365927637b6d622e89cf1b52a6dceb2c6463bc0a7c12d0ee4f

Values: Fields: description, docNo, expiryDate, itemCode, lot, purchaseOrderNo, qty, quantityUnit, receivingDate, receivingNo, supplier, Page-source permissions: PERM-QUAR-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REC-003

Source: src/pages/quarantine/receiving/[receivingId].astro

Sha256: 2a17abf63ae3f9fd9832cdebfdaf2c663c4ac7577b29de19f502dba086d8b0be

Values: Fields: description, docNo, expiryDate, inspectionNo, intent, itemCode, lot, qty, reason, receivingDate, supplier, templateVersionId, Page-source permissions: PERM-INSP-CREATE, PERM-QUAR-EDIT, PERM-QUAR-HOLD, PERM-QUAR-RELEASE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-INSP-001

Source: src/pages/quarantine/inspections/index.astro

Sha256: 973c27f38b35e138ab4ab9a452eeca5f29c91b88cf5aecc9d360be22eb425214

Values: Fields: finalResult, ownership, state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-INSP-003

Source: src/pages/quarantine/inspections/[inspectionId]/execute.astro

Sha256: f75d0de0e5020a3d4c679d3fc16a8f18cc5324cc528234d813abf75d89fa52fb

Values: Fields: , Page-source permissions: PERM-INSP-EDIT-DRAFT, PERM-INSP-SUBMIT

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-INSP-004

Source: src/pages/quarantine/inspections/[inspectionId]/review.astro

Sha256: 3276e8c9bf82db8ffcd33b6807d98be6e67c9163282fabfbe5a517431c0020f9

Values: Fields: reason, reauthenticationSecret, Page-source permissions: PERM-APR-APPROVE, PERM-APR-REJECT, PERM-APR-RETURN, PERM-APR-REVIEW, PERM-ESIG-SIGN, PERM-INSP-APPROVE, PERM-INSP-REJECT, PERM-INSP-RETURN, PERM-INSP-REVIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-QUAR-002

Source: src/pages/quarantine/admin/index.astro

Sha256: 8dc52c7b94ea56658a41db07358721d861cdafdad558cb49d31a1943c519fccb

Values: Fields: description, name, reauthenticationSecret, templateCode, versionNo, Page-source permissions: PERM-ADM-TEMPLATES

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-LAB-002

Source: src/pages/laboratory/tests/index.astro

Sha256: bd1c5e3c1bbab4eebf528b88ec882a10df2eadf1c342700e03d1a5ca5f797811

Values: Fields: direction, ownership, q, sort, state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-LAB-003

Source: src/pages/laboratory/tests/new.astro

Sha256: 63e4e4ba041a748d51506ae47e1cc966ae057141a63aded59e62d8f1e6be4257

Values: Fields: labTestNo, templateVersionId, Page-source permissions: PERM-LAB-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-LAB-009

Source: src/pages/laboratory/report-templates.astro

Sha256: 1d29ae770b5188b7eda693cc348f3642bb50951b1f242b1ffa44e52bc2be9d13

Values: Fields: connectorType, overallResult, reportType, version, Page-source permissions: PERM-LAB-CREATE, PERM-LAB-EDIT-DRAFT, PERM-LAB-VIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-LAB-004

Source: src/pages/laboratory/tests/[labTestId]/index.astro

Sha256: b8616c9f0d52564f3cab2bf60c3e8870329fe34c1865c9934fe9afb0bf63c9ad

Values: Fields: , Page-source permissions: PERM-APR-APPROVE, PERM-APR-REVIEW, PERM-ESIG-SIGN, PERM-LAB-AUTHORIZE-RETEST, PERM-LAB-EDIT-DRAFT, PERM-LAB-RETEST, PERM-LAB-RETURN, PERM-LAB-REVIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-LAB-005

Source: src/pages/laboratory/tests/[labTestId]/execute.astro

Sha256: cc5624c33461c39b9a918b344b169427d4791da51cf32783bcc7b5639503366b

Values: Fields: batchId, equipmentId, Page-source permissions: PERM-CAL-VIEW, PERM-EQP-VIEW, PERM-LAB-EDIT-DRAFT, PERM-LAB-SUBMIT, PERM-MNT-VIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-LAB-006

Source: src/pages/laboratory/tests/[labTestId]/review.astro

Sha256: ca3257239a8b0fba330def8fe13258afd6cd02494cfa965ac0ab26de2e2db02f

Values: Fields: expectedVersion, intent, reason, reauthenticationSecret, Page-source permissions: PERM-APR-APPROVE, PERM-ESIG-SIGN, PERM-LAB-APPROVE, PERM-LAB-RETURN

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-EQUIP-001

Source: src/pages/assets/equipment/index.astro

Sha256: abbdabb83816417960d23971fb221870efb088d257b56d6652333e1637b486c6

Values: Fields: q, state, Page-source permissions: PERM-EQP-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-EQUIP-002

Source: src/pages/assets/equipment/new.astro

Sha256: b072cfa082f3043d2487c60993d1ed71175c39299d9b99fb1d95f97f4ef8316a

Values: Fields: calibrationRequired, equipmentNo, location, maintenanceRequired, manufacturer, model, name, serialNo, Page-source permissions: PERM-EQP-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CAL-001

Source: src/pages/assets/calibrations/index.astro

Sha256: 9e7d3a60c52e64ec2f9dc80d124721ef36946d96214cc451883b6d2eca333f11

Values: Fields: equipmentId, q, state, Page-source permissions: PERM-CAL-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CAL-002

Source: src/pages/assets/calibrations/new.astro

Sha256: e97efcfd4b3194eb00bdc9fd02672b57132b27ca594055a5d9c2039b105c4847

Values: Fields: calibrationDate, calibrationNo, certificateNo, dueDate, equipmentId, provider, result, Page-source permissions: PERM-CAL-CREATE, PERM-EQP-VIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-MAINT-001

Source: src/pages/assets/maintenance/index.astro

Sha256: 6aeba9de67c9d826fde1c41e253485c4b6472e53df335a96d26909eb20e3ea88

Values: Fields: equipmentId, q, state, Page-source permissions: PERM-MNT-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-MAINT-002

Source: src/pages/assets/maintenance/new.astro

Sha256: 85bdb24ba1a430b659476b2eb8f342f63f9de515aeba71db4a8931022a78e14c

Values: Fields: description, equipmentId, maintenanceNo, maintenanceType, performedBy, plannedAt, provider, Page-source permissions: PERM-EQP-VIEW, PERM-MNT-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-DOC-001

Source: src/pages/documents/index.astro

Sha256: e834fa7fbd5b84d93fd54b78c1d518f43d013c0416ba1b9ff7e91ecbe92ae9bc

Values: Fields: q, type, Page-source permissions: PERM-DOC-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-DOC-002

Source: src/pages/documents/new.astro

Sha256: e03577e98829c2c94368e284dc760b72e39a820872bc456c1763ce11fecdf73b

Values: Fields: documentNo, documentType, title, Page-source permissions: PERM-DOC-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-DOC-003

Source: src/pages/documents/[documentId]/index.astro

Sha256: 7f4d602e26ac707bf426e212689a98d7defcdf852e50253fdf94dd7cc2566bd2

Values: Fields: , Page-source permissions: PERM-DOC-CREATE, PERM-DOC-REVISE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-DOC-004

Source: src/pages/documents/[documentId]/versions/new.astro

Sha256: db17b770af14f7eb1514045c4b6fc9944cb9985d5b10aaa5d4cf95d0a4b12939

Values: Fields: changeSummary, expectedDocumentVersion, expectedPredecessorId, expectedPredecessorState, expectedPredecessorVersion, fileId, revision, Page-source permissions: PERM-DOC-CREATE, PERM-DOC-REVISE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-DOC-005

Source: src/pages/documents/[documentId]/versions/[versionId]/index.astro

Sha256: 192caf957bd4226d3297d8242eabc70805672a784f8c57bbb034fdc3b49edd1c

Values: Fields: , Page-source permissions: PERM-DOC-EDIT-DRAFT, PERM-DOC-REVIEW, PERM-DOC-SUBMIT

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-DOC-006

Source: src/pages/documents/[documentId]/versions/[versionId]/review.astro

Sha256: c76344a702086043ae41db16af0eb8e86d0a59b3ca20190278b1873c070e6475

Values: Fields: , Page-source permissions: PERM-APR-REVIEW, PERM-DOC-REVIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-APPROVAL-002

Source: src/pages/approvals/[approvalId].astro

Sha256: 76114a8c90006a0b1c94ee6e9c86c6f32f5e74bdb4344fd542476ce11a9834fe

Values: Fields: approvalId, decision, reason, reauthenticationSecret, subjectVersion, workItemId, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CHANGE-001

Source: src/pages/change-requests/index.astro

Sha256: bc8feaf57eae0d63e1f49f87da6c9bdeb9cecb29e53a1fa5650e68992b2b855f

Values: Fields: state, targetType, Page-source permissions: PERM-CHG-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CHANGE-002

Source: src/pages/change-requests/new.astro

Sha256: 9df644786d3bb66f14db6c6e0722c138edd796ab7b6db454dfbe5a2a1e0e2caa

Values: Fields: changeField, changeNo, documentVersionId, expectedDocumentVersion, proposedValue, reason, Page-source permissions: PERM-CHG-CREATE, PERM-DOC-VIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CHANGE-003

Source: src/pages/change-requests/[changeRequestId]/index.astro

Sha256: a214b3cba8b9c50a30298561246a00dcff74f4b7a6e3dbd724df3451ade09daf

Values: Fields: , Page-source permissions: PERM-CHG-APPROVE, PERM-CHG-REJECT, PERM-CHG-RETURN, PERM-CHG-REVIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-CHANGE-004

Source: src/pages/change-requests/[changeRequestId]/review.astro

Sha256: b2c267b09e1e4ef751809261374989ed1cd30ade3ec91a5ef4bd87a878d66b5e

Values: Fields: action, expectedVersion, Page-source permissions: PERM-APR-REVIEW, PERM-CHG-REVIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REPORT-001

Source: src/pages/reports/index.astro

Sha256: 97653e035979756048aa006e7c8fc01d976153013552ac3d22a13959f013aae1

Values: Fields: arrow-right, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-ADMIN-001

Source: src/pages/admin/index.astro

Sha256: 65c208894491042fbd69426770db004aa3bac5cc2952c947f62310c9fe9c086f

Values: Fields: , Page-source permissions: PERM-001

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-USER-001

Source: src/pages/admin/users/index.astro

Sha256: d89cb4362ea3c26aea52ba80bf8da4068e2cce4a87d69492496edb8bbc0de069

Values: Fields: q, state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-USER-002

Source: src/pages/admin/users/new.astro

Sha256: c4abeef0b689f75a71c23d2fc7f83d15946db8354b80549988c051fe2683e5ff

Values: Fields: displayName, email, loginIdentity, roleCode, scopeKind, scopeValue-${checkbox.value}, temporaryPassword, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-USER-003

Source: src/pages/admin/users/[userId].astro

Sha256: 8407522cdb47f4723f80d7aacdd0cae237991559a87fae065fc4b6741ce628de

Values: Fields: displayName, email, kind, reason, roleId, temporaryPassword, value, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-ROLE-002

Source: src/pages/admin/roles/[roleId].astro

Sha256: 869e592a9bb05bee5640ede719dc5f323e7c8857b14c483d037159fe96b22703

Values: Fields: permission, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-SYSTEM-001

Source: src/pages/system/health.astro

Sha256: 3dfada74ea40dd872ef00eb9ed439e5c191b0f42219afdaa05d00ba33cc0be23

Values: Fields: , Page-source permissions: PERM-BKP-VIEW

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-SYSTEM-002

Source: src/pages/system/control-center.astro

Sha256: cfd06cbdace99107cfa648a253d8ca07bedcf5c4b64c8106d436cd952610e9c8

Values: Fields: dir, displayName, email, loginIdentity, q, roleCode, scopeKind, scopeValue-${checkbox.value}, sort, state, temporaryPassword, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-BACKUP-001

Source: src/pages/system/backups/index.astro

Sha256: 8fcba528b3f8100257bd7883183e4c8460f497fdbfbc2042ffcadb1ee1a059c2

Values: Fields: state, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-BACKUP-002

Source: src/pages/system/backups/[backupId]/index.astro

Sha256: fddd3974e156dcda7b3ce61364c6e21e8af17123cf4aa3c46a597c7763e26161

Values: Fields: , Page-source permissions: PERM-BKP-RESTORE-DRILL

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-BACKUP-003

Source: src/pages/system/backups/[backupId]/restore.astro

Sha256: 03474e1ee7141984106e60efcee3ae1728377887db7cd88d430731e2ee4915ae

Values: Fields: confirmRestore, expectedVersion, idempotencyKey, reason, restoreType, targetEnvironment, Page-source permissions: PERM-BKP-RESTORE-DRILL, PERM-BKP-RESTORE-PRODUCTION

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REJ-001

Source: src/pages/reject-reports/index.astro

Sha256: 6bc20b5fa5ac81cac40844ccb5d5870175b637cfc1cfc9b046ebc430dbc20c77

Values: Fields: department, from, itemCode, itemName, lot, q, status, tab, to, unit, unitMissing, Page-source permissions: PERM-RREJ-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REJ-002

Source: src/pages/reject-reports/new.astro

Sha256: 9f34c673b2f3240820c949784b2b0baccf2ba01364a6bbb9c648290a079a6175

Values: Fields: analysis, buRmProductName, department, goodQty, goodsDescription, itemCode, itemDescription, itemName, lotNo, machineName, productionFormula, pumpOutQty, rejectLimit, rejectQty, rejectReason, rejectedQty, remarks, reportDate, reportType, rmDescription, rmLotNo, rmType, rmUnit, shift, totalValue, unit, unitCost, Page-source permissions: PERM-RREJ-CREATE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REJ-003

Source: src/pages/reject-reports/issue-slips/[reportId].astro

Sha256: 72a02c17b9ae5d9862f2a61f46e9905adcf1839d5bf0e7cf727f4068abfe6b56

Values: Fields: approverName, expectedVersion, intent, reason, role, Page-source permissions: PERM-RREJ-ADMIN-CORRECT, PERM-RREJ-CONFIRM-APPROVAL, PERM-RREJ-EDIT, PERM-RREJ-VOID

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REJ-004

Source: src/pages/reject-reports/daily/[reportId].astro

Sha256: 4da73f27fdb522ef60dc12c83e5a2fd5b7cdfc2268dbe0bce9566ad2aedbcb23

Values: Fields: analysis, buRmProductName, expectedVersion, goodQty, intent, itemCode, itemDescription, lotNo, machineName, productionFormula, pumpOutQty, reason, rejectLimit, rejectQty, rejectReason, rmDescription, rmLotNo, rmType, rmUnit, Page-source permissions: PERM-RREJ-EDIT, PERM-RREJ-VOID

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-AI-001

Source: src/pages/ai-advisory.astro

Sha256: 3b09dd25ac1798e848879687239584529a7be9d0a01366bb12cc478b8834153d

Values: Fields: citation, consentToExternalProcessing, contextContent, contextLabel, dataClass, mode, question, sourceId, sourceType, Page-source permissions: PERM-AI-DRAFT, PERM-AI-SUGGEST, PERM-AI-SUMMARIZE, PERM-AI-USE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-SHARED-001

Source: src/pages/search.astro

Sha256: 481cf413019b734eb8806d834760ac683248c00aacd39dea8da9cf6cdac44954

Values: Fields: q, Page-source permissions: PERM-SRCH-USE

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-SHARED-002

Source: src/pages/notifications.astro

Sha256: 6f6098b28c260014e3bfa7a270874a92da9c5db1aa9807250a673b942157b525

Values: Fields: notificationId, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-SHARED-003

Source: src/pages/account.astro

Sha256: b11a75312e3a4813e1f6adf14c88e91b087dca9b2aaad324249e2565f81d42a6

Values: Fields: currentPassword, newPassword, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-SHARED-004

Source: src/pages/audit.astro

Sha256: abaec2b92b2a160f196889259e8ed49a1598f28dae0464a6539dc16837d9d156

Values: Fields: action, actorId, from, limit, subjectId, subjectType, to, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-QUAR-003

Source: src/pages/quarantine/admin/[templateId].astro

Sha256: 2c8c4680819f683a7d23a25255a73a12ff7fdda35dadd54a74eb05207bcaab22

Values: Fields: description, expectedVersion, intent, name, reason, reauthenticationSecret, versionNo, Page-source permissions: PERM-ADM-TEMPLATES

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-DOC-007

Source: src/pages/documents/[documentId]/versions/[versionId]/edit.astro

Sha256: 13d1c5fd0dc677f7f972da9f034379710bccb99a8708db48fe296801a82f7ce8

Values: Fields: changeSummary, expectedContentHash, expectedVersion, revision, Page-source permissions: PERM-DOC-EDIT-DRAFT

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.

## PAGE-RT-REL-001

Source: src/pages/governance/releases/[releaseId].astro

Sha256: aed4ca8f57941baa4cec45d708fbd418bfb3af5c0ab7317a8032b0f4ff50b39c

Values: Fields: expectedVersion, reauthenticationSecret, releaseId, Page-source permissions: 

Interpretation: Literal page-source strings only; application use-case grants remain authoritative. Dynamic fields/imported permissions may be defined elsewhere.
