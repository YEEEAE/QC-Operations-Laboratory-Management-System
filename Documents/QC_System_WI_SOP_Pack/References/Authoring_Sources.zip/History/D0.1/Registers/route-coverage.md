# Route coverage matrix

D0.1 | DRAFT FOR REVIEW | 2026-10-03

86 canonical routes plus separate /404 and /500 source pages = 88. All are mapped; route fields and permissions are source-text extractions, not runtime authority grants.

## RT-ROOT-001

Route: /

File: src/pages/index.astro

Sha256: 5a629664fc5ae70fae532f09fa139849d30cbd53afee3d90d7eb56639d81ac93

Visibility: public

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-AUTH-001

Route: /login

File: src/pages/login.astro

Sha256: b26b5d0a7b79791750594bb4c237ec05d938f03f99eb0bebf7a530a7154c152a

Visibility: public

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: loginIdentity, password, returnTo

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DASH-001

Route: /dashboard

File: src/pages/dashboard/index.astro

Sha256: 672d0501c5f895b798e1996a6ef81471c60b37126d483f059431044fe346f1ee

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-026

Wi: QC-WI-044

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-WORK-001

Route: /work

File: src/pages/work/index.astro

Sha256: 28b82c38cab1c37a1c4a217ee70c7ef2bdfa5de26e6d8bd0748c56b19d3874ac

Visibility: authenticated

Expectation: required

Sop: QC-SOP-026

Wi: QC-WI-044

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-TASK-001

Route: /tasks

File: src/pages/tasks/index.astro

Sha256: c82c5854a755fef2bd4d79dca3e3a1081b49b1eda0fa02133a17d08372d2aee7

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-019

Wi: QC-WI-031

Source fields: assignee, direction, due, open, q, sort, state

Source permissions: PERM-TASK-BLOCK, PERM-TASK-COMPLETE, PERM-TASK-CREATE, PERM-TASK-EDIT, PERM-TASK-REOPEN

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-TASK-002

Route: /tasks/new

File: src/pages/tasks/new.astro

Sha256: f090ed79d1ac722737c03086bf2e00a6d6c29d56fd4a9677b85055c2ebe4e812

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-019

Wi: QC-WI-031

Source fields: description, dueAt, priority, taskNo, title

Source permissions: PERM-TASK-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-TASK-003

Route: /tasks/[taskId]

File: src/pages/tasks/[taskId].astro

Sha256: 60144e6d13eafde67ded101a1a98cced9f0c32bb158460bb45a62c0973354266

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-019

Wi: QC-WI-031

Source fields: action, expectedVersion, reason

Source permissions: PERM-TASK-BLOCK, PERM-TASK-COMPLETE, PERM-TASK-CREATE, PERM-TASK-EDIT, PERM-TASK-REOPEN

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-QUAL-001

Route: /quality

File: src/pages/quality/index.astro

Sha256: 59b01041edd83940c4ae12256b05ac4f212b6bf31bceda9e9e437d0310e59882

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-FIND-001

Route: /quality/findings

File: src/pages/quality/findings/index.astro

Sha256: fa0f437d2c2bce959c5e84465c3236a0bb254a938a09d6d5c4fbae71a5fd8987

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Source fields: state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-FIND-002

Route: /quality/findings/new

File: src/pages/quality/findings/new.astro

Sha256: 74c83d6f18564d3bcd3535f87252c800023704a6dc10065ceb46181e21200ebc

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Source fields: description, findingNo, severity, title

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-FIND-003

Route: /quality/findings/[findingId]

File: src/pages/quality/findings/[findingId].astro

Sha256: 72051884c445abb0504ba6866c215a4e9e9183bb9b7b95ea25b97500fe89a080

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-NCR-001

Route: /quality/ncr

File: src/pages/quality/ncr/index.astro

Sha256: 70ec21c319be17fe42dd64790d67437ac7660bc7a2bf276b617ba985e9fb3c4c

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-017

Wi: QC-WI-027

Source fields: state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-NCR-002

Route: /quality/ncr/new

File: src/pages/quality/ncr/new.astro

Sha256: 2a380960c6dfa7c40b6ec78dd30a00b578c2c1fb317961e2d6ee59a33a282462

Visibility: permission-bound

Expectation: conditional

Sop: QC-SOP-017

Wi: QC-WI-027

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-NCR-003

Route: /quality/ncr/[ncrId]

File: src/pages/quality/ncr/[ncrId].astro

Sha256: 0ec3aa3eed2da1b3a163992987245740a73e87c80fcc3179b0fb3bc84dac76f1

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-017

Wi: QC-WI-027

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-RCA-001

Route: /quality/rca

File: src/pages/quality/rca/index.astro

Sha256: a435d56dfd814780768f995b0f2c524795d9adb5474be9ae12f463f09efd7480

Visibility: permission-bound

Expectation: conditional

Sop: QC-SOP-018

Wi: QC-WI-028

Source fields: ncrId, state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-RCA-002

Route: /quality/rca/[rcaId]

File: src/pages/quality/rca/[rcaId].astro

Sha256: 9b67adeffe0086f4f428a871c9a19e612e754e73d61a27e25f386a9ac1bbb92c

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-018

Wi: QC-WI-028

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CAPA-001

Route: /quality/capa

File: src/pages/quality/capa/index.astro

Sha256: 32f8e7cd3c2adc55bcbefdf247036080453d05515fefebd454ed1954e90b03ba

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-018

Wi: QC-WI-029, QC-WI-030

Source fields: ncrId, state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CAPA-002

Route: /quality/capa/new

File: src/pages/quality/capa/new.astro

Sha256: fd00ca40ddc5bb8fafba5383ddedeec7bbb1ebda3a21155cf4fb74a5f7d16440

Visibility: permission-bound

Expectation: conditional

Sop: QC-SOP-018

Wi: QC-WI-029, QC-WI-030

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CAPA-003

Route: /quality/capa/[capaId]

File: src/pages/quality/capa/[capaId].astro

Sha256: 430a09ef43c030709f3a1f70b33d3c17c7652f6edab55c163da967c095a7f6a5

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-018

Wi: QC-WI-029, QC-WI-030

Source fields: reason, reauthenticationSecret

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-QUAR-001

Route: /quarantine

File: src/pages/quarantine/index.astro

Sha256: a75e3b8454ecaf24ab8aea816fba51e47d667ff5ff0a3c8c666200f0272107f9

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-006

Wi: QC-WI-003, QC-WI-004, QC-WI-005

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REC-001

Route: /quarantine/receiving

File: src/pages/quarantine/receiving/index.astro

Sha256: e7144da91319b1bf11fa9b65b9da203ae328663e3568196be0dff819bd3db5cc

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-004

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-007, QC-WI-008

Source fields: expiryFrom, expiryTo, inspectionResult, inspectionStatus, itemCode, lot, ownership, purchaseOrderNo, q, quarantine, receivedFrom, receivedOn, receivedTo, releaseState, state, supplier

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REC-002

Route: /quarantine/receiving/new

File: src/pages/quarantine/receiving/new.astro

Sha256: f915db2889ca17365927637b6d622e89cf1b52a6dceb2c6463bc0a7c12d0ee4f

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-004

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-007, QC-WI-008

Source fields: description, docNo, expiryDate, itemCode, lot, purchaseOrderNo, qty, quantityUnit, receivingDate, receivingNo, supplier

Source permissions: PERM-QUAR-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REC-003

Route: /quarantine/receiving/[receivingId]

File: src/pages/quarantine/receiving/[receivingId].astro

Sha256: 2a17abf63ae3f9fd9832cdebfdaf2c663c4ac7577b29de19f502dba086d8b0be

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-004

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-007, QC-WI-008

Source fields: description, docNo, expiryDate, inspectionNo, intent, itemCode, lot, qty, reason, receivingDate, supplier, templateVersionId

Source permissions: PERM-INSP-CREATE, PERM-QUAR-EDIT, PERM-QUAR-HOLD, PERM-QUAR-RELEASE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-INSP-001

Route: /quarantine/inspections

File: src/pages/quarantine/inspections/index.astro

Sha256: 973c27f38b35e138ab4ab9a452eeca5f29c91b88cf5aecc9d360be22eb425214

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-008

Wi: QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-037, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Source fields: finalResult, ownership, state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-INSP-002

Route: /quarantine/inspections/[inspectionId]

File: src/pages/quarantine/inspections/[inspectionId]/index.astro

Sha256: 191927e929c2c65e8f463aef30a61c576bc50b57df0c62326485c2bc92e635d8

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-008

Wi: QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-037, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-INSP-003

Route: /quarantine/inspections/[inspectionId]/execute

File: src/pages/quarantine/inspections/[inspectionId]/execute.astro

Sha256: f75d0de0e5020a3d4c679d3fc16a8f18cc5324cc528234d813abf75d89fa52fb

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-008

Wi: QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-037, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Source fields: 

Source permissions: PERM-INSP-EDIT-DRAFT, PERM-INSP-SUBMIT

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-INSP-004

Route: /quarantine/inspections/[inspectionId]/review

File: src/pages/quarantine/inspections/[inspectionId]/review.astro

Sha256: 3276e8c9bf82db8ffcd33b6807d98be6e67c9163282fabfbe5a517431c0020f9

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-008

Wi: QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-037, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Source fields: reason, reauthenticationSecret

Source permissions: PERM-APR-APPROVE, PERM-APR-REJECT, PERM-APR-RETURN, PERM-APR-REVIEW, PERM-ESIG-SIGN, PERM-INSP-APPROVE, PERM-INSP-REJECT, PERM-INSP-RETURN, PERM-INSP-REVIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-QUAR-002

Route: /quarantine/admin

File: src/pages/quarantine/admin/index.astro

Sha256: 8dc52c7b94ea56658a41db07358721d861cdafdad558cb49d31a1943c519fccb

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-037, QC-WI-066

Source fields: description, name, reauthenticationSecret, templateCode, versionNo

Source permissions: PERM-ADM-TEMPLATES

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-001

Route: /laboratory

File: src/pages/laboratory/index.astro

Sha256: 15a244c0ab5b456d181745fd800d58321482f90ad73600d9634075b0edf1fa3e

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-009

Wi: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-050, QC-WI-051

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-002

Route: /laboratory/tests

File: src/pages/laboratory/tests/index.astro

Sha256: bd1c5e3c1bbab4eebf528b88ec882a10df2eadf1c342700e03d1a5ca5f797811

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-009

Wi: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-050, QC-WI-051

Source fields: direction, ownership, q, sort, state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-003

Route: /laboratory/tests/new

File: src/pages/laboratory/tests/new.astro

Sha256: 63e4e4ba041a748d51506ae47e1cc966ae057141a63aded59e62d8f1e6be4257

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-009

Wi: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-050, QC-WI-051

Source fields: labTestNo, templateVersionId

Source permissions: PERM-LAB-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-009

Route: /laboratory/report-templates

File: src/pages/laboratory/report-templates.astro

Sha256: 1d29ae770b5188b7eda693cc348f3642bb50951b1f242b1ffa44e52bc2be9d13

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-013

Wi: QC-WI-021, QC-WI-050, QC-WI-051

Source fields: connectorType, overallResult, reportType, version

Source permissions: PERM-LAB-CREATE, PERM-LAB-EDIT-DRAFT, PERM-LAB-VIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-004

Route: /laboratory/tests/[labTestId]

File: src/pages/laboratory/tests/[labTestId]/index.astro

Sha256: b8616c9f0d52564f3cab2bf60c3e8870329fe34c1865c9934fe9afb0bf63c9ad

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-009

Wi: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-050, QC-WI-051

Source fields: 

Source permissions: PERM-APR-APPROVE, PERM-APR-REVIEW, PERM-ESIG-SIGN, PERM-LAB-AUTHORIZE-RETEST, PERM-LAB-EDIT-DRAFT, PERM-LAB-RETEST, PERM-LAB-RETURN, PERM-LAB-REVIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-005

Route: /laboratory/tests/[labTestId]/execute

File: src/pages/laboratory/tests/[labTestId]/execute.astro

Sha256: cc5624c33461c39b9a918b344b169427d4791da51cf32783bcc7b5639503366b

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-009

Wi: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-050, QC-WI-051

Source fields: batchId, equipmentId

Source permissions: PERM-CAL-VIEW, PERM-EQP-VIEW, PERM-LAB-EDIT-DRAFT, PERM-LAB-SUBMIT, PERM-MNT-VIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-006

Route: /laboratory/tests/[labTestId]/review

File: src/pages/laboratory/tests/[labTestId]/review.astro

Sha256: ca3257239a8b0fba330def8fe13258afd6cd02494cfa965ac0ab26de2e2db02f

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-009

Wi: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-050, QC-WI-051

Source fields: expectedVersion, intent, reason, reauthenticationSecret

Source permissions: PERM-APR-APPROVE, PERM-ESIG-SIGN, PERM-LAB-APPROVE, PERM-LAB-RETURN

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-LAB-007

Route: /laboratory/tests/[labTestId]/retests/new

File: src/pages/laboratory/tests/[labTestId]/retests/new.astro

Sha256: 134d21b7a05eb98502a98b9e0ff30f3d034e9e161ca571c9a5a0633ef84a338c

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-009

Wi: QC-WI-012, QC-WI-013, QC-WI-014, QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-050, QC-WI-051

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ASSET-001

Route: /assets

File: src/pages/assets/index.astro

Sha256: c1f0d30cc649bb02919159bea9bfe324d73d8474ca66451180b477bddbc829fb

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-EQUIP-001

Route: /assets/equipment

File: src/pages/assets/equipment/index.astro

Sha256: abbdabb83816417960d23971fb221870efb088d257b56d6652333e1637b486c6

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034

Source fields: q, state

Source permissions: PERM-EQP-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-EQUIP-002

Route: /assets/equipment/new

File: src/pages/assets/equipment/new.astro

Sha256: b072cfa082f3043d2487c60993d1ed71175c39299d9b99fb1d95f97f4ef8316a

Visibility: permission-bound

Expectation: conditional

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034

Source fields: calibrationRequired, equipmentNo, location, maintenanceRequired, manufacturer, model, name, serialNo

Source permissions: PERM-EQP-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-EQUIP-003

Route: /assets/equipment/[equipmentId]

File: src/pages/assets/equipment/[equipmentId].astro

Sha256: 0dbfe222e4d19b00af93f1664fe9c95e4f48d4a8e3f807bc790959ac655ded71

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CAL-001

Route: /assets/calibrations

File: src/pages/assets/calibrations/index.astro

Sha256: 9e7d3a60c52e64ec2f9dc80d124721ef36946d96214cc451883b6d2eca333f11

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-021

Wi: QC-WI-033

Source fields: equipmentId, q, state

Source permissions: PERM-CAL-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CAL-002

Route: /assets/calibrations/new

File: src/pages/assets/calibrations/new.astro

Sha256: e97efcfd4b3194eb00bdc9fd02672b57132b27ca594055a5d9c2039b105c4847

Visibility: permission-bound

Expectation: conditional

Sop: QC-SOP-021

Wi: QC-WI-033

Source fields: calibrationDate, calibrationNo, certificateNo, dueDate, equipmentId, provider, result

Source permissions: PERM-CAL-CREATE, PERM-EQP-VIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CAL-003

Route: /assets/calibrations/[calibrationId]

File: src/pages/assets/calibrations/[calibrationId].astro

Sha256: 4ef2868c740e1c37a834d60d7029da03e1f2dad7dc6c07f0d3c8af0cc1ce3e50

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-021

Wi: QC-WI-033

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-MAINT-001

Route: /assets/maintenance

File: src/pages/assets/maintenance/index.astro

Sha256: 6aeba9de67c9d826fde1c41e253485c4b6472e53df335a96d26909eb20e3ea88

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-021

Wi: QC-WI-034, QC-WI-041

Source fields: equipmentId, q, state

Source permissions: PERM-MNT-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-MAINT-002

Route: /assets/maintenance/new

File: src/pages/assets/maintenance/new.astro

Sha256: 85bdb24ba1a430b659476b2eb8f342f63f9de515aeba71db4a8931022a78e14c

Visibility: permission-bound

Expectation: conditional

Sop: QC-SOP-021

Wi: QC-WI-034, QC-WI-041

Source fields: description, equipmentId, maintenanceNo, maintenanceType, performedBy, plannedAt, provider

Source permissions: PERM-EQP-VIEW, PERM-MNT-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-MAINT-003

Route: /assets/maintenance/[maintenanceId]

File: src/pages/assets/maintenance/[maintenanceId].astro

Sha256: c4d2690a666460ec4937e90f05a165b9f7db88dc6ff2a2f46e1db8f2801896d3

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-021

Wi: QC-WI-034, QC-WI-041

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DOC-001

Route: /documents

File: src/pages/documents/index.astro

Sha256: e834fa7fbd5b84d93fd54b78c1d518f43d013c0416ba1b9ff7e91ecbe92ae9bc

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-063

Source fields: q, type

Source permissions: PERM-DOC-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DOC-002

Route: /documents/new

File: src/pages/documents/new.astro

Sha256: e03577e98829c2c94368e284dc760b72e39a820872bc456c1763ce11fecdf73b

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-063

Source fields: documentNo, documentType, title

Source permissions: PERM-DOC-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DOC-003

Route: /documents/[documentId]

File: src/pages/documents/[documentId]/index.astro

Sha256: 7f4d602e26ac707bf426e212689a98d7defcdf852e50253fdf94dd7cc2566bd2

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-063

Source fields: 

Source permissions: PERM-DOC-CREATE, PERM-DOC-REVISE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DOC-004

Route: /documents/[documentId]/versions/new

File: src/pages/documents/[documentId]/versions/new.astro

Sha256: db17b770af14f7eb1514045c4b6fc9944cb9985d5b10aaa5d4cf95d0a4b12939

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-063

Source fields: changeSummary, expectedDocumentVersion, expectedPredecessorId, expectedPredecessorState, expectedPredecessorVersion, fileId, revision

Source permissions: PERM-DOC-CREATE, PERM-DOC-REVISE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DOC-005

Route: /documents/[documentId]/versions/[versionId]

File: src/pages/documents/[documentId]/versions/[versionId]/index.astro

Sha256: 192caf957bd4226d3297d8242eabc70805672a784f8c57bbb034fdc3b49edd1c

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-063

Source fields: 

Source permissions: PERM-DOC-EDIT-DRAFT, PERM-DOC-REVIEW, PERM-DOC-SUBMIT

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DOC-006

Route: /documents/[documentId]/versions/[versionId]/review

File: src/pages/documents/[documentId]/versions/[versionId]/review.astro

Sha256: c76344a702086043ae41db16af0eb8e86d0a59b3ca20190278b1873c070e6475

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-063

Source fields: 

Source permissions: PERM-APR-REVIEW, PERM-DOC-REVIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-APPROVAL-001

Route: /approvals

File: src/pages/approvals/index.astro

Sha256: f63728a870a21eff00425b6962b7abfb94dd4d061a48094c18f87d09e499bc89

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-APPROVAL-002

Route: /approvals/[approvalId]

File: src/pages/approvals/[approvalId].astro

Sha256: 76114a8c90006a0b1c94ee6e9c86c6f32f5e74bdb4344fd542476ce11a9834fe

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Source fields: approvalId, decision, reason, reauthenticationSecret, subjectVersion, workItemId

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CHANGE-001

Route: /change-requests

File: src/pages/change-requests/index.astro

Sha256: bc8feaf57eae0d63e1f49f87da6c9bdeb9cecb29e53a1fa5650e68992b2b855f

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Source fields: state, targetType

Source permissions: PERM-CHG-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CHANGE-002

Route: /change-requests/new

File: src/pages/change-requests/new.astro

Sha256: 9df644786d3bb66f14db6c6e0722c138edd796ab7b6db454dfbe5a2a1e0e2caa

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Source fields: changeField, changeNo, documentVersionId, expectedDocumentVersion, proposedValue, reason

Source permissions: PERM-CHG-CREATE, PERM-DOC-VIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CHANGE-003

Route: /change-requests/[changeRequestId]

File: src/pages/change-requests/[changeRequestId]/index.astro

Sha256: a214b3cba8b9c50a30298561246a00dcff74f4b7a6e3dbd724df3451ade09daf

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Source fields: 

Source permissions: PERM-CHG-APPROVE, PERM-CHG-REJECT, PERM-CHG-RETURN, PERM-CHG-REVIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-CHANGE-004

Route: /change-requests/[changeRequestId]/review

File: src/pages/change-requests/[changeRequestId]/review.astro

Sha256: b2c267b09e1e4ef751809261374989ed1cd30ade3ec91a5ef4bd87a878d66b5e

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Source fields: action, expectedVersion

Source permissions: PERM-APR-REVIEW, PERM-CHG-REVIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REPORT-001

Route: /reports

File: src/pages/reports/index.astro

Sha256: 97653e035979756048aa006e7c8fc01d976153013552ac3d22a13959f013aae1

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-025

Wi: QC-WI-043, QC-WI-068

Source fields: arrow-right

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REPORT-002

Route: /reports/[reportCode]

File: src/pages/reports/[reportCode].astro

Sha256: 90053511971000b321fd2e7dd968c055c6d5099d5e0d8e63d232fd2de713c903

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-025

Wi: QC-WI-043, QC-WI-068

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ADMIN-001

Route: /admin

File: src/pages/admin/index.astro

Sha256: 65c208894491042fbd69426770db004aa3bac5cc2952c947f62310c9fe9c086f

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: 

Source permissions: PERM-001

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-USER-001

Route: /admin/users

File: src/pages/admin/users/index.astro

Sha256: d89cb4362ea3c26aea52ba80bf8da4068e2cce4a87d69492496edb8bbc0de069

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: q, state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-USER-002

Route: /admin/users/new

File: src/pages/admin/users/new.astro

Sha256: c4abeef0b689f75a71c23d2fc7f83d15946db8354b80549988c051fe2683e5ff

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: displayName, email, loginIdentity, roleCode, scopeKind, scopeValue-${checkbox.value}, temporaryPassword

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-USER-003

Route: /admin/users/[userId]

File: src/pages/admin/users/[userId].astro

Sha256: 8407522cdb47f4723f80d7aacdd0cae237991559a87fae065fc4b6741ce628de

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: displayName, email, kind, reason, roleId, temporaryPassword, value

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ROLE-001

Route: /admin/roles

File: src/pages/admin/roles/index.astro

Sha256: c4bcd34c4f363c602eeea8eb6ab3a16e4ff9157b23f3dbad7612968b14fe65ce

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ROLE-002

Route: /admin/roles/[roleId]

File: src/pages/admin/roles/[roleId].astro

Sha256: 869e592a9bb05bee5640ede719dc5f323e7c8857b14c483d037159fe96b22703

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: permission

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ADMIN-002

Route: /admin/permissions

File: src/pages/admin/permissions/index.astro

Sha256: c3967d5d84fbf17718fa32054dff3d4c1e1094ba46302c5513795e6a436fc5f8

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ADMIN-003

Route: /admin/scopes

File: src/pages/admin/scopes/index.astro

Sha256: 981eb52fd0acfce8c93b4cb553d6114817eaade7a6771ba8ee3f661ce0a1581d

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-SYSTEM-001

Route: /system/health

File: src/pages/system/health.astro

Sha256: 3dfada74ea40dd872ef00eb9ed439e5c191b0f42219afdaa05d00ba33cc0be23

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-028

Wi: QC-WI-046, QC-WI-064, QC-WI-065

Source fields: 

Source permissions: PERM-BKP-VIEW

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-SYSTEM-002

Route: /system/control-center

File: src/pages/system/control-center.astro

Sha256: cfd06cbdace99107cfa648a253d8ca07bedcf5c4b64c8106d436cd952610e9c8

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-028

Wi: QC-WI-046, QC-WI-064, QC-WI-065

Source fields: dir, displayName, email, loginIdentity, q, roleCode, scopeKind, scopeValue-${checkbox.value}, sort, state, temporaryPassword

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-BACKUP-001

Route: /system/backups

File: src/pages/system/backups/index.astro

Sha256: 8fcba528b3f8100257bd7883183e4c8460f497fdbfbc2042ffcadb1ee1a059c2

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Source fields: state

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-BACKUP-002

Route: /system/backups/[backupId]

File: src/pages/system/backups/[backupId]/index.astro

Sha256: fddd3974e156dcda7b3ce61364c6e21e8af17123cf4aa3c46a597c7763e26161

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Source fields: 

Source permissions: PERM-BKP-RESTORE-DRILL

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-BACKUP-003

Route: /system/backups/[backupId]/restore

File: src/pages/system/backups/[backupId]/restore.astro

Sha256: 03474e1ee7141984106e60efcee3ae1728377887db7cd88d430731e2ee4915ae

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Source fields: confirmRestore, expectedVersion, idempotencyKey, reason, restoreType, targetEnvironment

Source permissions: PERM-BKP-RESTORE-DRILL, PERM-BKP-RESTORE-PRODUCTION

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REJ-001

Route: /reject-reports

File: src/pages/reject-reports/index.astro

Sha256: 6bc20b5fa5ac81cac40844ccb5d5870175b637cfc1cfc9b046ebc430dbc20c77

Visibility: authenticated

Expectation: required

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024

Source fields: department, from, itemCode, itemName, lot, q, status, tab, to, unit, unitMissing

Source permissions: PERM-RREJ-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REJ-002

Route: /reject-reports/new

File: src/pages/reject-reports/new.astro

Sha256: 9f34c673b2f3240820c949784b2b0baccf2ba01364a6bbb9c648290a079a6175

Visibility: authenticated

Expectation: required

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024

Source fields: analysis, buRmProductName, department, goodQty, goodsDescription, itemCode, itemDescription, itemName, lotNo, machineName, productionFormula, pumpOutQty, rejectLimit, rejectQty, rejectReason, rejectedQty, remarks, reportDate, reportType, rmDescription, rmLotNo, rmType, rmUnit, shift, totalValue, unit, unitCost

Source permissions: PERM-RREJ-CREATE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REJ-003

Route: /reject-reports/issue-slips/[reportId]

File: src/pages/reject-reports/issue-slips/[reportId].astro

Sha256: 72a02c17b9ae5d9862f2a61f46e9905adcf1839d5bf0e7cf727f4068abfe6b56

Visibility: authenticated

Expectation: required

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024

Source fields: approverName, expectedVersion, intent, reason, role

Source permissions: PERM-RREJ-ADMIN-CORRECT, PERM-RREJ-CONFIRM-APPROVAL, PERM-RREJ-EDIT, PERM-RREJ-VOID

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REJ-004

Route: /reject-reports/daily/[reportId]

File: src/pages/reject-reports/daily/[reportId].astro

Sha256: 4da73f27fdb522ef60dc12c83e5a2fd5b7cdfc2268dbe0bce9566ad2aedbcb23

Visibility: authenticated

Expectation: required

Sop: QC-SOP-015

Wi: QC-WI-024

Source fields: analysis, buRmProductName, expectedVersion, goodQty, intent, itemCode, itemDescription, lotNo, machineName, productionFormula, pumpOutQty, reason, rejectLimit, rejectQty, rejectReason, rmDescription, rmLotNo, rmType, rmUnit

Source permissions: PERM-RREJ-EDIT, PERM-RREJ-VOID

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-AI-001

Route: /ai-advisory

File: src/pages/ai-advisory.astro

Sha256: 3b09dd25ac1798e848879687239584529a7be9d0a01366bb12cc478b8834153d

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-027

Wi: QC-WI-045

Source fields: citation, consentToExternalProcessing, contextContent, contextLabel, dataClass, mode, question, sourceId, sourceType

Source permissions: PERM-AI-DRAFT, PERM-AI-SUGGEST, PERM-AI-SUMMARIZE, PERM-AI-USE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-SHARED-001

Route: /search

File: src/pages/search.astro

Sha256: 481cf413019b734eb8806d834760ac683248c00aacd39dea8da9cf6cdac44954

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-026

Wi: QC-WI-044

Source fields: q

Source permissions: PERM-SRCH-USE

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-SHARED-002

Route: /notifications

File: src/pages/notifications.astro

Sha256: 6f6098b28c260014e3bfa7a270874a92da9c5db1aa9807250a673b942157b525

Visibility: authenticated

Expectation: required

Sop: QC-SOP-026

Wi: QC-WI-044

Source fields: notificationId

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-SHARED-003

Route: /account

File: src/pages/account.astro

Sha256: b11a75312e3a4813e1f6adf14c88e91b087dca9b2aaad324249e2565f81d42a6

Visibility: authenticated

Expectation: required

Sop: QC-SOP-003

Wi: QC-WI-040

Source fields: currentPassword, newPassword

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-SHARED-004

Route: /audit

File: src/pages/audit.astro

Sha256: abaec2b92b2a160f196889259e8ed49a1598f28dae0464a6539dc16837d9d156

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-024

Wi: QC-WI-062

Source fields: action, actorId, from, limit, subjectId, subjectType, to

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-HELP-001

Route: /help

File: src/pages/help/index.astro

Sha256: faf4f70c9e6178ccf9a4163899a7f7e700dfd7e1c8645c161484bad43fd82206

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-QUAR-003

Route: /quarantine/admin/[templateId]

File: src/pages/quarantine/admin/[templateId].astro

Sha256: 2c8c4680819f683a7d23a25255a73a12ff7fdda35dadd54a74eb05207bcaab22

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-037, QC-WI-066

Source fields: description, expectedVersion, intent, name, reason, reauthenticationSecret, versionNo

Source permissions: PERM-ADM-TEMPLATES

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-DOC-007

Route: /documents/[documentId]/versions/[versionId]/edit

File: src/pages/documents/[documentId]/versions/[versionId]/edit.astro

Sha256: 13d1c5fd0dc677f7f972da9f034379710bccb99a8708db48fe296801a82f7ce8

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037, QC-WI-063

Source fields: changeSummary, expectedContentHash, expectedVersion, revision

Source permissions: PERM-DOC-EDIT-DRAFT

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-REL-001

Route: /governance/releases/[releaseId]

File: src/pages/governance/releases/[releaseId].astro

Sha256: aed4ca8f57941baa4cec45d708fbd418bfb3af5c0ab7317a8032b0f4ff50b39c

Visibility: permission-bound

Expectation: required

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Source fields: expectedVersion, reauthenticationSecret, releaseId

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ERROR-404

Route: /404

File: src/pages/404.astro

Sha256: 92309a0216f8a19175724b4e839ca61adaad96219410336a9b3868c0adcf69b0

Visibility: public

Expectation: separate error page

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED

## RT-ERROR-500

Route: /500

File: src/pages/500.astro

Sha256: a60d54bc4f70d1e8ad994a047a1d1e86f5b771f72c4b32517cf8fceb31bc21ef

Visibility: public

Expectation: separate error page

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046

Source fields: 

Source permissions: 

Status: DOCUMENTATION MAPPED; RUNTIME/ACCESSIBILITY/UAT NOT ACCEPTED
