# Coverage limits and digital implementation gaps

D0.1 | DRAFT FOR REVIEW | 2026-10-03

Every discovered source route/module/image is mapped. A mapped draft is not an approved method or proof that the proposed physical process is digitized.

## GAP-001

Area: Scientific execution

Status: BLOCKED FOR APPROVAL

Details: Full approved clauses, point limits, product applicability, device manual and calculation validation remain required; 11 scientific WIs are review proposals.

Decision: DEC-001..015; DEC-026

## GAP-002

Area: Physical/manual operations

Status: PROPOSED MANUAL

Details: Training, custody, sampling-plan control, internal transfer/rework/disposal have no complete dedicated digital workflow in the current inventory.

Decision: DEC-003; DEC-019

## GAP-003

Area: Company form identity

Status: PARTIAL

Details: Feeding/goggle full identifiers and Nelaton visual identity need original confirmation; no clamp form positively identified. All 84 images still mapped.

Decision: DEC-009/010/013/014

## GAP-004

Area: Document and generic decisions

Status: POLICY_SOURCE_REQUIRED

Details: Generic document/approval/change-request authority and effectivity remain unresolved. Pack is draft.

Decision: DEC-016

## GAP-005

Area: Worker, telemetry and recovery

Status: IMPLEMENTATION/PROVIDER EVIDENCE REQUIRED

Details: Restore intent is PLANNED only; worker/scheduler/exporter/durable backup/provider restore are not established by current source.

Decision: DEC-021/022

## GAP-006

Area: Acceptance and release

Status: NOT VERIFIED BY DOCUMENT AUTHORING

Details: No new DB18/browser/AT/runtime/provider/performance or human UAT acceptance was executed for this task.

Decision: DEC-024/025

## GAP-007

Area: Source conflicts

Status: DOCUMENTED

Details: New owner RBAC supersedes older reject creator-confirmation text; photographs supplied after older lab form-source absence description; leak-form revisions conflict.

Decision: DEC-004/017/028
