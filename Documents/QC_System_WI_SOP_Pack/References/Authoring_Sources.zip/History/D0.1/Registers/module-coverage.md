# Module and process coverage

D0.1 | DRAFT FOR REVIEW | 2026-10-03

All 19 current source modules are assigned to procedures. Mapping is not runtime or regulatory acceptance.

## administration

Module: administration

Sop: QC-SOP-003

Wi: QC-WI-040

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## ai-advisory

Module: ai-advisory

Sop: QC-SOP-027

Wi: QC-WI-045

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## approvals

Module: approvals

Sop: QC-SOP-011

Wi: QC-WI-012, QC-WI-013, QC-WI-063

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## assets

Module: assets

Sop: QC-SOP-020

Wi: QC-WI-032, QC-WI-033, QC-WI-034, QC-WI-041

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## backup-recovery

Module: backup-recovery

Sop: QC-SOP-029

Wi: QC-WI-047, QC-WI-048, QC-WI-065

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## change-requests

Module: change-requests

Sop: QC-SOP-023

Wi: QC-WI-038, QC-WI-063

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## dashboard

Module: dashboard

Sop: QC-SOP-026

Wi: QC-WI-044

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## documents

Module: documents

Sop: QC-SOP-022

Wi: QC-WI-035, QC-WI-036, QC-WI-037

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## e-signatures

Module: e-signatures

Sop: QC-SOP-011

Wi: QC-WI-013, QC-WI-030, QC-WI-063

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## identity

Module: identity

Sop: QC-SOP-003

Wi: QC-WI-040

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## laboratory

Module: laboratory

Sop: QC-SOP-009

Wi: QC-WI-015, QC-WI-016, QC-WI-017, QC-WI-018, QC-WI-019, QC-WI-020, QC-WI-021, QC-WI-050, QC-WI-051

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## quality

Module: quality

Sop: QC-SOP-017

Wi: QC-WI-026, QC-WI-027, QC-WI-028, QC-WI-029, QC-WI-030

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## quarantine

Module: quarantine

Sop: QC-SOP-006

Wi: QC-WI-001, QC-WI-002, QC-WI-003, QC-WI-004, QC-WI-005, QC-WI-009, QC-WI-010, QC-WI-011, QC-WI-012, QC-WI-013, QC-WI-037, QC-WI-066, QC-WI-052, QC-WI-053, QC-WI-054, QC-WI-055, QC-WI-056, QC-WI-057, QC-WI-058, QC-WI-059, QC-WI-060

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## reject-reports

Module: reject-reports

Sop: QC-SOP-014

Wi: QC-WI-022, QC-WI-023, QC-WI-024, QC-WI-025

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## release-governance

Module: release-governance

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-067

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## reporting

Module: reporting

Sop: QC-SOP-025

Wi: QC-WI-043

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## system-health

Module: system-health

Sop: QC-SOP-028

Wi: QC-WI-006, QC-WI-008, QC-WI-046, QC-WI-064

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## tasks

Module: tasks

Sop: QC-SOP-019

Wi: QC-WI-031, QC-WI-044

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW

## uat-evidence

Module: uat-evidence

Sop: QC-SOP-030

Wi: QC-WI-049, QC-WI-068

Status: SOURCE MODULE MAPPED FOR DOCUMENT REVIEW
