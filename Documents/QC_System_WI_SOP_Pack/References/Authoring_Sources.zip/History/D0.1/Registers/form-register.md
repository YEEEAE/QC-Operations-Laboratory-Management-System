# Company forms and source records

D0.1 | DRAFT FOR REVIEW | 2026-10-03

Original company numbers are preserved independently from new QC-WI/QC-SOP numbers. PARTIAL identity rows require the actual original. A stamp, historical signature or result is not current authority.

## FORM-001

Title: Receiving Slip from Supplier — Raw material / Finished Goods

Company number: F-7-5-7-1

Revision: 5

Printed date: 27.07.2021

Fields: Supplier’s Name; P.O. Ref. No.; Ref. No.; Ser. No.; Date; item code/description; Unit; Qty. Received; Lot No.; Exp. Date; Store Keeper

Linked documents: QC-WI-001; QC-WI-002

Status: IDENTITY OBSERVED; EFFECTIVITY/ORIGINAL CONTROL REQUIRED

Images: IMG-009, IMG-010, IMG-012, IMG-013, IMG-019, IMG-029, IMG-037, IMG-051, IMG-052, IMG-053, IMG-054, IMG-055, IMG-056, IMG-057, IMG-058, IMG-059, IMG-060, IMG-061, IMG-062, IMG-063, IMG-065, IMG-081, IMG-082, IMG-083, IMG-084

## FORM-002

Title: Daily Production & Rejection Record

Company number: F-7-5-3-12-2

Revision: 1

Printed date: 21.10.2025

Fields: Section; department; date/machine; item/product; lot; good/reject quantities; unit; analysis/assistance; prepared/reviewed fields

Linked documents: QC-WI-024

Status: IDENTITY OBSERVED; METRIC AND ROLE REVIEW REQUIRED

Images: IMG-002, IMG-004, IMG-005, IMG-006, IMG-020, IMG-039, IMG-071, IMG-072, IMG-073

## FORM-003

Title: Pressure Decay Test Report

Company number: F-8-2-6-05

Revision: 04

Printed date: 01.01.2026

Fields: Sample/connector identification; equipment; assembly force/torque/time/angle; environment; set/applied pressure; volume; pressure difference; holding time; leak throughput; PASS/FAIL/HOLD; tested/reviewed/approved

Linked documents: QC-WI-050; QC-WI-021

Status: PRINTED LIMITS OBSERVED; NOT ADOPTED

Images: IMG-001, IMG-008, IMG-011, IMG-028, IMG-030, IMG-033, IMG-038, IMG-041, IMG-042, IMG-043, IMG-044, IMG-045, IMG-046, IMG-047, IMG-048, IMG-049, IMG-050

## FORM-004

Title: Subatmospheric Pressure Air Leakage Test Report

Company number: F-8-2-6-07

Revision: 4

Printed date: 01.01.2026

Fields: Same run fields as pressure form, with vacuum parameters and sample-level leakage; historic signatures

Linked documents: QC-WI-051; QC-WI-021

Status: IDENTITY OBSERVED; CONFLICT WITH FORM-005

Images: IMG-007, IMG-027, IMG-040

## FORM-005

Title: Subatmospheric Pressure Air Leakage Test Report

Company number: FR-MA-018

Revision: 06

Printed date: 01.01.2020

Fields: Product/connector type; testing date; lot/area; medium; assembly; environment; volume (liter); pressure difference (kPa); throughput (Pa.cm³/s); tested/reviewed/approved

Linked documents: QC-WI-051; QC-WI-021

Status: IDENTITY OBSERVED; CONFLICTING LIMITS/UNITS/LABELS

Images: IMG-070

## FORM-006

Title: Inspection & Test Report for Oral Medication Syringe

Company number: F-823-T61-2

Revision: 0

Printed date: 01.01.2024

Fields: Supplier/PO/lot/size/type; packaging; barrel/plunger/piston; scale; leakage/aspiration; dead space; sample level/size; AQL; cylinder readings; remarks/status

Linked documents: QC-WI-052

Status: IDENTITY OBSERVED; PRINTED CRITERIA NOT ADOPTED

Images: IMG-074, IMG-075

## FORM-007

Title: Inspection & Test Report for Syringes

Company number: F-823-T61

Revision: 3

Printed date: 20.03.2024

Fields: Packing; appearance/type; scale; piston/nozzle/wings; clinical fitting; liquid/air leakage; dead space; pH; lubrication; logo; sterility; AQL; cylinder reference/readings

Linked documents: QC-WI-053

Status: IDENTITY OBSERVED; PRINTED PH/ACCURACY NEED SOURCE

Images: IMG-014, IMG-025

## FORM-008

Title: Inspection & Test Report for Feeding Tube Gastrostomy

Company number: F-823-T… (suffix not confidently resolved)

Revision: 2 (observed)

Printed date: 01.02.2024 (observed)

Fields: Material; dimensions; X-ray line; balloon/valve; port cap; retention ring; logo; sterility; sample/AQL; status; remarks

Linked documents: QC-WI-054

Status: PARTIAL IDENTITY; ORIGINAL FORM REQUIRED

Images: IMG-079

## FORM-009

Title: Inspection & Test Report for Nelaton Catheter

Company number: F-823-T48 (visual transcription; verify original)

Revision: 3 (observed)

Printed date: 01.02.2024

Fields: Type/lubrication; tube/tip/eyes; OD/ID/length; connector/gluing; scale/label/pouch; logo/sterility; sample/AQL; remarks/status

Linked documents: QC-WI-055

Status: IDENTITY REVIEW REQUIRED; VARIANT CONCERNS OBSERVED

Images: IMG-077, IMG-078, IMG-080

## FORM-010

Title: Inspection & Test Report for Nasal Oxygen Cannula

Company number: F-823-T9

Revision: 3

Printed date: 01.02.2024

Fields: Prongs/tip; pilot/nostril tubing; tube/connector dimension/gluing; appearance/size; logo/sterility; sample/AQL; remarks/status

Linked documents: QC-WI-056

Status: IDENTITY OBSERVED; LOW-FLOW APPLICABILITY REQUIRED

Images: IMG-076

## FORM-011

Title: Inspection & Test Report for Instruments Cleaning Brushes

Company number: F-823-T147

Revision: 0

Printed date: 13.09.2023

Fields: Twisted wire; wire/handle/bristle dimensions; protector; bristle status/cover; label; logo/sterility; sample/AQL; remarks/status; TF-M73-PS referenced

Linked documents: QC-WI-057

Status: IDENTITY OBSERVED; REFERENCED DRAWING NOT SUPPLIED

Images: IMG-003, IMG-017, IMG-018, IMG-021, IMG-022, IMG-023, IMG-026, IMG-035

## FORM-012

Title: Clamps — family requested by user

Company number: NOT IDENTIFIED IN REVIEWED IMAGE SET

Revision: NOT ESTABLISHED

Printed date: NOT ESTABLISHED

Fields: Product drawing, intended use and original inspection form required

Linked documents: QC-WI-058

Status: SOURCE GAP; NO COMPANY FORM NUMBER INVENTED

Images: 

## FORM-013

Title: Goggles inspection record / Safety Goggles Feature

Company number: F-823-T… (full suffix obscured/uncertain)

Revision: 0

Printed date: 20.04.2024

Fields: Packing; appearance; frame/vents; lens/seating; holder; lace/strap; logo/sterility; AQL/sample; status; supplier feature label

Linked documents: QC-WI-059

Status: PARTIAL IDENTITY; CLAIMS AND ORIGINAL FORM REQUIRED

Images: IMG-015, IMG-024, IMG-031, IMG-032, IMG-034

## FORM-014

Title: Inspection & Test Report for Endotracheal Tube

Company number: F-823-T30

Revision: 4

Printed date: 23.04.2024

Fields: Tube/tip/connector/type/angle; dimensions/length; inflation tube/cuff/pilot balloon; Murphy eye; X-ray/scale/guide; logo/sterility; sample/AQL; remarks

Linked documents: QC-WI-060

Status: IDENTITY OBSERVED; VARIANT/SOURCE REVIEW REQUIRED

Images: IMG-016, IMG-036

## FORM-015

Title: Rejection Slip for Material / Products / Parts

Company number: F-7-5-7-8

Revision: 4

Printed date: 21.09.2026 (pictured revision)

Fields: Department; item/lot/unit/qty/total; reason; prepared/checked/reviewed; rework/warehouse/other disposition; production/QCM/director approval

Linked documents: QC-WI-022; QC-WI-023; QC-WI-025

Status: IDENTITY OBSERVED; ROLE/CHECKPOINT MAPPING REQUIRED

Images: IMG-066, IMG-067, IMG-068, IMG-069

## FORM-016

Title: Handwritten technical note / sketch

Company number: NO CONTROLLED NUMBER OBSERVED

Revision: NOT ESTABLISHED

Printed date: NOT ESTABLISHED

Fields: Sketches, handwritten measurements and comments; no verified authority

Linked documents: QC-SOP-010

Status: CONTEXT ONLY; NOT AN APPROVED METHOD

Images: IMG-064
