# Master document register

D0.1 | DRAFT FOR REVIEW | Final layout review 2026-10-04

30 SOP PDFs and 68 editable WI DOCX files. Paths are relative to the pack root; Markdown sources are archive members. Approval and effectivity are not recorded.

## QC-SOP-001

Title: Document control and approval of this pack

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Document Control; QMS; QC Manager

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-001.md

Content sha256: 5418c8a0a3ff6c831d2488c201eb23d62d2372e4ee7b8ee4c9f611b125eb2211

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-001.pdf

## QC-SOP-002

Title: Personnel training and competency

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QMS; QC Supervisor; Technical specialists

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL TRAINING TRACKING REQUIRED

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-002.md

Content sha256: a83a0f031f283444e951dfb4164d89a8816e3da0f1813ea8f92e7fb519d50beb

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-002.pdf

## QC-SOP-003

Title: Account, permission and session management

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Named System Owner; Authorized identity administrator

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-003.md

Content sha256: 8cf804079a393f1a692e0d2fd1b263a5d9da5a62e588f455efffae23b6b6924e

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-003.pdf

## QC-SOP-004

Title: Supplier receipt and purchase-order reconciliation

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Warehouse; QC entry operator; Purchasing; QC Supervisor

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-004.md

Content sha256: 01e1b63183448b70a8f9fca6e47ee02afd2fd9de5b6ba6035a279c2cbf21006b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-004.pdf

## QC-SOP-005

Title: Receiving corrections and record conflicts

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC entry operator; QC Supervisor; Record owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-005.md

Content sha256: 9eb54f3c5ac57ba579ce2cae0a984c2ba15d1a11dcdfe84573704f489b828689

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-005.pdf

## QC-SOP-006

Title: Quarantine, HOLD and release control

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC Supervisor; QCM; Authorized release actor; Warehouse

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-006.md

Content sha256: 6a14dfb6582981508de2a59e0e86384558890f9fc620a5b5a4c7d5be07804ebe

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-006.pdf

## QC-SOP-007

Title: Sampling and sample custody

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC Supervisor; Sampling operator; Laboratory

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL CUSTODY AND PLAN CONTROL REQUIRED

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-007.md

Content sha256: 714f5c80d94e6d104c3aa555bcaa1eebd2b382b100ebfb8af55f8b1546694b74

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-007.pdf

## QC-SOP-008

Title: Incoming and product inspection

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC operator; Supervisor; QCM; Product specialist

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-008.md

Content sha256: f12fe8211cc9ca862111d0e4af5e8b17f64ec56961eec49d944ca08de126ee6e

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-008.pdf

## QC-SOP-009

Title: Laboratory method selection and execution

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Laboratory operator; Technical method owner; Supervisor; QCM

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-009.md

Content sha256: c355f02cf664b14b2267f3eddd0b72d78fd98a0927b73a3b7e4bee2a9aac01f6

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-009.pdf

## QC-SOP-010

Title: Raw data, instrument files and calculation control

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Laboratory; QC Supervisor; Document Control; IT

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-010.md

Content sha256: 99ac2da78bb0613c1f00aaead7f453cc079d935a591a33199cc53ca53bb6be29

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-010.pdf

## QC-SOP-011

Title: Review, approval and electronic signatures

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Supervisor; QCM; Authorized domain approver; QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-011.md

Content sha256: 424fcb83cb1a272ff48d3def463f20083f810612c92bae29fe6aca661cd5ca68

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-011.pdf

## QC-SOP-012

Title: Invalid work, retesting and disputed results

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Technical method owner; Supervisor; QCM

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-012.md

Content sha256: da9f5a736bd065123d5aaac78e40ce4179578f2db3a469ba0c4f620a99754593

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-012.pdf

## QC-SOP-013

Title: Laboratory report-form transcription

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC entry operator; Laboratory; Document Control

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-013.md

Content sha256: ea59ad3d952aa2e882f1028c9b64f4ef8b0f8b99520444dbf125760976434b73

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-013.pdf

## QC-SOP-014

Title: Rejected material and rejection slips

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC entry operator; Authorized confirmation actors; Warehouse; QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-014.md

Content sha256: 73d72e6f5869346c6febdb5268f35067d3d2e6309cbd35c337776f6ac5d291b9

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-014.pdf

## QC-SOP-015

Title: Daily production and rejection reporting

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Production; QC entry operator; Authorized finalizer; QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-015.md

Content sha256: 6580108fc329d85c6381ac67a884521e05488052f1101ce30494f9139a325148

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-015.pdf

## QC-SOP-016

Title: Internal transfer, rework and physical disposition

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Warehouse; Production; QC Supervisor; QMS

Implementation: PROPOSED MANUAL PROCEDURE — DIGITAL MOVEMENT LEDGER REQUIRED

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-016.md

Content sha256: f08038573296319ce0f0b8049f2b813c606b751a4e34136427449f9b3d151bfb

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-016.pdf

## QC-SOP-017

Title: Findings and nonconformance control

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC; Supervisor; Quality process owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-017.md

Content sha256: fe4ac5fa2f0815b16e6e4975a6532b326ca32e5dc05036747585da530725ea4b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-017.pdf

## QC-SOP-018

Title: Root cause and CAPA lifecycle

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Quality process owner; Investigator; Supervisor; QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-018.md

Content sha256: f3d0e7ca2360990125037c1db97ce0f2745ecd3bec091cacbcd99b6fbf1e4a2b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-018.pdf

## QC-SOP-019

Title: Task assignment and work handoff

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Task owner; Assignee; Supervisor

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-019.md

Content sha256: 0c62202657677c1b47d7272843a2ae70a58032606ca235f9f89078c0cddecb7c

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-019.pdf

## QC-SOP-020

Title: Equipment registration and fitness for use

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Equipment owner; Laboratory; Asset administrator

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-020.md

Content sha256: 6128e7166f6f0418457106e7c430f4082329e3e8430872992beca2ea0aeff008

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-020.pdf

## QC-SOP-021

Title: Calibration and maintenance control

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Metrology; Equipment owner; Maintenance; QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-021.md

Content sha256: 69f27b55a563f7cf1853942c4b9c6f47ec27ba4cb2e3a3fb31f1c1cdbe6d7282

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-021.pdf

## QC-SOP-022

Title: Templates, controlled documents and revisions

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Document Control; Template technical owner; Supervisor; QCM

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-022.md

Content sha256: c3ddcb55427842d3c66f4f99b5540cb972effa6d5acd1d8008934554756519f9

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-022.pdf

## QC-SOP-023

Title: Controlled change requests

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Change requester; Assigned reviewer; QMS; Named owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-023.md

Content sha256: e1105c0a5d3a948f969c415caae40df2352def920bda1cb60085fa43362a967a

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-023.pdf

## QC-SOP-024

Title: Records, audit, retention and corrections

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QMS; Document Control; IT; Record owners

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-024.md

Content sha256: ece02772e5f9575f41e619c34b0a02e971bddcf8c5f99c69c4f93b4d0335e3ec

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-024.pdf

## QC-SOP-025

Title: Reports, provenance and controlled exports

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Report owner; QC/QMS; Authorized reader

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-025.md

Content sha256: caa27270e4527518a1fd9450fe940b56efe9a5b00c2a8ca9a4949d510ca3c8d5

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-025.pdf

## QC-SOP-026

Title: Worklists, search, dashboards and notifications

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized system user; Work owner; Support

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-026.md

Content sha256: a3acae09ab2a47e451b8ec2b44934fee6dbe084ac1cae5e722fa5e81c4012a18

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-026.pdf

## QC-SOP-027

Title: AI advisory governance

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Named owner; QMS; Authorized advisory user; Privacy/security reviewer

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-027.md

Content sha256: 830406622656bea3c53adc5d658d141189ea623bf534eab70b10e91ba8822457

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-027.pdf

## QC-SOP-028

Title: Support, security incidents and service interruptions

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Support; Named owner; Security; QC/QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-028.md

Content sha256: c6802aa8f630d6324a424dbbbfd801f6cf524dcbc21ef8323934c6af6292bdf7

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-028.pdf

## QC-SOP-029

Title: Backup, restore intent and disaster recovery

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Named owner; IT recovery operator; QMS; Provider

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-029.md

Content sha256: ba40ecf4d28feaf61a4ee2cf811ebe93585469152f492f5c085a4770e617fa4a

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-029.pdf

## QC-SOP-030

Title: Release governance, verification and human UAT

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Named owner; Engineering; Verification lead; QMS; Human UAT participants

Implementation: SOURCE-ALIGNED DRAFT

Parent: Not recorded

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/SOP/QC-SOP-030.md

Content sha256: fe1fdaae7651c142e22c97ac3a15c63da982fed0474caa152ef652fe49fcfb62

Hash scope: Archived Markdown UTF-8 bytes

Delivery: SOPs/QC-SOP-030.pdf

## QC-WI-001

Title: Receive and reconcile a supplier delivery

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Warehouse; QC entry operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-004

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-001.md

Content sha256: c4577afdd8f9419c23c6a6862a3149267385d87bdab8f30b336d490bba43e59c

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-001.docx

## QC-WI-002

Title: Open and save a receiving correction

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized QC entry operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-005

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-002.md

Content sha256: a9b645493e692dacf2e6c7db7f287a593815e49e021e39a1875b16d7510aefcb

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-002.docx

## QC-WI-003

Title: Prepare receiving for inspection

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized receiving/inspection actor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-006

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-003.md

Content sha256: db355c5195a17e134d477169150b1f77f948e3664dedff33b60867371368cb02

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-003.docx

## QC-WI-004

Title: Place material on HOLD and preserve containment

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized HOLD actor; Warehouse

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-006

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-004.md

Content sha256: 9620e9df98d2d6b1f7c002f8c977860995d8f9a5382b89b4c473fedb0259f64b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-004.docx

## QC-WI-005

Title: Perform an authorized receiving release

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: P-05 authorized release actor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-006

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-005.md

Content sha256: e6d71fccc91f1abd6cf1bcdce631a78224ae9cecc58c01c3030c3cc7e62b7bc5

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-005.docx

## QC-WI-006

Title: Check a missing, denied, empty or unavailable source

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Operator; Authorized support

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-028

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-006.md

Content sha256: bb80415b6620de81607b9b9ad716a6e282d610272d8454c694b151a25b09f0a1

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-006.docx

## QC-WI-007

Title: Reconcile a conflict between two record versions

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Record author; Record owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-005

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-007.md

Content sha256: f4a215c0081969addfdb7deee82da840a33017482d96dedebf86da8910db9906

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-007.docx

## QC-WI-008

Title: Resolve an unknown result after submission

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Operator; Support

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-028

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-008.md

Content sha256: 19796530560f8931cd841e1f723d36ae550bef084dc12dfaa70dd8a39f91394d

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-008.docx

## QC-WI-009

Title: Select and identify samples from a lot

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Qualified sampling operator

Implementation: PROPOSED MANUAL PROCEDURE

Parent: QC-SOP-007

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-009.md

Content sha256: 8b02b7855f6bce23a1f8cd1835bf2b47c3aac82f2df4dc2d815d05b8af4e9e5d

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-009.docx

## QC-WI-010

Title: Receive and hand over laboratory samples

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Sampler; Laboratory receiver

Implementation: PROPOSED MANUAL PROCEDURE

Parent: QC-SOP-007

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-010.md

Content sha256: 61471e53eebf05b33a2383f290744a55166d4ef6c05d25f22e98c56f835c1abd

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-010.docx

## QC-WI-011

Title: Execute an inspection record

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Qualified QC executor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-011.md

Content sha256: 57760f9183cf2d23da6c56b6da336ef0d6e7237489195964786602e3174f5e80

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-011.docx

## QC-WI-012

Title: Review an inspection or lab report at stage 1

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Supervisor; Explicitly authorized named owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-011

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-012.md

Content sha256: ef0dabfef276fea7b6696b763dbee7cb9007873b98ddb039648f986c6a0e14fa

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-012.docx

## QC-WI-013

Title: Complete QCM final approval with signature binding

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QCM; Explicitly authorized named owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-011

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-013.md

Content sha256: ee46615f9dc781214be4115aeace7348b4f2c072fa96fd4e02d56835d401d709

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-013.docx

## QC-WI-014

Title: Correct returned work and reopen approved work

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Author; Authorized reopen actor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-011

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-014.md

Content sha256: 6ff2327ee54b1d3b71ee7be805d30bcf60b94f5e8918684af30347adde4d3976

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-014.docx

## QC-WI-015

Title: Create a laboratory test with an approved template

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Qualified lab entry operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-009

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-015.md

Content sha256: c351b48ba6c50d8cac52e5bf061e8936d538a0f10f3d12b33bc025d627ca0d09

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-015.docx

## QC-WI-016

Title: Record a laboratory run and equipment context

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Qualified laboratory operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-009

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-016.md

Content sha256: 9d9b961fa90bdf4295c9adcec09d84d3bbb1c1404b5c383da0c35b16560661a3

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-016.docx

## QC-WI-017

Title: Enter typed laboratory measurements

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized laboratory operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-009

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-017.md

Content sha256: da0a3c49d772aaba5e1f58399a7afebb2b668e07641cca608780941d5c72435e

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-017.docx

## QC-WI-018

Title: Attach and verify raw laboratory evidence

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Laboratory; Authorized evidence uploader

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-010

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-018.md

Content sha256: 8b3db8304321e54478d0fe3a3a2e54357cdc7ab746bd77e3096eded145a5ab24

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-018.docx

## QC-WI-019

Title: Check a calculated result before review

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Technical reviewer; Laboratory

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-010

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-019.md

Content sha256: 406e5ca58e996143442748f072371c9c84b5bb1df3fd9ec21884b2ea6b738569

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-019.docx

## QC-WI-020

Title: Authorize and create a traceable retest

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Technical method owner; Authorized lab actor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-012

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-020.md

Content sha256: 981ed254c67189a84e4d7250485050c30adffacada1ccf0cc29054f5f3a91c4b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-020.docx

## QC-WI-021

Title: Transcribe a Pressure Decay or Subatmospheric form

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC entry operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-013

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-021.md

Content sha256: 402c640161f580ab19decf64f05f518c2bb16f3de0b3c6439c67d59246fc0b52

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-021.docx

## QC-WI-022

Title: Create and submit a rejection issue slip

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC entry operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-014

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-022.md

Content sha256: 6126e5f7543609e52709b1ecaebca40875b257e30ec767791ed940550d2c8055

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-022.docx

## QC-WI-023

Title: Record authorized rejection approval confirmations

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized checkpoint actor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-014

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-023.md

Content sha256: 9d3ce8cdd5b44d4dc59546c7f1fe360cd31c7013ed682d3ce26f0b4966775aea

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-023.docx

## QC-WI-024

Title: Enter a daily production/rejection report

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Production; QC entry operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-015

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-024.md

Content sha256: 1877d0bd1bec14e0cf6ddd4f8455c8c4203140e2565a2015e0108052ceb2fb0e

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-024.docx

## QC-WI-025

Title: Carry out an approved internal transfer or rework handoff

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Warehouse; Production; QC

Implementation: PROPOSED MANUAL PROCEDURE

Parent: QC-SOP-016

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-025.md

Content sha256: 8ce1d57fa04a70ac2d3462f2f6097ea5cdb06db26bbcb25ebc407bf5c24f2810

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-025.docx

## QC-WI-026

Title: Create a factual Finding

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC entry operator

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-017

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-026.md

Content sha256: ba7b75ec65be234632d80a80c879c2958e66c0424acd165ad977eecc0471cb61

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-026.docx

## QC-WI-027

Title: Create an NCR linked to persisted evidence

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized QC entry operator; Quality owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-017

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-027.md

Content sha256: b67e5a3c3e3fb39e317a6c6e370e184572aae0a5ea82b0dc03ddb6d87e10dfce

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-027.docx

## QC-WI-028

Title: Record and review root-cause analysis

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Quality investigator; Technical reviewer

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-018

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-028.md

Content sha256: 5228eb96246ab710a6d7b8454dfb84acfc5e5be5bc89779ea783823bec0211be

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-028.docx

## QC-WI-029

Title: Create and track CAPA actions

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: QC entry operator; CAPA owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-018

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-029.md

Content sha256: 2991b66834ad27e4f2e72ab78d8da506b1c28002a206d266271d94c4443a145a

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-029.docx

## QC-WI-030

Title: Verify effectiveness and record controlled CAPA closure

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized verifier; Supervisor close actor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-018

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-030.md

Content sha256: 9cffad0163fc3261b8aa7bbc5466aefa78510243e37051307af59b09430b9726

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-030.docx

## QC-WI-031

Title: Assign, complete and hand over a task

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Task creator; Assignee

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-019

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-031.md

Content sha256: 9378f24d81ca88f759e2ec31dbbf6d989d83da1dee8ebed8a90bc4f4ebf3ba10

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-031.docx

## QC-WI-032

Title: Register and inspect an equipment asset

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Asset entry operator; Equipment owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-020

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-032.md

Content sha256: b46af10673b39bb6ef69d6249a707361e999b16666c1312723ff88a48dcc7f3b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-032.docx

## QC-WI-033

Title: Record and review calibration evidence

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Metrology; Authorized calibration actor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-021

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-033.md

Content sha256: 05265c016b034314b0506ec2fcf22b9e202a99afbc44101e4bbb1ffd7e557959

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-033.docx

## QC-WI-034

Title: Record maintenance and return-to-use checks

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Maintenance; Equipment owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-021

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-034.md

Content sha256: 464bc1b940ee9d6e90e3a173ed75cd00b4316cf3a0d7d620f176d416fd512e0a

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-034.docx

## QC-WI-035

Title: Create or revise a controlled document

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Document author; Document Control

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-022

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-035.md

Content sha256: 15c172a2e6b83ff0ec18b55989e29dc0394eb80a63428682056a57ef92d8a27a

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-035.docx

## QC-WI-036

Title: Save a document draft against its opened version

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized document author

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-022

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-036.md

Content sha256: 033bf39b83694ea00254b0045526b409bd3bf7fa9d7ac5f3078f9076ac9fa508

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-036.docx

## QC-WI-037

Title: Manage an inspection or laboratory template

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Supervisor; QCM; Explicit named owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-022

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-037.md

Content sha256: 3ba2562edf9427d3af852cb7dde538c65fb012ca9ac28bbcc7e0622fe654ae35

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-037.docx

## QC-WI-038

Title: Create and start review of a change request

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Requester; Assigned reviewer

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-023

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-038.md

Content sha256: 44c9d7a2a98ca9716d7fdc33f1af398736b65a9422352a0ef8f2ad02c779fa55

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-038.docx

## QC-WI-039

Title: Prepare a human training and competency assessment

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Trainer; Technical assessor

Implementation: PROPOSED MANUAL PROCEDURE

Parent: QC-SOP-002

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-039.md

Content sha256: fd7c90af27369e612df6ff95649d33a9ee36ca61ed50f399e83f3a3ce8c44e99

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-039.docx

## QC-WI-040

Title: Manage an account or recover a session

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized identity administrator; Account holder

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-003

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-040.md

Content sha256: 08cd35fd1fde231ce91127bc916ddbef7853d888eb7a2b351c92a4d72624dbfd

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-040.docx

## QC-WI-041

Title: Respond to instrument failure during a test

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Laboratory; Equipment owner; Technical method owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-012

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-041.md

Content sha256: 829f5585da4f84bf4f7a9cbe4ec423a2e519c23a06303a844272ee2d164f3a32

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-041.docx

## QC-WI-042

Title: Investigate a failed review or contradictory result

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Supervisor; Technical owner; Author

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-012

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-042.md

Content sha256: f9d455cbf65a7653b123276b6c8976e25d7ffff81b5b6fcea2292970469f2874

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-042.docx

## QC-WI-043

Title: Generate and reconcile a report export

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized report reader; Report owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-025

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-043.md

Content sha256: a6d0e92fd38d2db414074ba54930b283e3e328497daa89fdd7c1f6aba71992aa

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-043.docx

## QC-WI-044

Title: Find scoped work and read in-app notifications

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authenticated authorized user

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-026

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-044.md

Content sha256: 70a7b3387c6943450d34fb6c0bd3ef0df64b6f9a5c998856fadd1c16b9828368

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-044.docx

## QC-WI-045

Title: Make an authorized AI advisory request

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized advisory user

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-027

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-045.md

Content sha256: e115349a396d23f1e23c1c69aafeb60108894a06094d3e4480fbdd631fde81d8

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-045.docx

## QC-WI-046

Title: Register a support incident and inspect owner health

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Operator; Authorized support; Named yazeed

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-028

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-046.md

Content sha256: 7028985e838006a90c52dd52ad73e5ef92fda9c1df82b92750a3129c007fd936

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-046.docx

## QC-WI-047

Title: Create and verify a PLANNED restore intent

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Explicitly authorized drill actor; Named owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-029

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-047.md

Content sha256: 822e3de4bb63b37cabf727535f37bc03c233b85e0e984bb10e1a4db3f2976d7d

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-047.docx

## QC-WI-048

Title: Verify an isolated database-and-files recovery

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized recovery operator; Provider; Verification reviewer

Implementation: PROPOSED OPERATOR PROCEDURE — PROVIDER RUNBOOK REQUIRED

Parent: QC-SOP-029

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-048.md

Content sha256: e6ba7f06bce6fa8454b0a8ea4c8b09b4e48809b1652aaa95afb25123ef1fc77b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-048.docx

## QC-WI-049

Title: Freeze release evidence and conduct real UAT

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Engineering; Verification lead; Human UAT participants; QCM/owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-030

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-049.md

Content sha256: b0e805e9db78c5a073285f4c9aac756d845851c72c4210fb92471855972f5b8b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-049.docx

## QC-WI-050

Title: Pressure Decay connector leakage test — technical review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Leak-test specialist; Metrology; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-009

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-050.md

Content sha256: 8cb48069d23369d0fe1c227a23dc5e909fac8a1d64b91ef31ef6c8a317caf0e3

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-050.docx

## QC-WI-051

Title: Subatmospheric Pressure Air Leakage — technical review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Leak-test specialist; Metrology; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-009

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-051.md

Content sha256: ad8b95cfe7779c52e0ebe30bf4fc6680286c9f2cd72581e005251055a0c6ed41

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-051.docx

## QC-WI-052

Title: Oral medication syringes — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Oral administration product specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-052.md

Content sha256: 1dd531cffca6723d4179728434a427e9dbab9a6700ded366601912c7fe41fe00

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-052.docx

## QC-WI-053

Title: Syringes — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Syringe product specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-053.md

Content sha256: 95d9223c6bf82e8366f44a399a25dd5b912e6184ecea7267a5e239db1a1cca3b

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-053.docx

## QC-WI-054

Title: Feeding tubes — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Enteral product specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-054.md

Content sha256: 591cf2170bd98cb3045213e84303b3ddb44b53062d92bf6c57ac3b8d731edc1d

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-054.docx

## QC-WI-055

Title: Nelaton catheters — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Urethral catheter product specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-055.md

Content sha256: 6e94b12ca50efdb2f8490df2d762b183f8692222644740c7f36eaed5bd640bdf

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-055.docx

## QC-WI-056

Title: Nasal cannulas — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Respiratory product specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-056.md

Content sha256: b541c6391f17f8ccf084f0409ca6adce290f13db88a6378d669c13ad08033a65

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-056.docx

## QC-WI-057

Title: Brushes — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Product/design specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-057.md

Content sha256: f9256ba8f600442d84e1614320f07250ce34b61a344485cdc79fef6278df0aaa

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-057.docx

## QC-WI-058

Title: Clamps — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Product/design specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-058.md

Content sha256: 5a12bddeeb7846aeb083d835c8c153173f4b3cfe15546592a1e161b39bb4b076

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-058.docx

## QC-WI-059

Title: Goggles — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Eye-protection product specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-059.md

Content sha256: 69a0d65444d96b71c1e89b3540e4032359867a12092b933b1fdc5fdb1fd441a6

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-059.docx

## QC-WI-060

Title: Endotracheal tubes — inspection and test review proposal

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Airway product specialist; QC/QMS

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

Parent: QC-SOP-008

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-060.md

Content sha256: 8610d81556c8767e6d53303e02dc682d85456083c40f05cefb64cb5fdc361230

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-060.docx

## QC-WI-061

Title: Establish and measure an approved performance baseline

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Performance engineer; Product owner; QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-030

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-061.md

Content sha256: 4f9fa01e72d749b759c3d5df6c9bd3bb70f02e8143503f5b6667e457dd0b7181

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-061.docx

## QC-WI-062

Title: Review audit evidence and controlled-record history

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized audit reader; QMS

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-024

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-062.md

Content sha256: f44a73a031f94d2a86ceb5a129a9ec1de4434f49310ffad54610207a9cdab1b7

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-062.docx

## QC-WI-063

Title: Handle a generic approval awaiting authority policy

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Assigned approver; QMS; Named owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-011

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-063.md

Content sha256: be89a33104eaeef4c29f722fd4dc079db01c8a4a35a94bdc2d34d2fdfe757239

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-063.docx

## QC-WI-064

Title: Verify outbox processing, correlation and operator alerts

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized operations engineer; Provider; Named owner

Implementation: PROPOSED OPERATIONS PROCEDURE — WORKER/PROVIDER CAPABILITY REQUIRED

Parent: QC-SOP-028

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-064.md

Content sha256: 053d884cb266839014fb138980fad368b0a089581c4e19bae6085d8d103cf94c

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-064.docx

## QC-WI-065

Title: Review storage and environment configuration readiness

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized IT operator; Named owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-029

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-065.md

Content sha256: 30673038e4098de841bb19c0f8a466b30a9c6bf80564660f8dcb36bc95c03a68

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-065.docx

## QC-WI-066

Title: Review quarantine administration and configuration sources

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Authorized template administrator; Named owner; QC technical owner

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-022

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-066.md

Content sha256: 3ddf7952bb7e237ca5c85cc3a33d157c35aca8e705578c5e3adf346a21204583

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-066.docx

## QC-WI-067

Title: Review release evidence intake and the nineteen gates

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Named owner; Authorized release reviewer; Trusted evidence provider

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-030

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-067.md

Content sha256: a54ab330d9eaf1aa6128a0e7f240240d2e56ad9f16ada4cc524c66fb8de2acc3

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-067.docx

## QC-WI-068

Title: Record a real UAT cycle, session and defect

Revision: D0.1

Status: DRAFT FOR REVIEW

Owner: Named owner; Actual UAT participant; QCM/owner acceptor

Implementation: SOURCE-ALIGNED DRAFT

Parent: QC-SOP-030

Effective date: Not recorded

Approval signature: Not recorded

Markdown: References/Authoring_Sources.zip!/WI/QC-WI-068.md

Content sha256: a0349311ed5783f68d30508d4d9559305093c07440643bef9cbe445eb090688a

Hash scope: Archived Markdown UTF-8 bytes

Delivery: WIs/QC-WI-068.docx
