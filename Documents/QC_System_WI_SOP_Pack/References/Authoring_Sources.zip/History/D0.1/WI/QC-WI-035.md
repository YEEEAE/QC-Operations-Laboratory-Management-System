# QC-WI-035 — Create or revise a controlled document

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Preserve source files, predecessor lineage and one open revision draft.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Document author; Document Control

Review: Document author; Document Control

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-022

## 3. Before you start

- The source identity and registered files are available.

- Document create/revision permission and scope apply.

## 4. Work steps and checks

1. Open /documents/new for a new controlled identity or the supported revision entry for an existing one.

2. Enter real document number/title/type and source context from controlled evidence.

3. For a revision, verify the latest EFFECTIVE predecessor and absence of another open draft.

4. Register and link source files through the permitted evidence boundary.

5. Retain file IDs/digests and revision predecessor relationship.

6. Save the DRAFT and reopen its version detail.

7. Compare identity, content and source evidence.

8. Send for review only when completeness and required source assertions pass.

## 5. Decisions, errors and stop conditions

- APPROVED is not EFFECTIVE; do not choose an unqualified predecessor.

- Generic approval remains policy-source blocked.

## 6. Records and handoff

- Document/version

- Predecessor

- File IDs/digests

- Review submission

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/documents/domain/document-state.ts

- src/modules/documents

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-005 — Per-point and overall evaluation

- DEC-016 — Generic signature and document authority

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /documents

- /documents/new

- /documents/[documentId]

- /documents/[documentId]/versions/new

- /documents/[documentId]/versions/[versionId]

- /documents/[documentId]/versions/[versionId]/review

- /documents/[documentId]/versions/[versionId]/edit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
