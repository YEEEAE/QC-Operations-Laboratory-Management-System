# QC-WI-009 — Select and identify samples from a lot

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Carry out the approved sample-selection plan and create traceable sample identities.

Implementation: PROPOSED MANUAL PROCEDURE

## 2. Responsibilities and review

Responsible specialists: Qualified sampling operator

Review: Qualified sampling operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-007

## 3. Before you start

- Lot boundary and approved sample plan are available.

- Sampling equipment and handling conditions are suitable.

## 4. Work steps and checks

1. Confirm product, size, supplier, lot and lot quantity/unit.

2. Read the approved plan and record its source revision, sample size and selection method.

3. If attributes sampling applies, verify inspection level, AQL, code letter, acceptance/rejection counts and switching status from the approved source.

4. Select from the required lot locations without substituting convenient units.

5. Identify each sample or approved group and record where it came from.

6. Inspect sample packaging/condition and preserve required environmental conditions.

7. Record selected, reserved and destructive-test quantities separately.

8. Hand the identified samples and selection record to inspection or laboratory.

## 5. Decisions, errors and stop conditions

- No approved plan: stop acceptance sampling.

- Twelve rows or a historical handwritten AQL is not a plan.

## 6. Records and handoff

- Plan reference

- Selection log

- Sample identifiers

- Quantity and condition

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- EXT-008

- src/modules/laboratory/domain/lab-test.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-003 — Sampling plan

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
