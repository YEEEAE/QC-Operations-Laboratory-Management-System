# QC-WI-001 — Receive and reconcile a supplier delivery

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create one traceable receiving item for the actual product, lot and quantity unit.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Warehouse; QC entry operator

Review: Warehouse; QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-004

## 3. Before you start

- Delivery, purchase order and original receiving slip are present.

- You have PERM-QUAR-CREATE and authorized entry scope.

## 4. Work steps and checks

1. Separate the delivered lots and read the physical labels before entering data.

2. Compare Supplier’s Name and P.O. Ref. No. on the slip with supplier and purchaseOrderNo. Record discrepancies for Purchasing.

3. Check Item code no., Item Description, Unit, Qty. Received, Lot No. and Exp. Date against the actual delivery. Keep partial quantity separate from ordered quantity.

4. Open /quarantine/receiving/new. Enter receivingNo, supplier, docNo, itemCode, description and lot from the source.

5. Enter qty and quantityUnit exactly; enter receivingDate and expiryDate only when supported. Expiry cannot precede receipt.

6. Save once and allow the pending request to resolve. Preserve the source file reference in the evidence register.

7. Reopen the saved receiving detail and compare the identity, quantity, unit and dates line by line.

8. Leave the material identified as pending QC work and hand the receiving number and source documents to inspection.

## 5. Decisions, errors and stop conditions

- Unreadable lot, incompatible unit or unmatched PO: retain segregation and obtain clarification.

- Unknown save result: follow QC-WI-008 before another create.

## 6. Records and handoff

- Receiving number and version

- Reconciled supplier slip and PO

- Discrepancy record

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/create-receiving.ts

- src/pages/quarantine/receiving/new.astro

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/receiving

- /quarantine/receiving/new

- /quarantine/receiving/[receivingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
