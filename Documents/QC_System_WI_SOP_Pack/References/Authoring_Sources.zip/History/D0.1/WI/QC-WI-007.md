# QC-WI-007 — Reconcile a conflict between two record versions

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Resolve an expected-version or content-hash conflict without losing either author’s work.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Record author; Record owner

Review: Record author; Record owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-005

## 3. Before you start

- Your opened draft and proposed changes are retained.

- You can read the current authorized version.

## 4. Work steps and checks

1. Stop after the stale-version or content-hash conflict. Do not modify hidden version fields to force success.

2. Preserve the unsaved proposed content in an authorized working location.

3. Reload the current record and identify which fields or evidence changed since you opened it.

4. Compare the original opened values, your proposed values and current persisted values.

5. Resolve overlapping edits with the record owner; do not silently choose the newer timestamp as technical authority.

6. Open a fresh eligible edit form and enter only the reconciled changes with a supported correction reason.

7. Submit once using the freshly opened version/hash and wait for a definite outcome.

8. Reopen and compare the final persisted content and history; return controlled work to review if its approved context changed.

## 5. Decisions, errors and stop conditions

- Locked record: use authorized reopen/revision, not draft edit.

- Source disagreement remains unresolved: retain draft and escalate.

## 6. Records and handoff

- Three-way comparison

- Reconciliation decision

- Saved version and correction reason

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/correct-receiving.ts

- src/modules/documents

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/receiving

- /quarantine/receiving/new

- /quarantine/receiving/[receivingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
