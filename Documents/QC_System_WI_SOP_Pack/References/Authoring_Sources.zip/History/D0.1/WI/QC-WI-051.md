# QC-WI-051 — Subatmospheric Pressure Air Leakage — technical review proposal

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Develop and execute, after approval, a vacuum leakage method for the exact connector application.

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

## 2. Responsibilities and review

Responsible specialists: Leak-test specialist; Metrology; QC/QMS

Review: Leak-test specialist; Metrology; QC/QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-009

## 3. Before you start

- DEC-001 to DEC-006 and form-revision reconciliation are approved.

- The actual instrument manual, vacuum fixture and reference checks are available.

- The approved product-specific method and sample plan exist.

## 4. Work steps and checks

1. Identify connector type, product, lot and sample units and confirm the applicable application standard.

2. Compare the intended vacuum method with the licensed ISO 80369-20:2024 clauses and applicable connector standard; catalog scope is not a validated operating recipe.

3. Select eligible calibrated equipment and inspect tubing/fixture/reference connector. Verify the approved vacuum safety and safe-release instructions.

4. Assemble the connector pair with the approved force, torque, time and angle. Record the actual values and resolve N·m versus N/m before testing.

5. Condition and record environment, then confirm gauge/absolute basis, effective volume, target vacuum, stabilization and holding time from the approved method.

6. Apply vacuum using the actual device procedure, isolate, stabilize and acquire the pressure rise or leak output. Do not call it positive-pressure decay or reverse the sign without the method’s convention.

7. Retain set and applied pressure, volume, pressure difference, holding time, throughput, sample identity and instrument raw file/print.

8. For review only, check q = V × abs(ΔP)/Δt in Pa·cm³/s under stable-volume/isothermal assumptions. Preserve the actual instrument calculation and investigate compensation or unit differences.

9. Evaluate only under approved per-sample criteria and aggregation. Keep invalid runs and any HOLD/further-evaluation conclusion explicit.

10. Reconcile original form revision, raw evidence and digital test/run before submitting for review. Historical report transcription remains a separate draft workflow.

## 5. Decisions, errors and stop conditions

- F-8-2-6-07 Rev4 prints −80 to −88 kPa, 15–20 s and <5000 Pa·cm³/s; FR-MA-018 Rev06 prints different values/units, including <0.010 Pa·cm³/s. Neither is adopted by this draft.

- FR-MA-018 also contains ambiguous/typo labels and volume in litres while other forms use cm³. Document Control and the method specialist must resolve these conflicts before use.

- Vacuum instability, failed blank/reference or leaking fixture: stop and preserve the run for investigation.

## 6. Records and handoff

- Approved method

- Form-revision disposition

- Assembly/environment/vacuum settings

- Raw evidence

- Unit/calculation check

- Review chain

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- EXT-001

- EXT-002

- EXT-009

- FORM-004

- FORM-005

- QC-SOP-009

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-003 — Sampling plan

- DEC-004 — Leak-form revision and unit conflict

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/report-templates

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
