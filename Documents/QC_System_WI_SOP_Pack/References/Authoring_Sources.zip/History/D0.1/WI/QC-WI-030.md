# QC-WI-030 — Verify effectiveness and record controlled CAPA closure

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Preserve the difference between implemented action, effectiveness and exceptional closure.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized verifier; Supervisor close actor

Review: Authorized verifier; Supervisor close actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-018

## 3. Before you start

- Persisted action and verification evidence exist.

- Closure permission, reason, reauthentication and signature requirements are satisfied.

## 4. Work steps and checks

1. Review action completion against the agreed evidence.

2. Verify implementation before beginning effectiveness assessment.

3. Apply the pre-approved effectiveness method and observation window.

4. Record the actual effectiveness outcome and remaining actions.

5. Advance through supported verification/effectiveness states when persisted prerequisites pass.

6. If P-04 exceptional closure is authorized, state incomplete or ineffective work in the reason.

7. Complete the required Supervisor reauthentication/e-signature ceremony for CLOSE.

8. Reload CLOSED and preserve the effectiveness result and residual follow-up; closure does not certify success.

## 5. Decisions, errors and stop conditions

- QC entry users cannot close.

- No effectiveness evidence: do not claim effectiveness even if exceptional closure is permitted.

## 6. Records and handoff

- Verification

- Effectiveness assessment

- Closure reason/signature

- Residual obligations

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/capa/domain/capa.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/capa

- /quality/capa/new

- /quality/capa/[capaId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
