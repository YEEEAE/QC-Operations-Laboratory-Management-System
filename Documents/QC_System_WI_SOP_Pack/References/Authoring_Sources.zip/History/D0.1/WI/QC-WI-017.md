# QC-WI-017 — Enter typed laboratory measurements

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Save observations using the template datatype, exact unit and sample association.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized laboratory operator

Review: Authorized laboratory operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-009

## 3. Before you start

- PERM-LAB-EDIT-DRAFT and PERM-LAB-ENTER-MEASUREMENT apply.

- The eligible test, expectedVersion and parameter definitions are loaded.

## 4. Work steps and checks

1. Read the parameter dataType, unit, sourceReference and required flag.

2. Select the correct sampleId and parameterId; confirm the sample belongs to this test/run.

3. For NUMERIC, enter a valid decimal string without a unit suffix or premature rounding.

4. For TEXT, preserve the entered text, including literal true or false where that is the observed text.

5. For BOOLEAN, use a real boolean selection; do not convert all true/false-looking text globally.

6. Enter remarks only with an associated observation. NA is not a defined laboratory datatype and needs approved point semantics.

7. Save with the opened expectedVersion. Retain raw files and replicate data.

8. Reload and compare stored value type, exact decimal, unit, remarks and sample/run link.

## 5. Decisions, errors and stop conditions

- Mismatched unit, missing source or invalid type: correct from the approved definition.

- Stale version: reconcile; do not coerce data to satisfy a field.

## 6. Records and handoff

- Typed raw value

- Unit and remarks

- Sample/parameter/run link

- Reload check

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/domain/measurement.ts

- src/modules/laboratory/application/save-measurements.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
