# QC-WI-068 — Record a real UAT cycle, session and defect

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Persist human UAT evidence without simulating participant observations or signatures.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Named owner; Actual UAT participant; QCM/owner acceptor

Review: Named owner; Actual UAT participant; QCM/owner acceptor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-030

## 3. Before you start

- An authorized isolated UAT environment and real participant accounts exist.

- The approved scenarios and valid scientific sources are available.

## 4. Work steps and checks

1. The owner creates the supported UAT cycle with the actual candidate and planned coverage.

2. Assign real role-bound participants; do not seed production users or alter yazeed credentials.

3. Each participant performs the assigned scenario and records only their own session through the supported UAT action.

4. Capture actual result, limitation and retrievable evidence; source tests must be labeled separately.

5. The owner records defects with their affected scenario/record context.

6. Retest resolved defects on the resulting candidate and retain prior failure history.

7. QCM/owner accepts only through the actual supported signed ceremony.

8. Read back the persisted cycle/session/defect and acceptance links using authorized PERM-RPT-VIEW scope.

## 5. Decisions, errors and stop conditions

- No real participant or signature: NOT VERIFIED, not UAT PASS.

- Creating the cycle is not human acceptance.

## 6. Records and handoff

- Cycle

- Actual participant session

- Defect/retest

- Signed acceptance

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/uat-evidence

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-024 — Release gates, applicability and human acceptance

- DEC-025 — Performance budgets and representative environment

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reports

- /reports/[reportCode]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
