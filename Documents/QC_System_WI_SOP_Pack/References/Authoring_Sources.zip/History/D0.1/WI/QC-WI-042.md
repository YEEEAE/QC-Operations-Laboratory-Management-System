# QC-WI-042 — Investigate a failed review or contradictory result

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Resolve a review failure without editing the record to hide the concern.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Supervisor; Technical owner; Author

Review: Supervisor; Technical owner; Author

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-012

## 3. Before you start

- The review reason and raw evidence are available.

- The record state and actor actions are known.

## 4. Work steps and checks

1. Read the specific review concern and identify affected points/samples.

2. Compare source revision, units, raw data, equipment and calculations.

3. Contain affected material if the official outcome is uncertain.

4. For incomplete work, the authorized reviewer returns it with a specific reason.

5. The author resumes and corrects eligible draft work while preserving original evidence.

6. For scientific disagreement, obtain a documented technical interpretation or retest authorization.

7. For a rejected lab decision lacking approved PD-38 policy, retain POLICY_SOURCE_REQUIRED; do not create an alternate reject action.

8. Resubmit only the reconciled version and repeat the required review stages.

## 5. Decisions, errors and stop conditions

- Do not infer acceptance from a majority of passing rows.

- An unresolved scientific source remains a blocker.

## 6. Records and handoff

- Review reason

- Technical investigation

- Correction/retest

- New review

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/application/reject-lab-test.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
