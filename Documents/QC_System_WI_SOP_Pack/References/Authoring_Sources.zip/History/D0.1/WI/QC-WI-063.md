# QC-WI-063 — Handle a generic approval awaiting authority policy

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Review a pending generic approval without bypassing an unresolved signature policy.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Assigned approver; QMS; Named owner

Review: Assigned approver; QMS; Named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-011

## 3. Before you start

- The target and authority decision are identified.

- The actor may read the approval and target under current scope.

## 4. Work steps and checks

1. Open /approvals/[approvalId] and identify workflow type and exact target version.

2. Read the target record and supporting evidence.

3. Check the actual action permission, role/scope and separation-of-duties policy.

4. Determine whether the approved signature/decision policy exists for this workflow.

5. If PD-32 or RD-019 is unresolved, record POLICY_SOURCE_REQUIRED as the blocker.

6. Do not reuse inspection/lab FINAL_APPROVE authority for a generic document or change request.

7. Obtain the owner/QMS policy package and implement it through separate authorized change control if necessary.

8. Only after authority exists, perform the supported binding ceremony and verify the persisted decision.

## 5. Decisions, errors and stop conditions

- A visible button or entered approver name is not authorization.

- No alternate direct transition or password-only bypass is permitted.

## 6. Records and handoff

- Approval/target context

- Policy blocker

- Approved authority package when obtained

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

- src/modules/approvals

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /documents

- /documents/new

- /documents/[documentId]

- /documents/[documentId]/versions/new

- /documents/[documentId]/versions/[versionId]

- /documents/[documentId]/versions/[versionId]/review

- /approvals

- /approvals/[approvalId]

- /change-requests

- /change-requests/new

- /change-requests/[changeRequestId]

- /change-requests/[changeRequestId]/review

- /documents/[documentId]/versions/[versionId]/edit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
