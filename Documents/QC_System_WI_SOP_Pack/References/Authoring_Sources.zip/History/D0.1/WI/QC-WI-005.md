# QC-WI-005 — Perform an authorized receiving release

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record release only after the official PASS result and release prerequisites are satisfied.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: P-05 authorized release actor

Review: P-05 authorized release actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-006

## 3. Before you start

- PERM-QUAR-RELEASE, P-05 authority and scope apply.

- The actor is separate from the inspection author.

- Receiving is RELEASE_PENDING with official inspectionResult PASS.

## 4. Work steps and checks

1. Open the current receiving item and linked approved inspection.

2. Compare product, lot, quantity and source context with the material awaiting release.

3. Verify official PASS and RELEASE_PENDING; a transcribed form PASS is insufficient.

4. Check that no release-blocking condition or unresolved HOLD remains.

5. Confirm the exact actor permission and separation-of-duties requirements.

6. Invoke the supported RELEASE action with expectedVersion and request identity.

7. Reload and verify RELEASED and its audit/decision evidence before physical movement.

8. Hand the actual release evidence and lot scope to Warehouse and preserve the inspection approval separately.

## 5. Decisions, errors and stop conditions

- Denied, stale or missing official result: keep material contained.

- Inspection APPROVED alone does not establish receiving RELEASED.

## 6. Records and handoff

- Official inspection

- Release record/version

- Warehouse handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/release-receiving.ts

- src/shared/authorization/p05-authority.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine

- /quarantine/receiving

- /quarantine/receiving/new

- /quarantine/receiving/[receivingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
