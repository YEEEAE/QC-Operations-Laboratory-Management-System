# QC-WI-022 — Create and submit a rejection issue slip

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record an affected lot and proposed disposition from real rejection evidence.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator

Review: QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-014

## 3. Before you start

- Material identity, quantity/unit and rejection evidence exist.

- PERM-RREJ-CREATE and eligible submission grant apply.

## 4. Work steps and checks

1. Keep affected material segregated and identify the lot.

2. Open /reject-reports/new?type=slip and choose the issue-slip workflow.

3. Enter department, item description, lot, unit and quantities from the source.

4. Describe the rejection reason and link the actual test/inspection/incident.

5. Record the proposed disposition without treating it as approved.

6. Save and reopen the DRAFT to compare all fields with the original slip.

7. Submit through the supported action to the approval-tracking process.

8. Hand the exact report/version to an authorized confirmation actor; QC cannot attest or confirm.

## 5. Decisions, errors and stop conditions

- No source or mismatched quantity: stop submission.

- Creating the slip does not authorize rework, transfer or disposal.

## 6. Records and handoff

- Issue slip

- Source and quantity check

- Submitted version

- Approval handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reject-reports

- /reject-reports/new

- /reject-reports/issue-slips/[reportId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
