# QC-WI-021 — Transcribe a Pressure Decay or Subatmospheric form

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create a checked report draft from a legible original without creating an approved result.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator

Review: QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-013

## 3. Before you start

- Original image/form and form-register identity are available.

- The lab report-draft permission and scope apply.

## 4. Work steps and checks

1. Select the matching form at /laboratory/report-templates.

2. Record the source image ID, company form number and revision in the form/evidence register.

3. Compare the original identification, equipment, assembly, environment and result sections.

4. Transcribe rows exactly, preserving printed unit names and flagging unclear readings.

5. Keep historical PASS/FAIL/HOLD and Tested/Reviewed/Approved By values as transcription text.

6. Save once, reopen and compare all fields with the original.

7. Use the draft print only as a convenience copy; no signature or test evaluation is created.

8. If controlled testing is needed, create a separate approved-source laboratory test under QC-WI-015.

## 5. Decisions, errors and stop conditions

- Conflicting form revisions: seek Document Control disposition.

- Fixed twelve-row layout is not a scientific sample plan.

## 6. Records and handoff

- Report draft

- Original image ID/hash

- Form number/revision

- Transcription check

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/LABORATORY-REPORT-TEMPLATES.md

- src/modules/laboratory/application/report-drafts.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-004 — Leak-form revision and unit conflict

- DEC-028 — Source description conflicts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory/report-templates

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
