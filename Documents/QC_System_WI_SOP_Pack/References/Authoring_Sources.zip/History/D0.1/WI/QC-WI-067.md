# QC-WI-067 — Review release evidence intake and the nineteen gates

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Verify evidence provenance, candidate binding and gate applicability before release approval.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Named owner; Authorized release reviewer; Trusted evidence provider

Review: Named owner; Authorized release reviewer; Trusted evidence provider

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-030

## 3. Before you start

- The nineteen-gate registry and trusted provider authority are approved.

- Current runtime/build identity and candidate evidence exist.

## 4. Work steps and checks

1. Open /governance/releases/[releaseId] and identify the release/candidate context.

2. Read each canonical gate and its required owner/provider evidence.

3. Check provider identity, attestation payload, candidate binding, freshness and supported signature verification.

4. Verify nonce/replay handling; a repeated provider attestation must not be accepted as new evidence.

5. Distinguish unavailable evidence source from no evidence and denied access.

6. Compare runtime identity, applied migration ledger and artifact digest with the candidate.

7. Keep unresolved gates and authority sources explicit; do not use this documentation pack as test evidence.

8. Approve only through the authorized release workflow after all required gates pass; otherwise retain NO-GO.

## 5. Decisions, errors and stop conditions

- Trusted intake connectivity is not gate acceptance.

- Historical evidence from another SHA/dirty tree must be rebound or rerun.

## 6. Records and handoff

- Gate register

- Trusted attestation

- Runtime/schema identity

- Release decision

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/release-governance

- Documents/RELEASE-RUNBOOK.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-024 — Release gates, applicability and human acceptance

- DEC-025 — Performance budgets and representative environment

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /governance/releases/[releaseId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
