# QC-WI-015 — Create a laboratory test with an approved template

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create a traceable test using the applicable source and frozen template.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Qualified lab entry operator

Review: Qualified lab entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-009

## 3. Before you start

- PERM-LAB-CREATE and source read scope apply.

- An approved applicable template and sample request exist.

## 4. Work steps and checks

1. Open /laboratory/tests/new and identify the request and source receiving item where applicable.

2. Compare product, size, lot and planned test with the request.

3. Choose the exact approved template revision; inspect its source reference and applicability.

4. Check required parameters, datatypes, units and calculation/acceptance source before proceeding.

5. Create through the supported form with the required test identity and samples.

6. Wait for confirmed creation and reopen the saved test.

7. Verify DRAFT, template/source snapshot and correct sample identifiers.

8. Plan a traceable run and equipment context before entering measurements.

## 5. Decisions, errors and stop conditions

- Template unavailable or policy-source required: stop and obtain the approved package.

- Creation does not establish scientific eligibility or a result.

## 6. Records and handoff

- Test identity

- Request and source

- Template snapshot

- Sample list

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/application/create-lab-test.ts

- src/modules/laboratory/application/list-approved-templates.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
