# QC-WI-006 — Check a missing, denied, empty or unavailable source

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Classify a source-read problem without converting it into a false empty or successful result.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Operator; Authorized support

Review: Operator; Authorized support

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-028

## 3. Before you start

- You know the page, operation, time and safe correlation identifier.

- Support has authorized access to source status.

## 4. Work steps and checks

1. Read the visible error or source-status message and retain a sanitized copy.

2. Check whether authentication ended; if so, sign in and reopen the record.

3. Distinguish validation or stale version from source access denial and provider unavailability.

4. For missing or denied protected details, accept the generic not-found response; do not probe inaccessible record identifiers.

5. For provider failure, retain the unavailable state. Do not replace the count with zero or mark the register empty.

6. Use available independent page sections only for their supported scope.

7. Ask the responsible source owner to restore access or supply the missing controlled document through the authorized path.

8. After resolution, reload and verify the source identity and current data before continuing the blocked work.

## 5. Decisions, errors and stop conditions

- Source policy missing: obtain the approved authority; retrying cannot create it.

- No source access: do not broaden grants or bypass the server guard.

## 6. Records and handoff

- Sanitized issue

- Classification

- Resolved source identity

- Continuation check

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/INCIDENT-PROBLEM-RUNBOOK.md

- src/shared/authorization/authorize.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-022 — Worker, telemetry and alerts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /help

- /404

- /500

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
