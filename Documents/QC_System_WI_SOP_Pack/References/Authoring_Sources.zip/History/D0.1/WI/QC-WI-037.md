# QC-WI-037 — Manage an inspection or laboratory template

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Maintain approved-source point definitions without rewriting old executions.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Supervisor; QCM; Explicit named owner

Review: Supervisor; QCM; Explicit named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-022

## 3. Before you start

- P-06 authority and exact template permissions apply.

- Technical source/revision/applicability are available.

## 4. Work steps and checks

1. Open the relevant template administration surface and read current status/version.

2. Identify the product/method and controlled source for each point.

3. Define supported datatype, unit, required flag, criteria, calculation and precision only from approved sources.

4. Review unresolved manual-judgment and NA rules with the method owner.

5. Save and reopen the eligible draft and compare point definitions.

6. Use the permitted template review/approval action only when its policy and evidence apply.

7. For stop/supersede, retain a reason and verify the new template state.

8. Check that existing inspection/lab snapshots retain their original context.

## 5. Decisions, errors and stop conditions

- Admin or non-named owner role alone does not grant P-06 authority.

- Approved template without approved criteria still cannot create an official result.

## 6. Records and handoff

- Template/version

- Per-point source

- Review decision

- Snapshot preservation

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/templates/domain/template-state.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-005 — Per-point and overall evaluation

- DEC-016 — Generic signature and document authority

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

- /quarantine/admin

- /documents

- /documents/new

- /documents/[documentId]

- /documents/[documentId]/versions/new

- /documents/[documentId]/versions/[versionId]

- /documents/[documentId]/versions/[versionId]/review

- /quarantine/admin/[templateId]

- /documents/[documentId]/versions/[versionId]/edit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
