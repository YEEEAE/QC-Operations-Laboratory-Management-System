# QC-WI-047 — Create and verify a PLANNED restore intent

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Persist a restore request without claiming execution.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Explicitly authorized drill actor; Named owner

Review: Explicitly authorized drill actor; Named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-029

## 3. Before you start

- Explicit drill permission and GLOBAL scope apply.

- The backup is eligible and current snapshot/version are loaded.

- A meaningful reason and isolated intent target exist.

## 4. Work steps and checks

1. Open /system/backups and inspect the selected backup evidence.

2. Read its eligibility, version and restrictions.

3. Open the supported restore-intent form and enter the reason.

4. Keep the per-form eligibility digest and stable idempotency key unchanged for the same request.

5. Submit once with the opened backup context.

6. If uncertain, resolve the saved intent/replay before another request.

7. Reload the intent and verify PLANNED, reason and audit/outbox relationship.

8. Hand execution to an explicitly authorized recovery operator; this system currently provides no restore executor.

## 5. Decisions, errors and stop conditions

- Stale eligibility or denied scope: stop.

- PLANNED does not mean RESTORED, and no production restore is authorized.

## 6. Records and handoff

- Backup snapshot

- Stable request identity

- PLANNED intent

- Recovery handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/backup-recovery

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

- DEC-021 — Recovery authority, provider and objectives

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /system/backups

- /system/backups/[backupId]

- /system/backups/[backupId]/restore

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
