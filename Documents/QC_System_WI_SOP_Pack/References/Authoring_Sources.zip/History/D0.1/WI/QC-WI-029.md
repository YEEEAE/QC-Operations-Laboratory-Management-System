# QC-WI-029 — Create and track CAPA actions

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Plan linked actions with owners and evidence of completion.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator; CAPA owner

Review: QC entry operator; CAPA owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-018

## 3. Before you start

- An actual NCR link and required persisted prerequisites exist.

- PERM-CAPA-CREATE and action scope apply.

## 4. Work steps and checks

1. Read the NCR and supported causal conclusion.

2. Open the CAPA creation surface and retain the NCR identifier.

3. Enter title, description and at least one action.

4. Assign each action owner and approved due date or target context.

5. Define expected completion evidence and the approved verification/effectiveness criteria.

6. Save and reopen DRAFT to verify actions and predecessor link.

7. Use OPEN/START and later actions only through supported transitions.

8. Record actual action work and evidence; do not equate action completion with effectiveness.

## 5. Decisions, errors and stop conditions

- No NCR or incomplete prerequisites: creation/advancement stays denied.

- A caller-supplied verified flag is not persisted evidence.

## 6. Records and handoff

- CAPA and actions

- Owners and dates

- Completion evidence

- NCR link

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/capa/domain/capa.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/capa

- /quality/capa/new

- /quality/capa/[capaId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
