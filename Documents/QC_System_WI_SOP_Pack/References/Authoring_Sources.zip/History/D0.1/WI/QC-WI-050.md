# QC-WI-050 — Pressure Decay connector leakage test — technical review proposal

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Develop and execute, after approval, a pressure-decay method for the exact applicable connector and product.

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

## 2. Responsibilities and review

Responsible specialists: Leak-test specialist; Metrology; QC/QMS

Review: Leak-test specialist; Metrology; QC/QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-009

## 3. Before you start

- DEC-001 to DEC-006 and the product-specific applicability decision are resolved before controlled testing.

- Approved device manual, program, fixture, reference connector, calibration and safety limits are present.

- The approved sample plan and effective method are available.

## 4. Work steps and checks

1. Identify product, connector type, lot and samples. Confirm whether the connector is within ISO 80369-7:2021 or another application standard; do not apply Luer requirements to every product.

2. Obtain the licensed applicable clauses and compare the method with ISO 80369-20:2024. Its catalog establishes scope; detailed limits have not been verified from licensed text in this pack.

3. Check equipment ACTIVE eligibility, matching calibration, fixture condition, reference leak/background checks and the approved pressure safety procedure.

4. Assemble the actual connector/reference pair with approved force, torque, time and orientation. Record actual settings; do not silently use photographed historical settings.

5. Condition samples and record actual temperature/humidity under the approved method. Verify effective test volume, pressure basis, pressure program and stabilization/holding timing.

6. Use the approved fill, isolate/stabilize, measure and safely vent cycle. The ATEQ manufacturer overview supports this general sequence but is not the manual for the photographed instrument.

7. Retain set pressure, applied pressure, volume, start/end pressure or pressure difference, holding time, leakage throughput, sample ID and original instrument print/file.

8. Independently check the proposed stable-volume equation q = V × abs(Pstart − Pend)/Δt, using cm³, Pa and seconds. Address temperature, compliance, background leak and instrument compensation before adopting it.

9. Evaluate each valid sample only against the approved method’s criterion and aggregation rule. No official PASS/FAIL is generated from this draft or from the printed form alone.

10. Reconcile the report, instrument output and sample/run context. Submit for two-stage review and keep receiving release separate.

## 5. Decisions, errors and stop conditions

- Observed F-8-2-6-05 Rev04 prints pressure 300–330 kPa, hold 15–20 s and <5000 Pa·cm³/s; these are OBSERVED, NOT APPROVED parameters.

- The pictured run has handwritten settings/results and incomplete or differing units; investigate actual vs set pressure, assembly values and instrument timing labels.

- Leak, unstable pressure, failed reference check or fixture failure: retain data, HOLD affected work and obtain invalid-run/retest decision.

## 6. Records and handoff

- Approved method/clauses

- Sample plan

- Assembly/environment/settings

- Raw print/files

- Calculation check

- Reviewed report

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- EXT-001

- EXT-002

- EXT-009

- FORM-003

- QC-SOP-009

- QC-SOP-010

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-003 — Sampling plan

- DEC-004 — Leak-form revision and unit conflict

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/report-templates

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
