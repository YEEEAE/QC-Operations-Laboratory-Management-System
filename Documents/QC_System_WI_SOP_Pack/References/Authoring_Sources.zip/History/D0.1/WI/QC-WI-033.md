# QC-WI-033 — Record and review calibration evidence

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Enter the actual calibration and assess certificate suitability.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Metrology; Authorized calibration actor

Review: Metrology; Authorized calibration actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-021

## 3. Before you start

- Approved calibration method and interval exist.

- PERM-CAL-CREATE and asset scope apply.

## 4. Work steps and checks

1. Identify the asset and actual service date.

2. Open /assets/calibrations/new and link the correct equipment.

3. Enter supported service/certificate fields from the original evidence.

4. Review as-found/as-left results, uncertainty, traceability and tolerances under the approved method.

5. Record an out-of-tolerance concern and affected prior-work assessment.

6. Save and reopen to compare evidence and state.

7. Use only supported authorized review/transitions; do not force MAKE_CURRENT.

8. Check equipment eligibility after accepted calibration and retain the original certificate.

## 5. Decisions, errors and stop conditions

- No approved interval/tolerance: seek metrology decision.

- Attachment alone is not an accepted calibration.

## 6. Records and handoff

- Calibration record

- Certificate

- Technical review

- Impact/eligibility check

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/assets/calibration/domain/calibration.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-002 — Leak-test equipment manual and safety

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /assets

- /assets/equipment

- /assets/equipment/new

- /assets/equipment/[equipmentId]

- /assets/calibrations

- /assets/calibrations/new

- /assets/calibrations/[calibrationId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
