# QC-WI-036 — Save a document draft against its opened version

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Use content-hash and version compare-and-swap for document editing.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized document author

Review: Authorized document author

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-022

## 3. Before you start

- An eligible draft has been opened.

- The original opened version and content hash are retained by the form.

## 4. Work steps and checks

1. Open the document version edit form and confirm it is editable.

2. Review source and current content before changing it.

3. Enter the intended changes and preserve evidence links.

4. Submit with the opened expectedVersion and content hash.

5. Do not replace either value to bypass a conflict.

6. On stale/hash mismatch, preserve input and use QC-WI-007.

7. After confirmed success, reopen and compare content and new version.

8. Send the changed draft through its required review process.

## 5. Decisions, errors and stop conditions

- Locked state: use authorized revision/reopen process.

- Unknown result: reconcile saved content before resubmission.

## 6. Records and handoff

- Opened version/hash

- Saved content

- Conflict resolution where needed

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/documents

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-005 — Per-point and overall evaluation

- DEC-016 — Generic signature and document authority

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /documents

- /documents/new

- /documents/[documentId]

- /documents/[documentId]/versions/new

- /documents/[documentId]/versions/[versionId]

- /documents/[documentId]/versions/[versionId]/review

- /documents/[documentId]/versions/[versionId]/edit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
