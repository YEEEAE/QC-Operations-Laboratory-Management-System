# QC-WI-060 — Endotracheal tubes — inspection and test review proposal

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Prepare an applicable inspection/test plan for endotracheal tubes and execute it only after technical approval.

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

## 2. Responsibilities and review

Responsible specialists: Airway product specialist; QC/QMS

Review: Airway product specialist; QC/QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-008

## 3. Before you start

- DEC-015, DEC-001, DEC-003 and DEC-005 are resolved before controlled acceptance.

- Effective product drawing, licensed applicable method and sample plan are present.

- Qualified operator and suitable calibrated equipment are available.

## 4. Work steps and checks

1. Identify the product code, model, size, lot, supplier/manufacturing context and sterile/bulk status.

2. Confirm oral/nasal, cuffed/uncuffed, reinforced and other variants. ISO 5361:2023 corrected2023-11 and Amd1:2026 need applicability review for the exact product.

3. Compare the supplied company inspection form with the effective product drawing and resolve revision differences.

4. Inspect tube/tip, Murphy eye where applicable, connector, cuff, pilot balloon/inflation tube, markings, dimensions and packaging against the approved variant.

5. Propose patency/kink, connector/joint, cuff and pilot-balloon integrity tests under licensed applicable methods.

6. Apply cuff/balloon points only to the actual cuffed variant; radiopaque and guide marking requirements need approved design evidence.

7. Record inflation settings and medium from the approved method; no cuff pressure or leakage limit is supplied by this draft.

8. Select and label samples using the approved plan. Record actual per-point sample count rather than inferring it from form layout.

9. Record each observation and raw measurement with sample, unit, equipment, method revision and remarks. Keep printed/historical form values separate from approved criteria.

10. Evaluate under approved point and overall decision rules; hold uncertain work and retain failures.

11. Submit the exact record for Supervisor and QCM review; a reviewed test is not a receiving release.

## 5. Decisions, errors and stop conditions

- Missing drawing, intended-use mapping, method clause or limit: do not execute controlled acceptance.

- A handwritten tick, N/A or Accepted mark is historical evidence, not authority for a new test.

- Failed or invalid work: retain raw evidence and obtain containment/retest disposition.

## 6. Records and handoff

- Product applicability decision

- Approved point/test plan

- Sample log

- Raw evidence

- Reviewed inspection

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- FORM-014

- EXT-011

- QC-SOP-007

- QC-SOP-008

- QC-SOP-009

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-003 — Sampling plan

- DEC-005 — Per-point and overall evaluation

- DEC-015 — Tracheal-tube variants and current source

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
