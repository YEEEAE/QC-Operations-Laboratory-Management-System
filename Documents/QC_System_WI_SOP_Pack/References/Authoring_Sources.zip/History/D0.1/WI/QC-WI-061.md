# QC-WI-061 — Establish and measure an approved performance baseline

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Measure representative performance and compare with approved service objectives.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Performance engineer; Product owner; QMS

Review: Performance engineer; Product owner; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-030

## 3. Before you start

- Owner-approved metrics, budgets and workload/applicability exist.

- The environment, hardware, dataset and exact candidate are recorded.

## 4. Work steps and checks

1. Define user operations and representative permitted dataset sizes with the owner.

2. Record candidate SHA/dirty fingerprint, runtime, DB18 version, hardware, browser/device and network conditions.

3. Define warm and first-request/cold conditions and sufficient repeated samples before measuring.

4. Capture raw query count, latency/p95, payload size and applicable LCP/INP using the project-supported tools.

5. Separate server, database and browser timings; record failed requests and unavailable measurements.

6. For a change, repeat before/after under the same conditions and retain raw samples.

7. Compare against the actually approved budget, not a historical proposed number.

8. Record remaining environment or device limits and obtain owner review before an acceptance claim.

## 5. Decisions, errors and stop conditions

- No approved budget: measurements can be recorded but acceptance stays unresolved.

- Local loopback or an after-only sample does not establish production improvement.

## 6. Records and handoff

- Approved baseline

- Environment/workload

- Raw samples

- Comparison and acceptance

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

- Documents/RELEASE-RUNBOOK.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-024 — Release gates, applicability and human acceptance

- DEC-025 — Performance budgets and representative environment

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
