# QC-WI-002 — Open and save a receiving correction

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Correct eligible receiving fields with a source-backed reason and opened version.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized QC entry operator

Review: Authorized QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-005

## 3. Before you start

- Original evidence and corrected facts are available.

- PERM-QUAR-EDIT, ownership/scope and state permit correction.

## 4. Work steps and checks

1. Open /quarantine/receiving/[receivingId] and confirm PENDING, READY_FOR_INSPECTION, HOLD or EXPIRED.

2. Use the correction link to open the populated form; note the version that opened.

3. Compare all existing values with the original document. Identify exactly what is wrong.

4. Enter supported corrections to supplier, docNo, itemCode, description, lot, qty, quantityUnit, purchaseOrderNo and dates.

5. Write a reason that states the original error and supporting document. Do not use a blank or unexplained “updated”.

6. Submit the populated form with its expectedVersion. Keep any unsaved correction if the server rejects it.

7. After confirmed success, reload and check corrected fields, new version and retained reason/history.

8. Tell the inspection owner if the correction changes the work context; use the controlled inspection/HOLD route for frozen facts.

## 5. Decisions, errors and stop conditions

- Stale version: use QC-WI-007 and compare both records.

- UNDER_INSPECTION or later frozen snapshot: do not force an edit.

## 6. Records and handoff

- Correction source

- Reason

- Reloaded corrected record

- Version history

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/correct-receiving.ts

- src/modules/quarantine/receiving/domain/receiving-state.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/receiving

- /quarantine/receiving/new

- /quarantine/receiving/[receivingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
