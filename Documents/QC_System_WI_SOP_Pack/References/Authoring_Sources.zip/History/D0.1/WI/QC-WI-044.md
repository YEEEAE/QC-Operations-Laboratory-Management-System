# QC-WI-044 — Find scoped work and read in-app notifications

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Navigate bounded worklists and personal notifications to the current controlled record.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authenticated authorized user

Review: Authenticated authorized user

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-026

## 3. Before you start

- The user has source read scope.

- The relevant dashboard/work/search route is accessible.

## 4. Work steps and checks

1. Open /dashboard, /work or /search and review source status.

2. Enter relevant search/filter terms without probing inaccessible records.

3. Check the exact total and page boundary; continue pagination if needed.

4. Open the underlying record and read its current state/version.

5. Use the in-app notification register for your own events.

6. Mark your own item read through the supported action.

7. Remember that only implemented final-approval projections imply those specific events; stage1 is silent.

8. Complete the actual work through its domain action, not the notification.

## 5. Decisions, errors and stop conditions

- Denied or unavailable sources remain distinct from empty.

- Mark-read is not controlled acknowledgment or external delivery.

## 6. Records and handoff

- Underlying record handoff

- Page/filter context

- Own read state

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/dashboard

- src/shared/routing/routes.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-022 — Worker, telemetry and alerts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /dashboard

- /work

- /search

- /notifications

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
