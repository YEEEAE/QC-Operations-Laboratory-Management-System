# QC-WI-049 — Freeze release evidence and conduct real UAT

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Bind acceptance evidence to the actual candidate and real participant actions.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Engineering; Verification lead; Human UAT participants; QCM/owner

Review: Engineering; Verification lead; Human UAT participants; QCM/owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-030

## 3. Before you start

- Approved gate/authority sources and isolated PostgreSQL18 environment exist.

- Real participants and valid domain sources are available.

## 4. Work steps and checks

1. Record HEAD, branch, status, dirty fingerprint, migration source head and runtime identity.

2. Begin the project verification-run context before building evidence.

3. Map assigned routes/operations to real persona, state and acceptance criteria.

4. Execute applicable DB18 rollback/concurrency, browser/no-JS, accessibility and performance checks; preserve raw outcomes.

5. The owner creates the authorized UAT cycle/defects and participants record only their own role-bound sessions.

6. QCM/owner accepts only through the actual signed ceremony; do not generate human signatures or observations.

7. Reconcile all nineteen canonical gates and trusted evidence intake with the exact candidate.

8. Keep NO-GO when evidence is missing. Deployment/migration/publication need separate explicit authority.

## 5. Decisions, errors and stop conditions

- Later tree edits invalidate affected candidate evidence.

- Source tests and this pack do not constitute UAT or production acceptance.

## 6. Records and handoff

- Candidate freeze

- Verification raw evidence

- Real UAT sessions/signature

- Gate decision

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/RELEASE-RUNBOOK.md

- src/modules/uat-evidence

- src/modules/release-governance

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-024 — Release gates, applicability and human acceptance

- DEC-025 — Performance budgets and representative environment

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /governance/releases/[releaseId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
