# QC-WI-025 — Carry out an approved internal transfer or rework handoff

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record the physical movement and preserve lot status and quantity balance.

Implementation: PROPOSED MANUAL PROCEDURE

## 2. Responsibilities and review

Responsible specialists: Warehouse; Production; QC

Review: Warehouse; Production; QC

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-016

## 3. Before you start

- Approved disposition and destination exist.

- Rework method and reinspection requirements are approved.

## 4. Work steps and checks

1. Read the disposition and identify the permitted lot, quantity/unit and action.

2. Count segregated units and record origin, destination and status.

3. Prepare the movement/rework record with related QC identifiers.

4. Keep HOLD/rejected labels during movement unless the actual disposition explicitly changes status.

5. Have the receiver compare identity, quantity and condition before accepting the handoff.

6. For rework, record work performed against the approved instruction.

7. Create required new inspection/retest work and retain the original failure.

8. Reconcile sender/receiver quantities and store the completed physical evidence.

## 5. Decisions, errors and stop conditions

- No digital transfer ledger exists for this process; use the approved manual record.

- No disposition: do not move or relabel.

## 6. Records and handoff

- Movement record

- Quantity reconciliation

- Rework evidence

- Reinspection link

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
