# QC-WI-014 — Correct returned work and reopen approved work

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Use supported correction and reopen paths without changing locked history directly.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Author; Authorized reopen actor

Review: Author; Authorized reopen actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-011

## 3. Before you start

- The return reason or authorized reopen reason exists.

- The actor has the exact action permission and current version.

## 4. Work steps and checks

1. Read the review comments and distinguish missing evidence from changed technical criteria.

2. For RETURNED work, invoke RESUME where supported and verify DRAFT.

3. Correct only the identified issues and retain original raw evidence.

4. Save and recheck sample links, units and source applicability.

5. Resubmit the corrected version through the normal review chain.

6. For APPROVED work, do not open a draft edit or alter database state.

7. An authorized actor invokes REOPEN with required evidence; confirm UNDER_REVIEW and retained prior approval.

8. Repeat the required review stages and bind final signature to the changed version.

## 5. Decisions, errors and stop conditions

- No reopen authority: retain the issue and request the authorized workflow.

- Do not infer that an earlier signature approves later corrections.

## 6. Records and handoff

- Return/reopen reason

- Corrected version

- Retained prior approval

- New review chain

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/application/reopen-lab-test.ts

- src/modules/quarantine/inspection/domain/inspection-state.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
