# QC-WI-041 — Respond to instrument failure during a test

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Preserve incomplete data and assess affected work before retesting.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Laboratory; Equipment owner; Technical method owner

Review: Laboratory; Equipment owner; Technical method owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-012

## 3. Before you start

- The run/sample context is identifiable.

- The equipment can be safely stopped under its manual.

## 4. Work steps and checks

1. Stop the run using the approved instrument safe-stop procedure.

2. Identify the equipment, program, sample and failure time.

3. Retain raw readings, error messages, printouts and partial files.

4. Separate affected samples and material; record uncertainty rather than PASS.

5. Open maintenance and assess equipment eligibility.

6. The technical owner reviews whether earlier runs may be affected.

7. Obtain an approved invalid-run/retest decision and preserve the parent evidence.

8. Resume testing only after return-to-use and method prerequisites are demonstrated.

## 5. Decisions, errors and stop conditions

- No device manual: seek equipment specialist; this draft gives no unsafe mechanical instructions.

- Repair does not validate earlier readings.

## 6. Records and handoff

- Failure evidence

- Affected work

- Maintenance

- Retest/return-to-use decision

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/assets/equipment/infrastructure/eligibility-reader.ts

- src/modules/laboratory/application/create-retest.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /assets/maintenance

- /assets/maintenance/new

- /assets/maintenance/[maintenanceId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
