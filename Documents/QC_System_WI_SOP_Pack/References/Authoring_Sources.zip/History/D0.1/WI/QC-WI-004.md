# QC-WI-004 — Place material on HOLD and preserve containment

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Stop affected work and align physical containment with the digital HOLD record.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized HOLD actor; Warehouse

Review: Authorized HOLD actor; Warehouse

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-006

## 3. Before you start

- Affected lot and quantity are identified.

- You have the HOLD action permission and expected version.

## 4. Work steps and checks

1. Identify the receiving record and the precise scope of uncertainty.

2. Record the factual reason and affected units before changing status.

3. Segregate or restrict physical use under the site containment instruction.

4. Open the current receiving detail and use the supported HOLD action.

5. Submit the reason and opened expectedVersion, then verify the saved HOLD state.

6. Link the investigation, failed equipment, missing source or disputed result as appropriate.

7. Notify the responsible work owner through the authorized operational channel; this instruction does not automatically send external messages.

8. Retain HOLD until an approved disposition and supported recovery path exist. The current HOLD state has no general outgoing transition.

## 5. Decisions, errors and stop conditions

- Unknown write result: reconcile before another action.

- A REMOVE_HOLD action type name does not establish an implemented recovery path.

## 6. Records and handoff

- HOLD reason and version

- Physical containment scope

- Investigation handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/hold-receiving.ts

- src/modules/quarantine/receiving/domain/receiving-state.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine

- /quarantine/receiving

- /quarantine/receiving/new

- /quarantine/receiving/[receivingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
