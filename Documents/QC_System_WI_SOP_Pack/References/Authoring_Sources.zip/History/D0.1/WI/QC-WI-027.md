# QC-WI-027 — Create an NCR linked to persisted evidence

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create an NCR from a qualifying finding without substituting caller assertions for prerequisites.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized QC entry operator; Quality owner

Review: Authorized QC entry operator; Quality owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-017

## 3. Before you start

- The related Finding exists and is accessible.

- PERM-NCR-CREATE, scope and persisted prerequisites apply.

## 4. Work steps and checks

1. Open the source Finding and verify its evidence and affected scope.

2. Check the approved prerequisite and classification rules.

3. Open the supported NCR creation entry and select the actual predecessor.

4. Enter the nonconformance description, required owner/context and evidence.

5. Do not supply an arbitrary prerequisite flag as proof of completion.

6. Save and reopen the NCR to verify its persisted Finding link.

7. Assign containment/investigation under the approved policy.

8. Hand the NCR to the causal-analysis owner when that step is required.

## 5. Decisions, errors and stop conditions

- Unavailable prerequisite source: deny advancement.

- Proposed October quality policy is not an approved classification rule.

## 6. Records and handoff

- NCR

- Persisted Finding relationship

- Containment and investigation handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/ncr/domain/ncr.ts

- Documents/QUALITY-POLICY-DECISION-PACK-2026-10-02.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/ncr

- /quality/ncr/new

- /quality/ncr/[ncrId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
