# QC-WI-016 — Record a laboratory run and equipment context

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Bind samples, raw readings and calibration context to one identified execution.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Qualified laboratory operator

Review: Qualified laboratory operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-009

## 3. Before you start

- The test is eligible for run entry.

- The method and equipment are approved and equipment eligibility passes.

## 4. Work steps and checks

1. Open the test execution surface and read its frozen method context.

2. Identify the run and samples actually tested together.

3. Check equipment ACTIVE state, maintenance status and matching CURRENT non-overdue calibration.

4. Record the exact equipment/calibration reference and required setup context.

5. Use the approved method to prepare fixtures, medium and reference checks.

6. Record actual environment and run timing where required by the method.

7. Acquire each replicate against its sample and parameter; preserve the instrument file/print.

8. Save and reopen the run to verify sample/run/equipment relationships.

## 5. Decisions, errors and stop conditions

- Ineligible or unavailable equipment source: stop testing.

- Equipment failure mid-run: preserve partial data and use QC-WI-041.

## 6. Records and handoff

- Run identity

- Sample mapping

- Equipment/calibration snapshot

- Raw readings

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/application/record-lab-run.ts

- src/modules/laboratory/application/record-run-equipment.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
