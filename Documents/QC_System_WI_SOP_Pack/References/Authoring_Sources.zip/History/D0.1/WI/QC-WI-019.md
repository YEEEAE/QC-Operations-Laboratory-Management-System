# QC-WI-019 — Check a calculated result before review

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Independently check calculation inputs, units and approved rule version.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Technical reviewer; Laboratory

Review: Technical reviewer; Laboratory

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-010

## 3. Before you start

- The raw replicates and approved calculation rule are present.

- The rule defines rounding, precision and evaluation.

## 4. Work steps and checks

1. Read the rule identity, revision and source applicability.

2. Locate every raw input and verify sample/run association.

3. Confirm units and distinguish throughput from volumetric leakage; do not treat Pa·cm³/s as cm³/s.

4. For a proposed q = V × abs(ΔP)/Δt check, use cm³, Pa and seconds and record the stable-volume/isothermal assumptions.

5. Compare the rule with the actual instrument algorithm and effective fixture volume; this draft does not substitute for the device manual.

6. Recalculate without premature rounding and retain the check inputs.

7. Compare the result with the stored calculatedValue, calculatedUnit and calculationRuleReference/version.

8. Report disagreement for technical investigation before evaluation or approval.

## 5. Decisions, errors and stop conditions

- Unapproved equation or incompatible units: retain raw data and stop calculation approval.

- A mathematically correct number does not establish an approved acceptance limit.

## 6. Records and handoff

- Rule/version

- Inputs and unit check

- Independent calculation

- Discrepancy

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/domain/measurement.ts

- EXT-009

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-006 — Leak calculation validation

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
