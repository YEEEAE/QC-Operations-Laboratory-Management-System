# QC-WI-023 — Record authorized rejection approval confirmations

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record evidence of a real approval in the permitted checkpoint order.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized checkpoint actor

Review: Authorized checkpoint actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-014

## 3. Before you start

- Current approved authority and exact action grant exist.

- The real approval evidence is retrievable.

- QC entry users are excluded.

## 4. Work steps and checks

1. Open /reject-reports/issue-slips/[reportId] and read current state/version.

2. Verify the approval evidence relates to this material, lot, quantity and report.

3. Check the current required checkpoint: SUPERVISOR, QC_MANAGER or FACTORY_DIRECTOR under the supported chain.

4. Resolve the difference between printed Production Manager and application Supervisor labels under the approved QMS mapping.

5. Record the business approver name and supporting evidence only when the real approval occurred.

6. Submit the permitted confirmation with the current expectedVersion.

7. Reload and verify that the correct checkpoint advanced and prior evidence remains.

8. Complete only after all required checkpoints; typed names remain business evidence, not a fabricated e-signature.

## 5. Decisions, errors and stop conditions

- No approved role mapping or signer evidence: retain pending approval.

- QC cannot confirm its own or another person’s approval.

## 6. Records and handoff

- Checkpoint evidence

- Approver business field

- Versioned confirmation

- Completed-chain check

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reject-reports

- /reject-reports/new

- /reject-reports/issue-slips/[reportId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
