# QC-WI-066 — Review quarantine administration and configuration sources

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Distinguish template control from policy/configuration availability.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized template administrator; Named owner; QC technical owner

Review: Authorized template administrator; Named owner; QC technical owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-022

## 3. Before you start

- The actor has the exact administration/template permission.

- The source contract and approved technical decision exist.

## 4. Work steps and checks

1. Open /quarantine/admin or the relevant template detail under authorized scope.

2. Check whether the primary source is available, denied or empty.

3. Read the current template and frozen-source relationships.

4. Use QC-WI-037 for eligible template edits/review/stop actions.

5. Treat unrelated configuration panels as unavailable if their providers are absent; do not fabricate settings.

6. Identify the responsible source owner and required configuration/authority decision.

7. Verify any authorized change through the actual source and record version.

8. Confirm existing executions retain their original template snapshot.

## 5. Decisions, errors and stop conditions

- Page access does not authorize configuration mutation.

- Missing source does not permit a default criterion or guard bypass.

## 6. Records and handoff

- Template/configuration source status

- Owner decision

- Authorized change evidence

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/templates

- src/shared/routing/routes.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-005 — Per-point and overall evaluation

- DEC-016 — Generic signature and document authority

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/admin

- /quarantine/admin/[templateId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
