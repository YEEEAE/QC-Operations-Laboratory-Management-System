# QC-WI-032 — Register and inspect an equipment asset

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create a reliable asset identity and verify physical condition.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Asset entry operator; Equipment owner

Review: Asset entry operator; Equipment owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-020

## 3. Before you start

- Manufacturer/model/serial evidence and asset label exist.

- PERM-EQP-CREATE and authorized scope apply.

## 4. Work steps and checks

1. Read the physical label and manufacturer evidence.

2. Open /assets/equipment/new and enter supported identity fields.

3. Keep asset identity distinct from calibration certificate number.

4. Record intended method use in the controlled equipment documentation.

5. Save and reopen the asset record.

6. Compare label, model/serial and stored identity.

7. Inspect condition and identify missing suitability/manual evidence.

8. Hand the equipment record to calibration/maintenance control before controlled use.

## 5. Decisions, errors and stop conditions

- Unknown identity: do not fabricate a serial number.

- Registration does not prove fitness for use.

## 6. Records and handoff

- Asset record

- Physical identity check

- Suitability/manual source

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/assets/equipment/domain/equipment.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-002 — Leak-test equipment manual and safety

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /assets

- /assets/equipment

- /assets/equipment/new

- /assets/equipment/[equipmentId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
