# QC-WI-039 — Prepare a human training and competency assessment

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record actual demonstrated competence for a procedure and equipment scope.

Implementation: PROPOSED MANUAL PROCEDURE

## 2. Responsibilities and review

Responsible specialists: Trainer; Technical assessor

Review: Trainer; Technical assessor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-002

## 3. Before you start

- Effective procedure and approved task scope exist.

- An approved practical assessment is available.

## 4. Work steps and checks

1. Identify the person, task, procedure revision and equipment/method scope.

2. Explain the method, stop conditions and record requirements.

3. Demonstrate the task using authorized training material.

4. Observe the trainee perform it and handle a relevant error.

5. Record what was actually observed and any limitations.

6. The technical assessor decides competence under approved criteria.

7. Record actual authorization and required supervision.

8. Schedule reassessment only under the approved policy and update the training matrix.

## 5. Decisions, errors and stop conditions

- Attendance alone does not demonstrate competence.

- This source has no dedicated digital training module.

## 6. Records and handoff

- Training matrix

- Observed assessment

- Task authorization

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/ROLE-MATRIX.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
