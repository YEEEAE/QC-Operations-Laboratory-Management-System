# QC-WI-048 — Verify an isolated database-and-files recovery

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Demonstrate actual retrieval and restoration in an approved isolated destination.

Implementation: PROPOSED OPERATOR PROCEDURE — PROVIDER RUNBOOK REQUIRED

## 2. Responsibilities and review

Responsible specialists: Authorized recovery operator; Provider; Verification reviewer

Review: Authorized recovery operator; Provider; Verification reviewer

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-029

## 3. Before you start

- Durable provider artifacts and approved recovery procedure exist.

- Destination is isolated and explicitly authorized.

- RPO/RTO targets and measurements are defined.

## 4. Work steps and checks

1. Record source backup times, scope and database/file consistency evidence.

2. Retrieve original artifacts and verify manifest and checksums.

3. Create the isolated destination under approved access/configuration.

4. Restore database and files using the exact provider/manual procedure; this draft is not an executable provider runbook.

5. Verify applied schema ledger/checksums and record relationships.

6. Retrieve representative raw files and compare their digests.

7. Check signature/audit/provenance links and approved functional operations.

8. Record actual recovery point and elapsed recovery time, compare with approved targets and retain reviewer/provider evidence.

## 5. Decisions, errors and stop conditions

- No artifacts, provider manual or target authority: no drill execution claim.

- A database-only dump does not prove file recovery.

## 6. Records and handoff

- Artifact retrieval

- Isolated restore log

- DB/file verification

- Measured RPO/RTO

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/BACKUP-RECOVERY-PLAN.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

- DEC-021 — Recovery authority, provider and objectives

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /system/backups

- /system/backups/[backupId]

- /system/backups/[backupId]/restore

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
