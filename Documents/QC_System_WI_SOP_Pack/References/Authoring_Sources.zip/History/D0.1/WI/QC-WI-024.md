# QC-WI-024 — Enter a daily production/rejection report

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Capture exact daily line data and verify denominator meaning before reporting.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Production; QC entry operator

Review: Production; QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-015

## 3. Before you start

- Production source sheet and quantities are available.

- The actor has report creation/edit grants.

## 4. Work steps and checks

1. Open /reject-reports/new?type=daily and identify the date/section/department.

2. Enter product, machine, lot, material and quantity fields supported by the digital form.

3. Keep good and reject quantities and unit separate on every line.

4. Append additional lines using the current expectedVersion.

5. Reload and compare line order, exact decimals and source totals.

6. Check grouping by unit and report type.

7. Record that implemented reject percentage is reject/good ×100 with four-decimal rounding; good zero gives NULL.

8. Send eligible work to the authorized finalizer; QC entry users cannot finalize or void.

## 5. Decisions, errors and stop conditions

- Metric not approved: do not label it as approved total-output defect rate.

- Mixed units or zero denominator: retain the explicit limitation.

## 6. Records and handoff

- Daily source

- Persisted lines/version

- Unit totals

- Metric interpretation

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reject-reports

- /reject-reports/new

- /reject-reports/issue-slips/[reportId]

- /reject-reports/daily/[reportId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
