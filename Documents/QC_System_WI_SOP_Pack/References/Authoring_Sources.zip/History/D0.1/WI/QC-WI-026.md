# QC-WI-026 — Create a factual Finding

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Capture an observable concern with traceable evidence and containment context.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator

Review: QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-017

## 3. Before you start

- Evidence and affected product/process are identifiable.

- PERM-FIND-CREATE and scope apply.

## 4. Work steps and checks

1. Describe what was observed, where and when.

2. Separate the observed fact from a suspected cause.

3. Open /quality/findings/new and enter a clear title and description.

4. Include affected lot/record references and supporting evidence through supported fields.

5. Record immediate containment in the approved operational record.

6. Save and reopen to verify identity and evidence links.

7. Use supported submission/review actions only when their prerequisites pass.

8. Hand the finding to the quality owner for classification and NCR decision.

## 5. Decisions, errors and stop conditions

- Unknown affected scope: record it explicitly and investigate.

- Creation does not grant closure authority.

## 6. Records and handoff

- Finding

- Evidence

- Containment scope

- Quality-owner handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/findings/domain/finding.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
