# QC-WI-062 — Review audit evidence and controlled-record history

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Trace a change or decision across record, version, signature and audit evidence.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized audit reader; QMS

Review: Authorized audit reader; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-024

## 3. Before you start

- Audit-view permission and record scope apply.

- The target record and action/time context are known.

## 4. Work steps and checks

1. Open /audit through your authorized account and apply the relevant supported filters.

2. Find the target record and action using identifiers rather than unnecessary personal data.

3. Compare actor, action, time and request correlation with the record history.

4. For a signed decision, inspect the actual target version/hash and signature meaning.

5. Confirm that a correction/reopen preserves earlier evidence and does not rewrite it.

6. For an outbox event, keep transactional enqueue evidence separate from actual delivery.

7. Record a discrepancy in the incident or quality process without modifying the audit row.

8. Retain a permitted sanitized extract under the approved record policy.

## 5. Decisions, errors and stop conditions

- Audit event alone is not signature or physical execution proof.

- No update/delete of historical audit evidence is authorized.

## 6. Records and handoff

- Audit trace

- Record/signature comparison

- Sanitized discrepancy

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DATA-GOVERNANCE-REGISTER-032.md

- src/shared/routing/routes.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /audit

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
