# QC-WI-010 — Receive and hand over laboratory samples

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Document sample custody and resolve discrepancies before testing.

Implementation: PROPOSED MANUAL PROCEDURE

## 2. Responsibilities and review

Responsible specialists: Sampler; Laboratory receiver

Review: Sampler; Laboratory receiver

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-007

## 3. Before you start

- A labeled sample and test request exist.

- The custody record and approved handling rules are available.

## 4. Work steps and checks

1. Read the label and compare receiving/test reference, lot, product and sample identifier.

2. Count received units and compare with the request and selection log.

3. Check packaging condition, contamination concerns and required temperature/time conditions.

4. Record sender, receiver, handoff time, destination, purpose and condition in the controlled custody log.

5. If identity or condition is uncertain, separate the sample and seek a technical decision.

6. Associate the accepted sample identifier with the correct laboratory test/run.

7. At a later handoff, repeat identity, quantity and condition checks and preserve prior custody entries.

8. After testing, record consumed, retained and returned quantities under the approved disposition.

## 5. Decisions, errors and stop conditions

- Broken custody or mixed lot: do not silently relabel.

- Sample retention/disposal periods require QMS approval.

## 6. Records and handoff

- Custody log

- Sample/run link

- Discrepancy and disposition

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/domain/lab-test.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-003 — Sampling plan

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.
