# QC-WI-013 — Complete QCM final approval with signature binding

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Bind FINAL_APPROVE to the exact pending inspection/laboratory version.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QCM; Explicitly authorized named owner

Review: QCM; Explicitly authorized named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-011

## 3. Before you start

- The record is PENDING_QCM_APPROVAL.

- Final authority, domain permission, scope and separation of duties pass.

- The approved FINAL_APPROVE signature ceremony is available.

## 4. Work steps and checks

1. Open the pending record and verify its identity, version and prior Supervisor event.

2. Review all technical evidence and unresolved remarks yourself.

3. Select FINAL_APPROVE only if the reviewed record is still the version presented.

4. Complete your own reauthentication in the supported ceremony; do not share credentials.

5. Confirm the displayed signature meaning and target before submitting.

6. Wait for a definite result; if unknown, reconcile using QC-WI-008.

7. Reload and verify APPROVED, target version/hash, actor and decision/signature evidence.

8. Leave material release to its separate receiving action and preserve the signed history.

## 5. Decisions, errors and stop conditions

- Stale target, failed password or missing signature policy: no approval.

- A typed Approved By name cannot replace the ceremony.

## 6. Records and handoff

- FINAL_APPROVE decision

- Binding signature

- Approved record/version

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- src/modules/laboratory/application/final-approve-lab-test.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

- /approvals

- /approvals/[approvalId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
