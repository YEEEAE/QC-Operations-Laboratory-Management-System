# QC-WI-043 — Generate and reconcile a report export

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Verify the exported data against the scoped screen dataset.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized report reader; Report owner

Review: Authorized report reader; Report owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-025

## 3. Before you start

- PERM-RPT-VIEW and source scope apply.

- Filters, period, units and metric meaning are defined.

## 4. Work steps and checks

1. Open the report and record selected filters and source status.

2. Check scope, exact totals and unit grouping.

3. Identify the report provenance/dataset context before export.

4. Generate the supported export without changing filters.

5. If REPORT_DATASET_CHANGED appears, refresh and review a new coherent snapshot.

6. Compare exported rows, totals, units and provenance with the screen.

7. Retain the output in its approved location and mark unapproved prints clearly.

8. Record distribution only after the approved owner accepts the report meaning and evidence.

## 5. Decisions, errors and stop conditions

- Unavailable source is not zero.

- Request-local digest is not durable snapshot retention.

## 6. Records and handoff

- Filter/provenance context

- Export

- Parity check

- Distribution

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/reporting

- Documents/REJECT-REPORTS.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /reports

- /reports/[reportCode]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
