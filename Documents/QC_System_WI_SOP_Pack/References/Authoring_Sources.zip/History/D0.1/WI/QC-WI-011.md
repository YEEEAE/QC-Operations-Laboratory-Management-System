# QC-WI-011 — Execute an inspection record

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record product inspection observations against the frozen template and source context.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Qualified QC executor

Review: Qualified QC executor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-008

## 3. Before you start

- The linked inspection and samples are ready.

- The source, method and criteria are approved and applicable.

## 4. Work steps and checks

1. Open /quarantine/inspections/[inspectionId]/execute and confirm DRAFT and the opened version.

2. Compare the frozen receiving identity and template version with the physical lot.

3. Read each point’s method, required evidence, unit and approved judgment rule.

4. Inspect the defined sample units and record the actual observation, not only an overall pass mark.

5. Link raw measurements, photos and equipment context to the point they support.

6. Record remarks for discrepancies and use not-applicable only under an approved point rule.

7. Save and reopen the observations to check completeness and correct sample association.

8. Submit eligible completed work to Supervisor review; preserve a scientific-source blocker instead of bypassing evaluation.

## 5. Decisions, errors and stop conditions

- Missing scientific source: retain observations and stop official result generation.

- FAIL or HOLD: follow containment and review, not release.

## 6. Records and handoff

- Per-point observation

- Sample and source snapshot

- Raw evidence

- Submission

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/inspection/domain/inspection-state.ts

- src/shared/routing/routes.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-003 — Sampling plan

- DEC-005 — Per-point and overall evaluation

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
