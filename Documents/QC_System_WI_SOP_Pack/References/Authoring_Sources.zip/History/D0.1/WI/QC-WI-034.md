# QC-WI-034 — Record maintenance and return-to-use checks

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Preserve repair history and demonstrate suitability before use.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Maintenance; Equipment owner

Review: Maintenance; Equipment owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-021

## 3. Before you start

- The equipment and maintenance scope are known.

- PERM-MNT-CREATE and transition grants apply.

## 4. Work steps and checks

1. Identify the failed/serviced equipment and stop affected use.

2. Open /assets/maintenance/new and link the asset.

3. Describe fault, work request and supporting evidence.

4. Record the actual work, parts and test evidence in supported fields/attachments.

5. Maintain ineligible status while blocking maintenance is active.

6. Complete only permitted transitions with required reasons and current version.

7. Perform approved functional/calibration checks after work.

8. Verify eligibility and authorize return to use under the approved owner decision.

## 5. Decisions, errors and stop conditions

- VOID or another unsupported transition remains denied.

- Repair completion does not establish valid calibration.

## 6. Records and handoff

- Maintenance history

- Work evidence

- Functional check

- Return-to-use decision

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/assets/maintenance/domain/maintenance.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-002 — Leak-test equipment manual and safety

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /assets

- /assets/equipment

- /assets/equipment/new

- /assets/equipment/[equipmentId]

- /assets/maintenance

- /assets/maintenance/new

- /assets/maintenance/[maintenanceId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
