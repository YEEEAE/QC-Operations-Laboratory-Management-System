# QC-WI-040 — Manage an account or recover a session

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Use supported account and credential operations while protecting identity history.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized identity administrator; Account holder

Review: Authorized identity administrator; Account holder

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-003

## 3. Before you start

- The access request or password-recovery need is verified.

- The administrator has the exact identity grant and scope.

## 4. Work steps and checks

1. For provisioning, compare requested work with the approved QC role matrix.

2. Use the supported /admin/users create/edit/activate/disable/reset operation only under its exact server permission.

3. Keep the named yazeed owner authority protected; a role string alone is insufficient.

4. Review the returned safe account view without exporting credentials.

5. For self password change, use the account operation and verify confirmed success.

6. After credential change/reset, verify revoked sessions and sign in again.

7. At throttle or pending login, wait for the actual response; do not repeatedly submit.

8. After session expiry, reopen the record and reconcile any earlier unknown write outcome.

## 5. Decisions, errors and stop conditions

- Missing access authority: no grant expansion.

- Page visibility does not establish write permission.

## 6. Records and handoff

- Access request

- Safe account update

- Credential/session audit

- Recovery readback

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/identity

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

- DEC-024 — Release gates, applicability and human acceptance

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /

- /login

- /admin

- /admin/users

- /admin/users/new

- /admin/users/[userId]

- /admin/roles

- /admin/roles/[roleId]

- /admin/permissions

- /admin/scopes

- /account

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
