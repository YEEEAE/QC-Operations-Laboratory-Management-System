# QC-WI-012 — Review an inspection or lab report at stage 1

Revision D0.1 | DRAFT FOR REVIEW | Prepared 2026-10-03

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Complete the first review stage and return or advance the exact submitted version.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Supervisor; Explicitly authorized named owner

Review: Supervisor; Explicitly authorized named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-011

## 3. Before you start

- The actor has the domain review and stage-1 approval grant.

- The submitted record and all evidence are accessible.

## 4. Work steps and checks

1. Open the relevant inspection or lab review page and identify record/version.

2. Start review through the supported action, confirming UNDER_REVIEW.

3. Check sample identity, source applicability, method, raw data, calculation and equipment evidence.

4. If work is incomplete, RETURN with a specific reason and verify RETURNED.

5. If the review is satisfactory, invoke stage-1 APPROVE under the exact authority.

6. Verify PENDING_QCM_APPROVAL and the recorded stage-1 action.

7. Do not claim a formal e-signature at stage1; this chain records a workflow approval event.

8. Hand the exact pending record to QCM for final review.

## 5. Decisions, errors and stop conditions

- MANAGER is not the normal stage-1 authority.

- Unresolved scientific criteria prevent an official approval conclusion.

## 6. Records and handoff

- Review evidence

- Return reason or stage-1 event

- QCM handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- src/modules/laboratory/domain/lab-state.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. All decisions listed above remain open in this authoring delivery.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

- /approvals

- /approvals/[approvalId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.
