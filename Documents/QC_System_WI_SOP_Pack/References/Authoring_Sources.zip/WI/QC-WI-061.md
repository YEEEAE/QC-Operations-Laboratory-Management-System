# QC-WI-061 — Establish and measure an approved performance baseline

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Measure representative performance and compare with approved service objectives.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Performance engineer; Product owner; QMS

Review: Performance engineer; Product owner; QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-030

## 3. Before you start

- Owner-approved metrics, budgets and workload/applicability exist.

- The environment, hardware, dataset and exact candidate are recorded.

## 4. Work steps and checks

1. Define user operations and representative permitted dataset sizes with the owner.

2. Record candidate SHA/dirty fingerprint, runtime, DB18 version, hardware, browser/device and network conditions.

3. Define warm and first-request/cold conditions and sufficient repeated samples before measuring.

4. Capture raw query count, latency/p95, payload size and applicable LCP/INP using the project-supported tools.

5. Separate server, database and browser timings; record failed requests and unavailable measurements.

6. For a change, repeat before/after under the same conditions and retain raw samples.

7. Compare against the actually approved budget, not a historical proposed number.

8. Record remaining environment or device limits and obtain owner review before an acceptance claim.

## 5. Decisions, errors and stop conditions

- No approved budget: measurements can be recorded but acceptance stays unresolved.

- Local loopback or an after-only sample does not establish production improvement.

## 6. Records and handoff

- Approved baseline

- Environment/workload

- Raw samples

- Comparison and acceptance

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

- Documents/RELEASE-RUNBOOK.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-024 — Release gates, applicability and human acceptance

- DEC-025 — Performance budgets and representative environment

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-024 — Release and human UAT evidence

Freeze source SHA, dirty fingerprint, build/runtime identity and migration state. Define real UAT roles and scenarios, including receiving, inspection/lab review, denial, stale version, uncertain submission, reports and recovery intent. Participants execute with their own authorized accounts and record observed outcome, evidence and defects. Preserve failed and blocked cases.

Decision and exception check: A verification lead checks candidate binding and unresolved defects; the authorized acceptor signs only real participant evidence. A source test, authored script or planned scenario cannot be substituted for the session. If the candidate changes, assess affected evidence and rebind/rerun as required. Gate PASS does not itself execute release or deployment.

Record: QC-REC-017 release gate and UAT session; QC-SOP-030; route-coverage register.

DEC-025 — Performance measurement contract

Capture request/query counts, payload size and the relevant timing metric with clock/method details. For p95, retain all raw samples, sample count and percentile method; do not report a percentile from one observation. Compare before/after with equivalent data and conditions. Include errors and timeouts in the stated analysis rather than silently dropping them.

Decision and exception check: For interactive pages, define the measured user interaction and tooling; page load time is not INP. Record server and browser segments separately. If a budget is absent, report measured values and request the acceptance decision without claiming a pass. A local loopback benchmark does not establish provider latency.

Record: QC-REC-018 performance plan and measurements; QC-WI-061.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
