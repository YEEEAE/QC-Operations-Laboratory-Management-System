# QC-WI-038 — Create and start review of a change request

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Prepare impact evidence and start version-bound review through the native action.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Requester; Assigned reviewer

Review: Requester; Assigned reviewer

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-023

## 3. Before you start

- PERM-CHG-CREATE and later review grants apply.

- Affected records and proposed change are identified.

## 4. Work steps and checks

1. Open /change-requests/new and describe the change and reason.

2. List affected scientific, data, authority, security, training and operational sources.

3. Attach the supporting evidence through supported fields.

4. Save and reopen to verify DRAFT content and context.

5. Submit eligible work through the supported workflow.

6. The assigned reviewer opens the current review page and invokes START_REVIEW with expectedVersion.

7. Verify the recorded review state and preserve comments.

8. Keep RETURN/APPROVE/REJECT decisions blocked where PD-32 approval transaction authority is absent.

## 5. Decisions, errors and stop conditions

- Do not call a direct decision transition to bypass approval context.

- Change request creation is not permission to deploy or migrate.

## 6. Records and handoff

- Change request

- Impact evidence

- START_REVIEW event

- Decision blocker

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/change-requests

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /change-requests

- /change-requests/new

- /change-requests/[changeRequestId]

- /change-requests/[changeRequestId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-016 — Document, change and signature policy

Bind the decision to document number/revision, file digest, actor, role/scope, decision meaning, timestamp and authentication evidence. Preserve rejection/return reasons. Reopening creates a new review cycle without erasing the signed predecessor. A changed file invalidates the pending approval binding and requires renewed review.

Decision and exception check: Proposed separation: author cannot give their own final approval; reviewers may request corrections but may not replace raw evidence; only an approved release/distribution role may make a revision effective. Maintain current application denial for generic approval while RD-019/PD-32 are unresolved. Adopt this policy through the real owner/QMS process before implementation.

Record: QC-REC-009 review, approval and effectivity record; QC-SOP-001/011/022/023.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
