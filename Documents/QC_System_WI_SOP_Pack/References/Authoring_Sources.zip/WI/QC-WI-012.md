# QC-WI-012 — Review an inspection or lab report at stage 1

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Complete the first review stage and return or advance the exact submitted version.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Supervisor; Explicitly authorized named owner

Review: Supervisor; Explicitly authorized named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-011

## 3. Before you start

- The actor has the domain review and stage-1 approval grant.

- The submitted record and all evidence are accessible.

## 4. Work steps and checks

1. Open the relevant inspection or lab review page and identify record/version.

2. Start review through the supported action, confirming UNDER_REVIEW.

3. Check sample identity, source applicability, method, raw data, calculation and equipment evidence.

4. If work is incomplete, RETURN with a specific reason and verify RETURNED.

5. If the review is satisfactory, invoke stage-1 APPROVE under the exact authority.

6. Verify PENDING_QCM_APPROVAL and the recorded stage-1 action.

7. Do not claim a formal e-signature at stage1; this chain records a workflow approval event.

8. Hand the exact pending record to QCM for final review.

## 5. Decisions, errors and stop conditions

- MANAGER is not the normal stage-1 authority.

- Unresolved scientific criteria prevent an official approval conclusion.

## 6. Records and handoff

- Review evidence

- Return reason or stage-1 event

- QCM handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

- src/modules/laboratory/domain/lab-state.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-016 — Generic signature and document authority

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

- /approvals

- /approvals/[approvalId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-016 — Document, change and signature policy

Bind the decision to document number/revision, file digest, actor, role/scope, decision meaning, timestamp and authentication evidence. Preserve rejection/return reasons. Reopening creates a new review cycle without erasing the signed predecessor. A changed file invalidates the pending approval binding and requires renewed review.

Decision and exception check: Proposed separation: author cannot give their own final approval; reviewers may request corrections but may not replace raw evidence; only an approved release/distribution role may make a revision effective. Maintain current application denial for generic approval while RD-019/PD-32 are unresolved. Adopt this policy through the real owner/QMS process before implementation.

Record: QC-REC-009 review, approval and effectivity record; QC-SOP-001/011/022/023.

## 11. Official physical record workflow

Prepare the specific company inspection form before opening the digital template. Record the form number/revision, According to WI reference, supplier or Product Re-evaluation context, PO/date, lot, received quantity, size/type/color and inspection date. A re-evaluation without a purchase order is not an invented new receipt.

Give each selected piece a sample identity and retain its container/lot relationship. Execute every applicable printed point; record an observation or reading in Remarks and the required sample level/size. Follow the legend: acceptable, not acceptable, read remarks and not applicable are distinct. Explain NA against product design; do not copy NA from another lot.

Reconcile AQL, Code Letter, Accept, Reject, Results and Status with actual sample counts and adverse remarks. The checkmark in Accepted is part of the original record; an unresolved unfavorable remark still requires a documented review when establishing a new digital conclusion. Preserve Checked by OBM Inspectors and Reviewed by Q.C.M as the original paper roles.

Completion check: all rows and remarks are legible, sample count and subgroup totals reconcile, test references and raw readings are attached, and the review relates to the exact product/lot and form revision.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
