# QC-WI-006 — Check a missing, denied, empty or unavailable source

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Classify a source-read problem without converting it into a false empty or successful result.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Operator; Authorized support

Review: Operator; Authorized support

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-028

## 3. Before you start

- You know the page, operation, time and safe correlation identifier.

- Support has authorized access to source status.

## 4. Work steps and checks

1. Read the visible error or source-status message and retain a sanitized copy.

2. Check whether authentication ended; if so, sign in and reopen the record.

3. Distinguish validation or stale version from source access denial and provider unavailability.

4. For missing or denied protected details, accept the generic not-found response; do not probe inaccessible record identifiers.

5. For provider failure, retain the unavailable state. Do not replace the count with zero or mark the register empty.

6. Use available independent page sections only for their supported scope.

7. Ask the responsible source owner to restore access or supply the missing controlled document through the authorized path.

8. After resolution, reload and verify the source identity and current data before continuing the blocked work.

## 5. Decisions, errors and stop conditions

- Source policy missing: obtain the approved authority; retrying cannot create it.

- No source access: do not broaden grants or bypass the server guard.

## 6. Records and handoff

- Sanitized issue

- Classification

- Resolved source identity

- Continuation check

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/INCIDENT-PROBLEM-RUNBOOK.md

- src/shared/authorization/authorize.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-022 — Worker, telemetry and alerts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /help

- /404

- /500

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-022 — Outbox worker and operator alert protocol

Define the deployed worker, queue, claim/lease, retry/backoff, terminal-failure handling, scheduler and heartbeat. Record exporter destination, redaction and authorized alert receivers. Derive alert thresholds from approved service objectives and measured queue behavior. Under separate test authorization, enqueue a non-sensitive test event, track claim and attempt, obtain provider receipt and receiver acknowledgment, then prove deduplication/retry behavior.

Decision and exception check: A missing heartbeat, growing oldest-event age or terminal failure creates an incident under the approved threshold. A zero queue or no-op exporter is not proof of delivery. Retain raw timestamps and provider IDs; operator acknowledgment records who acted and when. No live message is sent by this document package.

Record: QC-REC-015 worker, telemetry and alert exercise; QC-WI-064.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
