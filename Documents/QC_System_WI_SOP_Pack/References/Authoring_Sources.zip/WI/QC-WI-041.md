# QC-WI-041 — Respond to instrument failure during a test

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Preserve incomplete data and assess affected work before retesting.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Laboratory; Equipment owner; Technical method owner

Review: Laboratory; Equipment owner; Technical method owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-012

## 3. Before you start

- The run/sample context is identifiable.

- The equipment can be safely stopped under its manual.

## 4. Work steps and checks

1. Stop the run using the approved instrument safe-stop procedure.

2. Identify the equipment, program, sample and failure time.

3. Retain raw readings, error messages, printouts and partial files.

4. Separate affected samples and material; record uncertainty rather than PASS.

5. Open maintenance and assess equipment eligibility.

6. The technical owner reviews whether earlier runs may be affected.

7. Obtain an approved invalid-run/retest decision and preserve the parent evidence.

8. Resume testing only after return-to-use and method prerequisites are demonstrated.

## 5. Decisions, errors and stop conditions

- No device manual: seek equipment specialist; this draft gives no unsafe mechanical instructions.

- Repair does not validate earlier readings.

## 6. Records and handoff

- Failure evidence

- Affected work

- Maintenance

- Retest/return-to-use decision

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/assets/equipment/infrastructure/eligibility-reader.ts

- src/modules/laboratory/application/create-retest.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /assets/maintenance

- /assets/maintenance/new

- /assets/maintenance/[maintenanceId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-026 — Invalid test, retest and rejection

Contain affected material, identify all runs since the last valid control and record the reason for invalidation or retest. The method owner approves sample selection, repeat count, conditions and the rule for combining or separately reporting results before retesting. Link the new run to the original and preserve the operator, time, equipment and source revisions.

Decision and exception check: A confirmed product failure proceeds to the authorized nonconformance/disposition process. A passing retest does not erase a failing result. Ambiguous results remain HOLD/further evaluation until reviewed. The current digital lab reject path remains policy-blocked where PD-38 authority is not established; no alternate route is proposed.

Record: QC-REC-019 invalidation and retest authorization; QC-SOP-012; QC-WI-020/042.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
