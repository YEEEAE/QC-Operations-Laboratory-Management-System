# QC-WI-045 — Make an authorized AI advisory request

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Send only approved data with fresh consent and verify the advice independently.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized advisory user

Review: Authorized advisory user

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-027

## 3. Before you start

- Provider policy, geography, retention and data classes are approved.

- Configuration is valid and explicit per-request consent is available.

## 4. Work steps and checks

1. Read policy/provider readiness on the advisory page.

2. Draft a minimal question within approved data classes.

3. Remove credentials, signatures and unapproved QC source images.

4. Review exactly what will be sent and provide request-specific consent.

5. Submit once through the supported provider boundary.

6. Record refusal, timeout or unknown outcome accurately.

7. Check the response against controlled sources and retain the human interpretation.

8. Use normal domain workflows for any resulting decision; AI cannot approve, release or write controlled results.

## 5. Decisions, errors and stop conditions

- Default-disabled or missing policy/configuration: no send.

- Changing request data requires renewed consent.

## 6. Records and handoff

- Policy reference

- Consent

- Sanitized outcome

- Human verification

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/AI-PROVIDERS.md

- src/modules/ai-advisory

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-023 — AI provider/data governance

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /ai-advisory

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-023 — AI advisory data handling

The owner and privacy/security reviewer document provider/model, geography, retention/training terms, permitted data classes, credentials custody, incident path and audit metadata. Minimize each prompt; remove personal identifiers and signatures. Actual company photos may contain names, supplier information and production details; their presence in this repository is not consent to external upload.

Decision and exception check: Each authorized request records purpose, policy version, allowed content class, consent and response correlation. Verify recommendations against the controlled sources and record the human conclusion. Deny when the policy/provider is missing, consent is absent or the data exceeds scope. Record provider failure without substituting fabricated advice.

Record: QC-REC-016 AI request assessment; QC-SOP-027; current AI-PROVIDERS source.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
