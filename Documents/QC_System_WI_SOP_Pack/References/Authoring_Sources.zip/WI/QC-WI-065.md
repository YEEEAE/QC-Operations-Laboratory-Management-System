# QC-WI-065 — Review storage and environment configuration readiness

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Verify configuration and file-storage prerequisites without exposing secrets or treating presence as proof.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized IT operator; Named owner

Review: Authorized IT operator; Named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-029

## 3. Before you start

- An approved environment and read-only inspection authority exist.

- Configuration contract and storage owner policy are available.

## 4. Work steps and checks

1. Identify environment, runtime candidate and provider scope.

2. Compare required variable names/presence with the configuration contract without printing values.

3. Keep optional R2 settings all-or-none and record whether the approved durable provider is actually configured.

4. Verify registered file upload/retrieval/digest in an authorized isolated context.

5. Record that the local adapter is memory-only; do not label it durable backup storage.

6. Check actual provider access, file/database consistency and recovery artifact availability.

7. Assess missing telemetry, AI or provider settings under their own approved policies; configuration is not owner approval.

8. Report readiness gaps and obtain explicit change/deployment authority before editing an operating environment.

## 5. Decisions, errors and stop conditions

- Never export connection strings, tokens or provider keys into evidence.

- A configured provider name does not prove retrieval or recovery.

## 6. Records and handoff

- Sanitized presence comparison

- File roundtrip

- Provider evidence

- Readiness gaps

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/CONFIGURATION-REFERENCE.md

- Documents/BACKUP-RECOVERY-PLAN.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

- DEC-021 — Recovery authority, provider and objectives

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /system/health

- /system/control-center

- /system/backups

- /system/backups/[backupId]

- /system/backups/[backupId]/restore

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

DEC-021 — Database and file recovery protocol

For each exercise, obtain explicit isolated-target authorization and the provider runbook. Record source artifact/time, database and file manifest, checksums, target identity, restore start/end and service verification times. Restore only into the approved isolated destination, check relational integrity and attachment readability, and reconcile a representative cross-domain record set before sign-off.

Decision and exception check: Measure achieved RPO as the difference between the incident/reference time and latest recoverable committed data; measure RTO from the defined interruption start to verified service recovery. Record the start/end definitions before the exercise. Compare with owner-approved objectives; no objective is inferred from a successful local copy. Production restore requires separate authority.

Record: QC-REC-014 recovery exercise; QC-WI-047/048/065.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
