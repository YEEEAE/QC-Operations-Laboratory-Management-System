# QC-WI-015 — Create a laboratory test with an approved template

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create a traceable test using the applicable source and frozen template.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Qualified lab entry operator

Review: Qualified lab entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-009

## 3. Before you start

- PERM-LAB-CREATE and source read scope apply.

- An approved applicable template and sample request exist.

## 4. Work steps and checks

1. Open /laboratory/tests/new and identify the request and source receiving item where applicable.

2. Compare product, size, lot and planned test with the request.

3. Choose the exact approved template revision; inspect its source reference and applicability.

4. Check required parameters, datatypes, units and calculation/acceptance source before proceeding.

5. Create through the supported form with the required test identity and samples.

6. Wait for confirmed creation and reopen the saved test.

7. Verify DRAFT, template/source snapshot and correct sample identifiers.

8. Plan a traceable run and equipment context before entering measurements.

## 5. Decisions, errors and stop conditions

- Template unavailable or policy-source required: stop and obtain the approved package.

- Creation does not establish scientific eligibility or a result.

## 6. Records and handoff

- Test identity

- Request and source

- Template snapshot

- Sample list

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/application/create-lab-test.ts

- src/modules/laboratory/application/list-approved-templates.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-001 — Source adoption and applicability

The technical owner prepares a product matrix by item code, size, material, connector, sterile/bulk condition and intended use. For each row, identify the current company WI, product specification and external standard where applicable. Document Control compares the controlled master with the photographed copy. A newer standard edition triggers an impact review; it does not silently replace the company method.

Decision and exception check: An applicable source package passes review when the exact revision can be retrieved, every mandatory point has a source and method, and the reviewer has resolved conflicting instructions. Preserve existing physical record outcomes as recorded. Registering them digitally does not create a new approval or retrospective release.

Record: QC-REC-001 source adoption record; company form register; clause-to-point matrix.

DEC-002 — Equipment readiness and safe operation

At the instrument, read the nameplate and record asset ID, manufacturer/model, serial, controller/software version, pressure sensor ranges, fixture identity, regulator and reference device. Match the calibration certificate to that serial and range. Attach the actual operator manual and identify its sections for connection, pressurization, isolation, emergency stop and safe venting. Record pre-use checks with a known reference and fixture/background leak check under that manual.

Decision and exception check: Stop for an unreadable label, expired or mismatched calibration, damaged connection, failed reference check or an uncontrolled program. Make the system safe using the instrument procedure; retain the failed run and identify all affected work since the last acceptable check. A maintenance completion requires a documented return-to-use check.

Record: QC-REC-002 equipment readiness and run setup; equipment/calibration/maintenance records.

DEC-005 — Point evaluation and overall result

For a valid numeric run, retain the unrounded observation and compare by the exact approved operator. For visual checks, record a concrete observation and the form legend. The physical legend distinguishes acceptable, not acceptable, read remarks and not applicable. Preserve R as a review requirement and NA with a point-specific reason; neither becomes a automatic PASS.

Decision and exception check: Proposed aggregation: all required applicable points must have valid accepted outcomes before an overall pass is proposed. Any failed required point prevents a pass; missing/invalid/conflicted evidence remains HOLD/further evaluation. A reviewer resolves contradictory remarks even when an Accepted box is ticked. Lot release is a separate disposition.

Record: QC-REC-005 acceptance-point specification and review; original per-point result and remarks.

DEC-006 — Calculation validation and discrepancy handling

For an engineering check under constant effective volume and approximately isothermal conditions, propose q = V × abs(Pstart - Pend) / elapsed time. Use Pa, cm³ and seconds consistently; kPa converts to Pa by 1000 and litres to cm³ by 1000. Document whether pressures are gauge or absolute and whether compensation, reference volume, compliance, background or standard-condition normalization applies. Validate against the actual manufacturer algorithm before official use.

Decision and exception check: Observed discrepancy for investigation: IMG-048 print shows V=2.04 cm³, 330.781 and 327.852 kPa, 20 s and an output 2981 Pa·cm³/s. The simple dimensional check gives 298.758 Pa·cm³/s. These differ by about tenfold. This is not proof of an incorrect machine; printed volume/time semantics or internal scaling may differ. Require an explanation and validation dataset.

Record: QC-REC-006 calculation validation: raw readings, units, formula/version, instrument output, independent result, difference and reviewer disposition.

DEC-026 — Invalid test, retest and rejection

Contain affected material, identify all runs since the last valid control and record the reason for invalidation or retest. The method owner approves sample selection, repeat count, conditions and the rule for combining or separately reporting results before retesting. Link the new run to the original and preserve the operator, time, equipment and source revisions.

Decision and exception check: A confirmed product failure proceeds to the authorized nonconformance/disposition process. A passing retest does not erase a failing result. Ambiguous results remain HOLD/further evaluation until reviewed. The current digital lab reject path remains policy-blocked where PD-38 authority is not established; no alternate route is proposed.

Record: QC-REC-019 invalidation and retest authorization; QC-SOP-012; QC-WI-020/042.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
