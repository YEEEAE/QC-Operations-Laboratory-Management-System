# QC-WI-028 — Record and review root-cause analysis

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Develop a cause conclusion supported by evidence, not a completed diagram alone.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Quality investigator; Technical reviewer

Review: Quality investigator; Technical reviewer

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-018

## 3. Before you start

- The NCR and relevant process evidence exist.

- The quality policy and RCA action authority apply.

## 4. Work steps and checks

1. Open the linked RCA/NCR context and define the problem precisely.

2. Collect timing, equipment, process, material and operator evidence relevant to the concern.

3. List plausible causal explanations and what evidence would discriminate them.

4. Use the approved analysis technique and record actual findings.

5. Retain rejected hypotheses and their reasons where material to the conclusion.

6. Link the supported cause to proposed corrective/preventive actions.

7. Save and reload the RCA content/version.

8. Submit to the authorized reviewer and hand the supported conclusion to CAPA planning.

## 5. Decisions, errors and stop conditions

- Insufficient evidence: retain an unresolved hypothesis.

- Do not mark cause confirmed because an action was assigned.

## 6. Records and handoff

- RCA evidence

- Hypothesis assessment

- Supported conclusion

- CAPA handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/rca/domain/rca.ts

- Documents/QUALITY-POLICY-DECISION-PACK-2026-10-02.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/rca

- /quality/rca/[rcaId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-018 — Finding to CAPA lifecycle

At NCR creation, link the finding, source requirement, product/lot/process, immediate containment, risk assessment and owner. At RCA review, distinguish verified causes from hypotheses and include evidence that could disprove the cause. At CAPA planning, assign each action, due date, completion evidence, verifier and effectiveness measure with a justified observation period.

Decision and exception check: An action marked complete is not proof of effectiveness. Record the planned versus actual observation window and denominator of opportunities or recurrence. Preserve the source P-04 exceptional Supervisor closure with its reason, reauthentication/signature and residual-risk follow-up; do not label incomplete or ineffective work effective merely because closure is permitted.

Record: QC-REC-011 quality investigation and effectiveness record; QC-SOP-017/018.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
