# QC-WI-021 — Transcribe a Pressure Decay or Subatmospheric form

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create a checked report draft from a legible original without creating an approved result.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator

Review: QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-013

## 3. Before you start

- Original image/form and form-register identity are available.

- The lab report-draft permission and scope apply.

## 4. Work steps and checks

1. Select the matching form at /laboratory/report-templates.

2. Record the source image ID, company form number and revision in the form/evidence register.

3. Compare the original identification, equipment, assembly, environment and result sections.

4. Transcribe rows exactly, preserving printed unit names and flagging unclear readings.

5. Keep historical PASS/FAIL/HOLD and Tested/Reviewed/Approved By values as transcription text.

6. Save once, reopen and compare all fields with the original.

7. Use the draft print only as a convenience copy; no signature or test evaluation is created.

8. If controlled testing is needed, create a separate approved-source laboratory test under QC-WI-015.

## 5. Decisions, errors and stop conditions

- Conflicting form revisions: seek Document Control disposition.

- Fixed twelve-row layout is not a scientific sample plan.

## 6. Records and handoff

- Report draft

- Original image ID/hash

- Form number/revision

- Transcription check

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/LABORATORY-REPORT-TEMPLATES.md

- src/modules/laboratory/application/report-drafts.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-004 — Leak-form revision and unit conflict

- DEC-028 — Source description conflicts

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /laboratory/report-templates

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-004 — Leakage form revision reconciliation

Create a comparison of pressure direction/basis, set pressure, actual pressure, assembly force, torque unit, assembly time, angle, temperature, humidity, effective volume, measurement time and leakage unit. Record the newest form as the proposed current candidate only after Document Control confirms its distribution status. Resolve the printed N/m versus N·m label and the printout label showing seconds beside a pressure-difference symbol through the method/instrument owner.

Decision and exception check: A form may be transcribed while its uncertain labels are retained verbatim and flagged. New testing needs a coherent approved source. The 2026 forms print a leakage limit below 5000 Pa·cm³/s, whereas the older form prints a different value; the revision number alone does not prove equivalence or authorize conversion.

Record: QC-REC-004 method and form reconciliation; images IMG-040, IMG-048 and IMG-070.

DEC-028 — Source description reconciliation

For each form, preserve company number, revision, printed date, image ID/hash, observed fields and workflow context. For a conflicting narrative, state the observed evidence and the newer authority source. Distinguish paper availability from digital template integration, and historical signer evidence from a new digital signature.

Decision and exception check: Closure rule for the source-availability description: all 84 files are indexed, readable derivatives exist, and the official physical-use attestation is recorded. Remaining incomplete form suffixes and scientific/effectivity conflicts remain with their specific decisions. Do not mark those technically resolved by the general attestation.

Record: Official_Physical_Records_Basis.pdf; form-register.pdf; image-register.pdf; user attestation 2026-10-04.

## 11. Official physical record workflow

Use a separate run row for each sample/replicate. Record connector type, sample count, lot and sampling area, then equipment identity/medium, assembly force, torque, time and angle. Record actual temperature and humidity in the environmental block; an empty block remains missing information.

Enter set pressure (sp), applied pressure (tp), volume (v), pressure difference, holding time and instrument leakage result in their printed units. Retain the printer ticket with serial/run identifier and timestamp. Match each ticket to its sample row; do not assume the top ticket describes every row underneath. Distinguish setpoint from achieved pressure.

F-8-2-6-05 Rev04 prints 300–330 kPa, 15–20 s and <5000 Pa·cm³/s. F-8-2-6-07 Rev4 prints −80 to −88 kPa with the same time/limit. These are observed company-form values; adoption for a product requires the form/method reconciliation in DEC-004. A pressure outside the source range or a failed stability check needs investigation even if reported leakage is below the limit.

Mark the run outcome only after validity and criterion checks. Complete the overall PASS, FAIL or HOLD/FURTHER EVALUATION block separately from individual rows. Retain Tested by, Reviewed by and Approved by sections with actual identities/dates; do not fill a blank historical signature. Attach an investigation when independent calculation and printer output disagree.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
