# QC-WI-027 — Create an NCR linked to persisted evidence

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create an NCR from a qualifying finding without substituting caller assertions for prerequisites.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized QC entry operator; Quality owner

Review: Authorized QC entry operator; Quality owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-017

## 3. Before you start

- The related Finding exists and is accessible.

- PERM-NCR-CREATE, scope and persisted prerequisites apply.

## 4. Work steps and checks

1. Open the source Finding and verify its evidence and affected scope.

2. Check the approved prerequisite and classification rules.

3. Open the supported NCR creation entry and select the actual predecessor.

4. Enter the nonconformance description, required owner/context and evidence.

5. Do not supply an arbitrary prerequisite flag as proof of completion.

6. Save and reopen the NCR to verify its persisted Finding link.

7. Assign containment/investigation under the approved policy.

8. Hand the NCR to the causal-analysis owner when that step is required.

## 5. Decisions, errors and stop conditions

- Unavailable prerequisite source: deny advancement.

- Proposed October quality policy is not an approved classification rule.

## 6. Records and handoff

- NCR

- Persisted Finding relationship

- Containment and investigation handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/ncr/domain/ncr.ts

- Documents/QUALITY-POLICY-DECISION-PACK-2026-10-02.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/ncr

- /quality/ncr/new

- /quality/ncr/[ncrId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-018 — Finding to CAPA lifecycle

At NCR creation, link the finding, source requirement, product/lot/process, immediate containment, risk assessment and owner. At RCA review, distinguish verified causes from hypotheses and include evidence that could disprove the cause. At CAPA planning, assign each action, due date, completion evidence, verifier and effectiveness measure with a justified observation period.

Decision and exception check: An action marked complete is not proof of effectiveness. Record the planned versus actual observation window and denominator of opportunities or recurrence. Preserve the source P-04 exceptional Supervisor closure with its reason, reauthentication/signature and residual-risk follow-up; do not label incomplete or ineffective work effective merely because closure is permitted.

Record: QC-REC-011 quality investigation and effectiveness record; QC-SOP-017/018.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
