# QC-WI-053 — Syringes — inspection and test review proposal

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Prepare an applicable inspection/test plan for syringes and execute it only after technical approval.

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

## 2. Responsibilities and review

Responsible specialists: Syringe product specialist; QC/QMS

Review: Syringe product specialist; QC/QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-008

## 3. Before you start

- DEC-008, DEC-001, DEC-003 and DEC-005 are resolved before controlled acceptance.

- Effective product drawing, licensed applicable method and sample plan are present.

- Qualified operator and suitable calibrated equipment are available.

## 4. Work steps and checks

1. Identify the product code, model, size, lot, supplier/manufacturing context and sterile/bulk status.

2. Confirm whether the device is an empty sterile manual-use hypodermic syringe. ISO 7886-1:2017 is a design-test candidate, excludes several syringe types and does not itself establish lot-release requirements.

3. Compare the supplied company inspection form with the effective product drawing and resolve revision differences.

4. Check type (LL/LT/catheter tip/side nozzle where applicable), graduation, barrel, piston, nozzle, wings and physical defects against the actual model drawing.

5. Propose delivered-volume, plunger operation, leakage during aspiration, liquid leakage and dead-space checks for method-owner assessment.

6. For a Luer connector, assess ISO 80369-7 applicability and use the separately approved leakage WI. Do not use a connector test as a complete syringe test.

7. Treat printed pH 5.0–6.0 and ±5%/±4% accuracy values as form observations requiring technical-source confirmation, not approved universal limits.

8. Select and label samples using the approved plan. Record actual per-point sample count rather than inferring it from form layout.

9. Record each observation and raw measurement with sample, unit, equipment, method revision and remarks. Keep printed/historical form values separate from approved criteria.

10. Evaluate under approved point and overall decision rules; hold uncertain work and retain failures.

11. Submit the exact record for Supervisor and QCM review; a reviewed test is not a receiving release.

## 5. Decisions, errors and stop conditions

- Missing drawing, intended-use mapping, method clause or limit: do not execute controlled acceptance.

- A handwritten tick, N/A or Accepted mark is historical evidence, not authority for a new test.

- Failed or invalid work: retain raw evidence and obtain containment/retest disposition.

## 6. Records and handoff

- Product applicability decision

- Approved point/test plan

- Sample log

- Raw evidence

- Reviewed inspection

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- FORM-007

- EXT-003

- EXT-002

- QC-SOP-007

- QC-SOP-008

- QC-SOP-009

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-003 — Sampling plan

- DEC-005 — Per-point and overall evaluation

- DEC-008 — Syringe variant and method

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quarantine/inspections

- /quarantine/inspections/[inspectionId]

- /quarantine/inspections/[inspectionId]/execute

- /quarantine/inspections/[inspectionId]/review

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-001 — Source adoption and applicability

The technical owner prepares a product matrix by item code, size, material, connector, sterile/bulk condition and intended use. For each row, identify the current company WI, product specification and external standard where applicable. Document Control compares the controlled master with the photographed copy. A newer standard edition triggers an impact review; it does not silently replace the company method.

Decision and exception check: An applicable source package passes review when the exact revision can be retrieved, every mandatory point has a source and method, and the reviewer has resolved conflicting instructions. Preserve existing physical record outcomes as recorded. Registering them digitally does not create a new approval or retrospective release.

Record: QC-REC-001 source adoption record; company form register; clause-to-point matrix.

DEC-003 — Lot definition and sampling

The QC planner selects the approved sampling procedure and records edition, lot quantity, normal/tightened/reduced status, inspection level, defect classes, AQL or alternative rationale, code letter, sample size and Ac/Re. Select across containers or production positions using the documented random/systematic method. Allocate destructive and non-destructive samples separately and prevent replacement of an unfavorable sample without an investigation.

Decision and exception check: Compare total samples actually tested with the plan and reconcile extra runs, repeats and retained samples. The supplied feeding-tube record has a Sample Size entry and a different checked-quantity remark; reconcile that difference before using its plan as a precedent. A re-evaluation of a few retained items does not become acceptance of a new incoming lot.

Record: QC-REC-003 sampling and custody plan; per-sample identifiers; original AQL/code/Ac/Re block.

DEC-005 — Point evaluation and overall result

For a valid numeric run, retain the unrounded observation and compare by the exact approved operator. For visual checks, record a concrete observation and the form legend. The physical legend distinguishes acceptable, not acceptable, read remarks and not applicable. Preserve R as a review requirement and NA with a point-specific reason; neither becomes a automatic PASS.

Decision and exception check: Proposed aggregation: all required applicable points must have valid accepted outcomes before an overall pass is proposed. Any failed required point prevents a pass; missing/invalid/conflicted evidence remains HOLD/further evaluation. A reviewer resolves contradictory remarks even when an Accepted box is ticked. Lot release is a separate disposition.

Record: QC-REC-005 acceptance-point specification and review; original per-point result and remarks.

DEC-008 — Syringe variants and volume verification

Complete the 17 inspection points in the printed sequence. Inspect scale, piston, nozzle and barrel/wings before clinical-fit, liquid, aspiration and spillage tests. Record lubrication and sterile/bulk presentation. Preserve the original pH requirement of 5.0–6.0 and the printed accuracy bands as observed company-source text; attach the source method before executing or validating those tests.

Decision and exception check: For volume verification, identify the calibrated reference cylinder, certificate, nominal test point, reference reading, observed syringe reading and error direction. Define the approved percentage-error denominator and rounding rule before evaluation. A diagonal strike across rows or a handwritten NA must be explained per point; it is not a validated exclusion for another lot.

Record: QC-WI-053; FORM-007; IMG-014/025; QC-REC-005/007.

## 11. Official physical record workflow

Prepare the specific company inspection form before opening the digital template. Record the form number/revision, According to WI reference, supplier or Product Re-evaluation context, PO/date, lot, received quantity, size/type/color and inspection date. A re-evaluation without a purchase order is not an invented new receipt.

Give each selected piece a sample identity and retain its container/lot relationship. Execute every applicable printed point; record an observation or reading in Remarks and the required sample level/size. Follow the legend: acceptable, not acceptable, read remarks and not applicable are distinct. Explain NA against product design; do not copy NA from another lot.

Reconcile AQL, Code Letter, Accept, Reject, Results and Status with actual sample counts and adverse remarks. The checkmark in Accepted is part of the original record; an unresolved unfavorable remark still requires a documented review when establishing a new digital conclusion. Preserve Checked by OBM Inspectors and Reviewed by Q.C.M as the original paper roles.

Completion check: all rows and remarks are legible, sample count and subgroup totals reconcile, test references and raw readings are attached, and the review relates to the exact product/lot and form revision.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
