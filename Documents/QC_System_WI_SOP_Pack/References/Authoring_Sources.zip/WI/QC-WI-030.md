# QC-WI-030 — Verify effectiveness and record controlled CAPA closure

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Preserve the difference between implemented action, effectiveness and exceptional closure.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized verifier; Supervisor close actor

Review: Authorized verifier; Supervisor close actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-018

## 3. Before you start

- Persisted action and verification evidence exist.

- Closure permission, reason, reauthentication and signature requirements are satisfied.

## 4. Work steps and checks

1. Review action completion against the agreed evidence.

2. Verify implementation before beginning effectiveness assessment.

3. Apply the pre-approved effectiveness method and observation window.

4. Record the actual effectiveness outcome and remaining actions.

5. Advance through supported verification/effectiveness states when persisted prerequisites pass.

6. If P-04 exceptional closure is authorized, state incomplete or ineffective work in the reason.

7. Complete the required Supervisor reauthentication/e-signature ceremony for CLOSE.

8. Reload CLOSED and preserve the effectiveness result and residual follow-up; closure does not certify success.

## 5. Decisions, errors and stop conditions

- QC entry users cannot close.

- No effectiveness evidence: do not claim effectiveness even if exceptional closure is permitted.

## 6. Records and handoff

- Verification

- Effectiveness assessment

- Closure reason/signature

- Residual obligations

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/capa/domain/capa.ts

- Documents/DECISION-ASSUMPTION-REGISTER-026.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

- /quality/capa

- /quality/capa/new

- /quality/capa/[capaId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-018 — Finding to CAPA lifecycle

At NCR creation, link the finding, source requirement, product/lot/process, immediate containment, risk assessment and owner. At RCA review, distinguish verified causes from hypotheses and include evidence that could disprove the cause. At CAPA planning, assign each action, due date, completion evidence, verifier and effectiveness measure with a justified observation period.

Decision and exception check: An action marked complete is not proof of effectiveness. Record the planned versus actual observation window and denominator of opportunities or recurrence. Preserve the source P-04 exceptional Supervisor closure with its reason, reauthentication/signature and residual-risk follow-up; do not label incomplete or ineffective work effective merely because closure is permitted.

Record: QC-REC-011 quality investigation and effectiveness record; QC-SOP-017/018.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
