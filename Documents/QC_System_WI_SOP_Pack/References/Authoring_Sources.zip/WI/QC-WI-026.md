# QC-WI-026 — Create a factual Finding

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Capture an observable concern with traceable evidence and containment context.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator

Review: QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-017

## 3. Before you start

- Evidence and affected product/process are identifiable.

- PERM-FIND-CREATE and scope apply.

## 4. Work steps and checks

1. Describe what was observed, where and when.

2. Separate the observed fact from a suspected cause.

3. Open /quality/findings/new and enter a clear title and description.

4. Include affected lot/record references and supporting evidence through supported fields.

5. Record immediate containment in the approved operational record.

6. Save and reopen to verify identity and evidence links.

7. Use supported submission/review actions only when their prerequisites pass.

8. Hand the finding to the quality owner for classification and NCR decision.

## 5. Decisions, errors and stop conditions

- Unknown affected scope: record it explicitly and investigate.

- Creation does not grant closure authority.

## 6. Records and handoff

- Finding

- Evidence

- Containment scope

- Quality-owner handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quality/findings/domain/finding.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-018 — Quality prerequisites and effectiveness

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quality

- /quality/findings

- /quality/findings/new

- /quality/findings/[findingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-018 — Finding to CAPA lifecycle

At NCR creation, link the finding, source requirement, product/lot/process, immediate containment, risk assessment and owner. At RCA review, distinguish verified causes from hypotheses and include evidence that could disprove the cause. At CAPA planning, assign each action, due date, completion evidence, verifier and effectiveness measure with a justified observation period.

Decision and exception check: An action marked complete is not proof of effectiveness. Record the planned versus actual observation window and denominator of opportunities or recurrence. Preserve the source P-04 exceptional Supervisor closure with its reason, reauthentication/signature and residual-risk follow-up; do not label incomplete or ineffective work effective merely because closure is permitted.

Record: QC-REC-011 quality investigation and effectiveness record; QC-SOP-017/018.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
