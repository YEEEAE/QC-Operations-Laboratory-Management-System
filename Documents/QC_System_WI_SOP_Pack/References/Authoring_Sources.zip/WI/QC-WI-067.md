# QC-WI-067 — Review release evidence intake and the nineteen gates

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Verify evidence provenance, candidate binding and gate applicability before release approval.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Named owner; Authorized release reviewer; Trusted evidence provider

Review: Named owner; Authorized release reviewer; Trusted evidence provider

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-030

## 3. Before you start

- The nineteen-gate registry and trusted provider authority are approved.

- Current runtime/build identity and candidate evidence exist.

## 4. Work steps and checks

1. Open /governance/releases/[releaseId] and identify the release/candidate context.

2. Read each canonical gate and its required owner/provider evidence.

3. Check provider identity, attestation payload, candidate binding, freshness and supported signature verification.

4. Verify nonce/replay handling; a repeated provider attestation must not be accepted as new evidence.

5. Distinguish unavailable evidence source from no evidence and denied access.

6. Compare runtime identity, applied migration ledger and artifact digest with the candidate.

7. Keep unresolved gates and authority sources explicit; do not use this documentation pack as test evidence.

8. Approve only through the authorized release workflow after all required gates pass; otherwise retain NO-GO.

## 5. Decisions, errors and stop conditions

- Trusted intake connectivity is not gate acceptance.

- Historical evidence from another SHA/dirty tree must be rebound or rerun.

## 6. Records and handoff

- Gate register

- Trusted attestation

- Runtime/schema identity

- Release decision

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/release-governance

- Documents/RELEASE-RUNBOOK.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-024 — Release gates, applicability and human acceptance

- DEC-025 — Performance budgets and representative environment

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /governance/releases/[releaseId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-024 — Release and human UAT evidence

Freeze source SHA, dirty fingerprint, build/runtime identity and migration state. Define real UAT roles and scenarios, including receiving, inspection/lab review, denial, stale version, uncertain submission, reports and recovery intent. Participants execute with their own authorized accounts and record observed outcome, evidence and defects. Preserve failed and blocked cases.

Decision and exception check: A verification lead checks candidate binding and unresolved defects; the authorized acceptor signs only real participant evidence. A source test, authored script or planned scenario cannot be substituted for the session. If the candidate changes, assess affected evidence and rebind/rerun as required. Gate PASS does not itself execute release or deployment.

Record: QC-REC-017 release gate and UAT session; QC-SOP-030; route-coverage register.

DEC-025 — Performance measurement contract

Capture request/query counts, payload size and the relevant timing metric with clock/method details. For p95, retain all raw samples, sample count and percentile method; do not report a percentile from one observation. Compare before/after with equivalent data and conditions. Include errors and timeouts in the stated analysis rather than silently dropping them.

Decision and exception check: For interactive pages, define the measured user interaction and tooling; page load time is not INP. Record server and browser segments separately. If a budget is absent, report measured values and request the acceptance decision without claiming a pass. A local loopback benchmark does not establish provider latency.

Record: QC-REC-018 performance plan and measurements; QC-WI-061.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
