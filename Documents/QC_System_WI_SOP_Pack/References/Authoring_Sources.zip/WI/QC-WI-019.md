# QC-WI-019 — Check a calculated result before review

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Independently check calculation inputs, units and approved rule version.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Technical reviewer; Laboratory

Review: Technical reviewer; Laboratory

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-010

## 3. Before you start

- The raw replicates and approved calculation rule are present.

- The rule defines rounding, precision and evaluation.

## 4. Work steps and checks

1. Read the rule identity, revision and source applicability.

2. Locate every raw input and verify sample/run association.

3. Confirm units and distinguish throughput from volumetric leakage; do not treat Pa·cm³/s as cm³/s.

4. For a proposed q = V × abs(ΔP)/Δt check, use cm³, Pa and seconds and record the stable-volume/isothermal assumptions.

5. Compare the rule with the actual instrument algorithm and effective fixture volume; this draft does not substitute for the device manual.

6. Recalculate without premature rounding and retain the check inputs.

7. Compare the result with the stored calculatedValue, calculatedUnit and calculationRuleReference/version.

8. Report disagreement for technical investigation before evaluation or approval.

## 5. Decisions, errors and stop conditions

- Unapproved equation or incompatible units: retain raw data and stop calculation approval.

- A mathematically correct number does not establish an approved acceptance limit.

## 6. Records and handoff

- Rule/version

- Inputs and unit check

- Independent calculation

- Discrepancy

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/domain/measurement.ts

- EXT-009

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-006 — Leak calculation validation

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-006 — Calculation validation and discrepancy handling

For an engineering check under constant effective volume and approximately isothermal conditions, propose q = V × abs(Pstart - Pend) / elapsed time. Use Pa, cm³ and seconds consistently; kPa converts to Pa by 1000 and litres to cm³ by 1000. Document whether pressures are gauge or absolute and whether compensation, reference volume, compliance, background or standard-condition normalization applies. Validate against the actual manufacturer algorithm before official use.

Decision and exception check: Observed discrepancy for investigation: IMG-048 print shows V=2.04 cm³, 330.781 and 327.852 kPa, 20 s and an output 2981 Pa·cm³/s. The simple dimensional check gives 298.758 Pa·cm³/s. These differ by about tenfold. This is not proof of an incorrect machine; printed volume/time semantics or internal scaling may differ. Require an explanation and validation dataset.

Record: QC-REC-006 calculation validation: raw readings, units, formula/version, instrument output, independent result, difference and reviewer disposition.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

## 11. Official physical record workflow

Use a separate run row for each sample/replicate. Record connector type, sample count, lot and sampling area, then equipment identity/medium, assembly force, torque, time and angle. Record actual temperature and humidity in the environmental block; an empty block remains missing information.

Enter set pressure (sp), applied pressure (tp), volume (v), pressure difference, holding time and instrument leakage result in their printed units. Retain the printer ticket with serial/run identifier and timestamp. Match each ticket to its sample row; do not assume the top ticket describes every row underneath. Distinguish setpoint from achieved pressure.

F-8-2-6-05 Rev04 prints 300–330 kPa, 15–20 s and <5000 Pa·cm³/s. F-8-2-6-07 Rev4 prints −80 to −88 kPa with the same time/limit. These are observed company-form values; adoption for a product requires the form/method reconciliation in DEC-004. A pressure outside the source range or a failed stability check needs investigation even if reported leakage is below the limit.

Mark the run outcome only after validity and criterion checks. Complete the overall PASS, FAIL or HOLD/FURTHER EVALUATION block separately from individual rows. Retain Tested by, Reviewed by and Approved by sections with actual identities/dates; do not fill a blank historical signature. Attach an investigation when independent calculation and printer output disagree.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
