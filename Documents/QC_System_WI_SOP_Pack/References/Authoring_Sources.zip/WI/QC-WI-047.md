# QC-WI-047 — Create and verify a PLANNED restore intent

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Persist a restore request without claiming execution.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Explicitly authorized drill actor; Named owner

Review: Explicitly authorized drill actor; Named owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-029

## 3. Before you start

- Explicit drill permission and GLOBAL scope apply.

- The backup is eligible and current snapshot/version are loaded.

- A meaningful reason and isolated intent target exist.

## 4. Work steps and checks

1. Open /system/backups and inspect the selected backup evidence.

2. Read its eligibility, version and restrictions.

3. Open the supported restore-intent form and enter the reason.

4. Keep the per-form eligibility digest and stable idempotency key unchanged for the same request.

5. Submit once with the opened backup context.

6. If uncertain, resolve the saved intent/replay before another request.

7. Reload the intent and verify PLANNED, reason and audit/outbox relationship.

8. Hand execution to an explicitly authorized recovery operator; this system currently provides no restore executor.

## 5. Decisions, errors and stop conditions

- Stale eligibility or denied scope: stop.

- PLANNED does not mean RESTORED, and no production restore is authorized.

## 6. Records and handoff

- Backup snapshot

- Stable request identity

- PLANNED intent

- Recovery handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/backup-recovery

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-020 — Retention, file safety and record storage

- DEC-021 — Recovery authority, provider and objectives

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /system/backups

- /system/backups/[backupId]

- /system/backups/[backupId]/restore

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

DEC-021 — Database and file recovery protocol

For each exercise, obtain explicit isolated-target authorization and the provider runbook. Record source artifact/time, database and file manifest, checksums, target identity, restore start/end and service verification times. Restore only into the approved isolated destination, check relational integrity and attachment readability, and reconcile a representative cross-domain record set before sign-off.

Decision and exception check: Measure achieved RPO as the difference between the incident/reference time and latest recoverable committed data; measure RTO from the defined interruption start to verified service recovery. Record the start/end definitions before the exercise. Compare with owner-approved objectives; no objective is inferred from a successful local copy. Production restore requires separate authority.

Record: QC-REC-014 recovery exercise; QC-WI-047/048/065.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
