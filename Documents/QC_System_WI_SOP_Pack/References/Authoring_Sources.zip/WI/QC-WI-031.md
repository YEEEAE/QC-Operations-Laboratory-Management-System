# QC-WI-031 — Assign, complete and hand over a task

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Track a concrete deliverable and its handoff.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Task creator; Assignee

Review: Task creator; Assignee

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-019

## 3. Before you start

- The required output and related QC record are known.

- Task grants and scope apply.

## 4. Work steps and checks

1. Open /tasks/new and write a specific task title and deliverable.

2. Assign the responsible person and supported due/context fields.

3. Link the relevant controlled record in its supported context.

4. Save and verify the assignee and task version.

5. The assignee starts work only after checking prerequisites.

6. Record progress, blockers and output evidence.

7. Use the supported completion action after the deliverable exists.

8. Hand the output to its recipient; use the domain approval workflow separately.

## 5. Decisions, errors and stop conditions

- No required source: keep work blocked.

- Task complete is not product released or report approved.

## 6. Records and handoff

- Task

- Assignment

- Output

- Handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/tasks/domain/state.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /tasks

- /tasks/new

- /tasks/[taskId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-019 — Training, custody and movement

The assessor observes identity checks, correct source selection, a normal task, a deliberate exception, raw-data recording and safe handoff. Record each result and restriction. Reassess following a significant method/equipment change, an observed competence failure or the approved review schedule. Training attendance alone is insufficient.

Decision and exception check: For custody, record sample ID, parent lot, selection time, selector, quantity, condition, container/seal and every transfer with both parties and time. For movement, reconcile opening quantity, received/transferred, tested/destroyed, reworked, scrapped and closing balance in one unit. Discrepancies stop handoff until explained; maintain quarantine identity through transport.

Record: QC-REC-003, QC-REC-010 movement, QC-REC-012 competency; QC-SOP-002/007/016.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
