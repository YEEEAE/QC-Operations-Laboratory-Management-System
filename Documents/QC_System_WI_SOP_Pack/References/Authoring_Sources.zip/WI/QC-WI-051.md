# QC-WI-051 — Subatmospheric Pressure Air Leakage — technical review proposal

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Develop and execute, after approval, a vacuum leakage method for the exact connector application.

Implementation: SCIENTIFIC PROPOSAL — NOT AUTHORIZED FOR CONTROLLED ACCEPTANCE

## 2. Responsibilities and review

Responsible specialists: Leak-test specialist; Metrology; QC/QMS

Review: Leak-test specialist; Metrology; QC/QMS

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-009

## 3. Before you start

- DEC-001 to DEC-006 and form-revision reconciliation are approved.

- The actual instrument manual, vacuum fixture and reference checks are available.

- The approved product-specific method and sample plan exist.

## 4. Work steps and checks

1. Identify connector type, product, lot and sample units and confirm the applicable application standard.

2. Compare the intended vacuum method with the licensed ISO 80369-20:2024 clauses and applicable connector standard; catalog scope is not a validated operating recipe.

3. Select eligible calibrated equipment and inspect tubing/fixture/reference connector. Verify the approved vacuum safety and safe-release instructions.

4. Assemble the connector pair with the approved force, torque, time and angle. Record the actual values and resolve N·m versus N/m before testing.

5. Condition and record environment, then confirm gauge/absolute basis, effective volume, target vacuum, stabilization and holding time from the approved method.

6. Apply vacuum using the actual device procedure, isolate, stabilize and acquire the pressure rise or leak output. Do not call it positive-pressure decay or reverse the sign without the method’s convention.

7. Retain set and applied pressure, volume, pressure difference, holding time, throughput, sample identity and instrument raw file/print.

8. For review only, check q = V × abs(ΔP)/Δt in Pa·cm³/s under stable-volume/isothermal assumptions. Preserve the actual instrument calculation and investigate compensation or unit differences.

9. Evaluate only under approved per-sample criteria and aggregation. Keep invalid runs and any HOLD/further-evaluation conclusion explicit.

10. Reconcile original form revision, raw evidence and digital test/run before submitting for review. Historical report transcription remains a separate draft workflow.

## 5. Decisions, errors and stop conditions

- F-8-2-6-07 Rev4 prints −80 to −88 kPa, 15–20 s and <5000 Pa·cm³/s; FR-MA-018 Rev06 prints different values/units, including <0.010 Pa·cm³/s. Neither is adopted by this draft.

- FR-MA-018 also contains ambiguous/typo labels and volume in litres while other forms use cm³. Document Control and the method specialist must resolve these conflicts before use.

- Vacuum instability, failed blank/reference or leaking fixture: stop and preserve the run for investigation.

## 6. Records and handoff

- Approved method

- Form-revision disposition

- Assembly/environment/vacuum settings

- Raw evidence

- Unit/calculation check

- Review chain

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- EXT-001

- EXT-002

- EXT-009

- FORM-004

- FORM-005

- QC-SOP-009

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-001 — Scientific source and applicability

- DEC-002 — Leak-test equipment manual and safety

- DEC-003 — Sampling plan

- DEC-004 — Leak-form revision and unit conflict

- DEC-005 — Per-point and overall evaluation

- DEC-006 — Leak calculation validation

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/report-templates

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-001 — Source adoption and applicability

The technical owner prepares a product matrix by item code, size, material, connector, sterile/bulk condition and intended use. For each row, identify the current company WI, product specification and external standard where applicable. Document Control compares the controlled master with the photographed copy. A newer standard edition triggers an impact review; it does not silently replace the company method.

Decision and exception check: An applicable source package passes review when the exact revision can be retrieved, every mandatory point has a source and method, and the reviewer has resolved conflicting instructions. Preserve existing physical record outcomes as recorded. Registering them digitally does not create a new approval or retrospective release.

Record: QC-REC-001 source adoption record; company form register; clause-to-point matrix.

DEC-002 — Equipment readiness and safe operation

At the instrument, read the nameplate and record asset ID, manufacturer/model, serial, controller/software version, pressure sensor ranges, fixture identity, regulator and reference device. Match the calibration certificate to that serial and range. Attach the actual operator manual and identify its sections for connection, pressurization, isolation, emergency stop and safe venting. Record pre-use checks with a known reference and fixture/background leak check under that manual.

Decision and exception check: Stop for an unreadable label, expired or mismatched calibration, damaged connection, failed reference check or an uncontrolled program. Make the system safe using the instrument procedure; retain the failed run and identify all affected work since the last acceptable check. A maintenance completion requires a documented return-to-use check.

Record: QC-REC-002 equipment readiness and run setup; equipment/calibration/maintenance records.

DEC-003 — Lot definition and sampling

The QC planner selects the approved sampling procedure and records edition, lot quantity, normal/tightened/reduced status, inspection level, defect classes, AQL or alternative rationale, code letter, sample size and Ac/Re. Select across containers or production positions using the documented random/systematic method. Allocate destructive and non-destructive samples separately and prevent replacement of an unfavorable sample without an investigation.

Decision and exception check: Compare total samples actually tested with the plan and reconcile extra runs, repeats and retained samples. The supplied feeding-tube record has a Sample Size entry and a different checked-quantity remark; reconcile that difference before using its plan as a precedent. A re-evaluation of a few retained items does not become acceptance of a new incoming lot.

Record: QC-REC-003 sampling and custody plan; per-sample identifiers; original AQL/code/Ac/Re block.

DEC-004 — Leakage form revision reconciliation

Create a comparison of pressure direction/basis, set pressure, actual pressure, assembly force, torque unit, assembly time, angle, temperature, humidity, effective volume, measurement time and leakage unit. Record the newest form as the proposed current candidate only after Document Control confirms its distribution status. Resolve the printed N/m versus N·m label and the printout label showing seconds beside a pressure-difference symbol through the method/instrument owner.

Decision and exception check: A form may be transcribed while its uncertain labels are retained verbatim and flagged. New testing needs a coherent approved source. The 2026 forms print a leakage limit below 5000 Pa·cm³/s, whereas the older form prints a different value; the revision number alone does not prove equivalence or authorize conversion.

Record: QC-REC-004 method and form reconciliation; images IMG-040, IMG-048 and IMG-070.

DEC-005 — Point evaluation and overall result

For a valid numeric run, retain the unrounded observation and compare by the exact approved operator. For visual checks, record a concrete observation and the form legend. The physical legend distinguishes acceptable, not acceptable, read remarks and not applicable. Preserve R as a review requirement and NA with a point-specific reason; neither becomes a automatic PASS.

Decision and exception check: Proposed aggregation: all required applicable points must have valid accepted outcomes before an overall pass is proposed. Any failed required point prevents a pass; missing/invalid/conflicted evidence remains HOLD/further evaluation. A reviewer resolves contradictory remarks even when an Accepted box is ticked. Lot release is a separate disposition.

Record: QC-REC-005 acceptance-point specification and review; original per-point result and remarks.

DEC-006 — Calculation validation and discrepancy handling

For an engineering check under constant effective volume and approximately isothermal conditions, propose q = V × abs(Pstart - Pend) / elapsed time. Use Pa, cm³ and seconds consistently; kPa converts to Pa by 1000 and litres to cm³ by 1000. Document whether pressures are gauge or absolute and whether compensation, reference volume, compliance, background or standard-condition normalization applies. Validate against the actual manufacturer algorithm before official use.

Decision and exception check: Observed discrepancy for investigation: IMG-048 print shows V=2.04 cm³, 330.781 and 327.852 kPa, 20 s and an output 2981 Pa·cm³/s. The simple dimensional check gives 298.758 Pa·cm³/s. These differ by about tenfold. This is not proof of an incorrect machine; printed volume/time semantics or internal scaling may differ. Require an explanation and validation dataset.

Record: QC-REC-006 calculation validation: raw readings, units, formula/version, instrument output, independent result, difference and reviewer disposition.

## 11. Official physical record workflow

Use a separate run row for each sample/replicate. Record connector type, sample count, lot and sampling area, then equipment identity/medium, assembly force, torque, time and angle. Record actual temperature and humidity in the environmental block; an empty block remains missing information.

Enter set pressure (sp), applied pressure (tp), volume (v), pressure difference, holding time and instrument leakage result in their printed units. Retain the printer ticket with serial/run identifier and timestamp. Match each ticket to its sample row; do not assume the top ticket describes every row underneath. Distinguish setpoint from achieved pressure.

F-8-2-6-05 Rev04 prints 300–330 kPa, 15–20 s and <5000 Pa·cm³/s. F-8-2-6-07 Rev4 prints −80 to −88 kPa with the same time/limit. These are observed company-form values; adoption for a product requires the form/method reconciliation in DEC-004. A pressure outside the source range or a failed stability check needs investigation even if reported leakage is below the limit.

Mark the run outcome only after validity and criterion checks. Complete the overall PASS, FAIL or HOLD/FURTHER EVALUATION block separately from individual rows. Retain Tested by, Reviewed by and Approved by sections with actual identities/dates; do not fill a blank historical signature. Attach an investigation when independent calculation and printer output disagree.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
