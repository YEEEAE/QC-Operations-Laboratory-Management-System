# QC-WI-022 — Create and submit a rejection issue slip

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record an affected lot and proposed disposition from real rejection evidence.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: QC entry operator

Review: QC entry operator

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-014

## 3. Before you start

- Material identity, quantity/unit and rejection evidence exist.

- PERM-RREJ-CREATE and eligible submission grant apply.

## 4. Work steps and checks

1. Keep affected material segregated and identify the lot.

2. Open /reject-reports/new?type=slip and choose the issue-slip workflow.

3. Enter department, item description, lot, unit and quantities from the source.

4. Describe the rejection reason and link the actual test/inspection/incident.

5. Record the proposed disposition without treating it as approved.

6. Save and reopen the DRAFT to compare all fields with the original slip.

7. Submit through the supported action to the approval-tracking process.

8. Hand the exact report/version to an authorized confirmation actor; QC cannot attest or confirm.

## 5. Decisions, errors and stop conditions

- No source or mismatched quantity: stop submission.

- Creating the slip does not authorize rework, transfer or disposal.

## 6. Records and handoff

- Issue slip

- Source and quantity check

- Submitted version

- Approval handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

- Documents/OWNER-DECISION-RBAC-2026-09-23.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /reject-reports

- /reject-reports/new

- /reject-reports/issue-slips/[reportId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-017 — Rejection, physical disposition and metrics

For production-origin stock, route to the actual required Production, QC and Director authorities. For warehouse-origin stock, the supplied record explicitly notes that Production signature is not required; record the documented exception and its scope for that record. Do not map Production Manager to the application SUPERVISOR merely because both appear first in an approval chain.

Decision and exception check: QC entry records facts and prepares the report; actual approval confirmations are recorded only by an authorized confirming actor with source evidence. Rework or transfer needs a separate completed movement record and quantity reconciliation. Report the implemented reject/good ×100 metric under that explicit label; zero good denominator is undefined, not zero rejection. Any change to reject/total requires an approved definition and code change.

Record: QC-WI-022/023/024/025; FORM-015; IMG-066; QC-REC-008/010.

## 11. Official physical record workflow

Use F-7-5-7-8 Rev4. Select the actual Production/Warehouse origin, record date, item description, lot, unit, line quantity and total quantity. Attach the referenced incident/test report and identify the exact reason for rejection, including item code where shown in remarks.

Complete preparation and review in the physical workflow. Keep Checked by Production Team distinct from Reviewed by Quality Controller, and keep both distinct from the approval section for Production Manager, Quality Control Manager and Factory Director. The photographed warehouse report carries a documented Production-signature exception; retain its scope without generalizing it to every rejection.

Record proposed Rework, Transfer to Warehouse or Other disposition, then obtain the real approval before execution. Rework completion needs its own evidence and reinspection; selecting Rework does not show that it happened. Reconcile quantities sent, returned, scrapped and remaining. The digital confirmation is entered only by an authorized actor and linked to the real source.

Completion check: origin, lot, unit, quantities, reason, disposition, approval evidence and movement/reinspection references all agree. Keep the original report with its signatures and dates intact.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
