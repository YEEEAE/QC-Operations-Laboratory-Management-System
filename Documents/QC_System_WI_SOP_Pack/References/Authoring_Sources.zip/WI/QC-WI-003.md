# QC-WI-003 — Prepare receiving for inspection

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Check readiness and start inspection without creating an official result.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized receiving/inspection actor

Review: Authorized receiving/inspection actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-006

## 3. Before you start

- Receiving identity and required readiness evidence are complete.

- You have the specific transition and PERM-QUAR-START-INSPECTION grants.

## 4. Work steps and checks

1. Read the current receiving state, inspection result and version.

2. Resolve supplier, lot, date and quantity issues using the source documents.

3. Confirm the exact product template and approved source applicability.

4. If MARK_READY is available and its prerequisites pass, invoke it and reload READY_FOR_INSPECTION.

5. Select the supported start-inspection action; do not create a disconnected inspection record.

6. Verify the linked inspection identifier and frozen receiving/template context.

7. Confirm the receiving state returned by the server and retain the existing source evidence.

8. Hand the inspection record and samples to the assigned executor; no PASS or RELEASED claim is made at this stage.

## 5. Decisions, errors and stop conditions

- Missing source or denied action: preserve readiness blocker.

- HOLD or expired material: seek approved disposition before attempting inspection.

## 6. Records and handoff

- Readiness evidence

- Linked inspection and snapshot

- Work handoff

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/quarantine/receiving/application/create-inspection-from-receiving.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-027 — HOLD recovery and physical release label

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /quarantine

- /quarantine/receiving

- /quarantine/receiving/new

- /quarantine/receiving/[receivingId]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-027 — HOLD investigation and physical disposition

Investigate the reason and assemble the receiving, inspection/lab, equipment, source and discrepancy evidence. The authorized disposition owner decides continued HOLD, additional work, rejection, rework or release eligibility under an approved path. Record the decision and its conditions before moving material. Warehouse verifies identity and quantity against the signed disposition.

Decision and exception check: The current receiving state machine has no general outgoing HOLD transition. A proposed REMOVE_HOLD workflow must be implemented and verified under change control before digital use; do not edit the database or substitute a new receiving record. Physical release evidence and digital state must be reconciled, and no stale label is reused.

Record: QC-REC-020 HOLD and disposition; QC-SOP-006; QC-WI-004/005.

## 11. Official physical record workflow

Start with the yellow QC copy of F-7-5-7-1 Rev5 and the delivery/PO attachments. The printed distribution assigns original to Accounts, pink to Store Keeper, yellow to QC and blue to Production. Record which physical copy was checked; keep a readable linked scan when one photograph contains several overlapping pages.

Read Supplier’s Name, P.O. Ref. No., Ref. No., Ser. No. and Date independently. Ref. No. and Ser. No. may be different identifiers and must not overwrite each other. For each line, compare Sr. No., Item code no., Item Description, Unit, Qty. Received, Lot No. and Exp. Date to the actual label. Separate ordered quantity from this receipt quantity and preserve split deliveries.

Count containers and reconcile line totals in the same unit. Retain the original strike-through/correction and supporting note; ask the responsible source owner to explain a disagreement. Store Keeper acknowledgment establishes the physical receipt record; it does not establish QC release. Associate the digital receiving record with its exact paper line and evidence image/page.

Completion check: supplier, PO, item, lot, quantity/unit, receipt date and expiry agree across the physical item, slip and saved record; unresolved differences are linked to containment and Purchasing/Store Keeper clarification.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
