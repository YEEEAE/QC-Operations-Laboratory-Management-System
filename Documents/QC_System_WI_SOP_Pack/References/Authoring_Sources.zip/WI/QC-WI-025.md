# QC-WI-025 — Carry out an approved internal transfer or rework handoff

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Record the physical movement and preserve lot status and quantity balance.

Implementation: PROPOSED MANUAL PROCEDURE

## 2. Responsibilities and review

Responsible specialists: Warehouse; Production; QC

Review: Warehouse; Production; QC

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-016

## 3. Before you start

- Approved disposition and destination exist.

- Rework method and reinspection requirements are approved.

## 4. Work steps and checks

1. Read the disposition and identify the permitted lot, quantity/unit and action.

2. Count segregated units and record origin, destination and status.

3. Prepare the movement/rework record with related QC identifiers.

4. Keep HOLD/rejected labels during movement unless the actual disposition explicitly changes status.

5. Have the receiver compare identity, quantity and condition before accepting the handoff.

6. For rework, record work performed against the approved instruction.

7. Create required new inspection/retest work and retain the original failure.

8. Reconcile sender/receiver quantities and store the completed physical evidence.

## 5. Decisions, errors and stop conditions

- No digital transfer ledger exists for this process; use the approved manual record.

- No disposition: do not move or relabel.

## 6. Records and handoff

- Movement record

- Quantity reconciliation

- Rework evidence

- Reinspection link

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- Documents/REJECT-REPORTS.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-019 — Training, sample custody and movement

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-019 — Training, custody and movement

The assessor observes identity checks, correct source selection, a normal task, a deliberate exception, raw-data recording and safe handoff. Record each result and restriction. Reassess following a significant method/equipment change, an observed competence failure or the approved review schedule. Training attendance alone is insufficient.

Decision and exception check: For custody, record sample ID, parent lot, selection time, selector, quantity, condition, container/seal and every transfer with both parties and time. For movement, reconcile opening quantity, received/transferred, tested/destroyed, reworked, scrapped and closing balance in one unit. Discrepancies stop handoff until explained; maintain quarantine identity through transport.

Record: QC-REC-003, QC-REC-010 movement, QC-REC-012 competency; QC-SOP-002/007/016.

## 11. Official physical record workflow

Use F-7-5-7-8 Rev4. Select the actual Production/Warehouse origin, record date, item description, lot, unit, line quantity and total quantity. Attach the referenced incident/test report and identify the exact reason for rejection, including item code where shown in remarks.

Complete preparation and review in the physical workflow. Keep Checked by Production Team distinct from Reviewed by Quality Controller, and keep both distinct from the approval section for Production Manager, Quality Control Manager and Factory Director. The photographed warehouse report carries a documented Production-signature exception; retain its scope without generalizing it to every rejection.

Record proposed Rework, Transfer to Warehouse or Other disposition, then obtain the real approval before execution. Rework completion needs its own evidence and reinspection; selecting Rework does not show that it happened. Reconcile quantities sent, returned, scrapped and remaining. The digital confirmation is entered only by an authorized actor and linked to the real source.

Completion check: origin, lot, unit, quantities, reason, disposition, approval evidence and movement/reinspection references all agree. Keep the original report with its signatures and dates intact.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
