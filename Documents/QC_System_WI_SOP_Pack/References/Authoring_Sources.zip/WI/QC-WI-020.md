# QC-WI-020 — Authorize and create a traceable retest

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Create new linked work after an approved investigation and retest decision.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Technical method owner; Authorized lab actor

Review: Technical method owner; Authorized lab actor

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-012

## 3. Before you start

- The original test and suspect evidence are retained.

- The retest policy and action permission are approved.

## 4. Work steps and checks

1. Identify whether the concern is a failed result, invalid run or disputed interpretation.

2. Document the investigation and affected sample/run scope.

3. Obtain the technical retest decision, including sample selection and method.

4. Open the original test and use the supported retest action.

5. Enter the required reason and current version/context.

6. Verify the new test identifier and parent relationship without altering the original.

7. Prepare a new eligible run and record independent new evidence.

8. Review both tests together and retain the original failure and final disposition rationale.

## 5. Decisions, errors and stop conditions

- No technical authority: HOLD and seek review.

- Do not repeat tests until PASS or erase an earlier result.

## 6. Records and handoff

- Investigation

- Retest decision

- Parent/new test link

- Combined review

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/laboratory/application/create-retest.ts

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-026 — Retest, invalid work and lab rejection

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /laboratory

- /laboratory/tests

- /laboratory/tests/new

- /laboratory/tests/[labTestId]

- /laboratory/tests/[labTestId]/execute

- /laboratory/tests/[labTestId]/review

- /laboratory/tests/[labTestId]/retests/new

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-026 — Invalid test, retest and rejection

Contain affected material, identify all runs since the last valid control and record the reason for invalidation or retest. The method owner approves sample selection, repeat count, conditions and the rule for combining or separately reporting results before retesting. Link the new run to the original and preserve the operator, time, equipment and source revisions.

Decision and exception check: A confirmed product failure proceeds to the authorized nonconformance/disposition process. A passing retest does not erase a failing result. Ambiguous results remain HOLD/further evaluation until reviewed. The current digital lab reject path remains policy-blocked where PD-38 authority is not established; no alternate route is proposed.

Record: QC-REC-019 invalidation and retest authorization; QC-SOP-012; QC-WI-020/042.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
