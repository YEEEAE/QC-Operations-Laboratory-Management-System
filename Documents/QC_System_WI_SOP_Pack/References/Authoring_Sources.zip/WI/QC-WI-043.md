# QC-WI-043 — Generate and reconcile a report export

Revision D0.2 | DRAFT FOR REVIEW | Revised 2026-10-04

Effective date: not recorded. Approval/signature: not recorded. This draft does not authorize testing, release, production changes or UAT acceptance.

## 1. Purpose and scope

Verify the exported data against the scoped screen dataset.

Implementation: SOURCE-ALIGNED DRAFT

## 2. Responsibilities and review

Responsible specialists: Authorized report reader; Report owner

Review: Authorized report reader; Report owner

Approval: Authorized QMS / Document Control approver under the approved document policy; not yet established for this draft

Parent procedure: QC-SOP-025

## 3. Before you start

- PERM-RPT-VIEW and source scope apply.

- Filters, period, units and metric meaning are defined.

## 4. Work steps and checks

1. Open the report and record selected filters and source status.

2. Check scope, exact totals and unit grouping.

3. Identify the report provenance/dataset context before export.

4. Generate the supported export without changing filters.

5. If REPORT_DATASET_CHANGED appears, refresh and review a new coherent snapshot.

6. Compare exported rows, totals, units and provenance with the screen.

7. Retain the output in its approved location and mark unapproved prints clearly.

8. Record distribution only after the approved owner accepts the report meaning and evidence.

## 5. Decisions, errors and stop conditions

- Unavailable source is not zero.

- Request-local digest is not durable snapshot retention.

## 6. Records and handoff

- Filter/provenance context

- Export

- Parity check

- Distribution

Before handoff, reopen the saved record where the application supports it and compare the result with the source. Retain an unresolved outcome as unresolved; do not infer approval from a name, signature image, task completion or test result.

## 7. Sources and related documents

- src/modules/reporting

- Documents/REJECT-REPORTS.md

Repository sources are bound to HEAD 435f9f704049dee4916223b24b96866d7fa9af2e. Resolve source IDs, file hashes, external editions and form originals in References (source metadata is inside Authoring_Sources.zip).

## 8. Required decisions before approval

- DEC-017 — Rejection approval mapping and metrics

- DEC-020 — Retention, file safety and record storage

Document Control records real reviewer outcomes and actual approval/effectivity only after the controlled process. Completed proposals for these decisions are provided in References/Policy_and_Method_Decision_Book.pdf. Required source evidence and owner adoption remain explicitly recorded there.

## 9. Current route references

- /reports

- /reports/[reportCode]

Route placeholders identify existing records. Route coverage is documentation mapping, not proof that every role/state was accepted in a browser. Exact extracted field and permission strings are in References/route-coverage.pdf and References/source-contract-register.pdf.


## 10. Detailed operating policy and review checks

These are D0.2 proposed operating controls for adoption. Official company records remain valid physical source records; this revision does not retrospectively change their outcomes. Use the operational record named below to capture execution and exceptions.

DEC-017 — Rejection, physical disposition and metrics

For production-origin stock, route to the actual required Production, QC and Director authorities. For warehouse-origin stock, the supplied record explicitly notes that Production signature is not required; record the documented exception and its scope for that record. Do not map Production Manager to the application SUPERVISOR merely because both appear first in an approval chain.

Decision and exception check: QC entry records facts and prepares the report; actual approval confirmations are recorded only by an authorized confirming actor with source evidence. Rework or transfer needs a separate completed movement record and quantity reconciliation. Report the implemented reject/good ×100 metric under that explicit label; zero good denominator is undefined, not zero rejection. Any change to reject/total requires an approved definition and code change.

Record: QC-WI-022/023/024/025; FORM-015; IMG-066; QC-REC-008/010.

DEC-020 — Retention and controlled storage

For each class, QMS and the record owner set the legal/contractual basis, retention trigger, approved period, archive location, access roles, retrieval target and disposal authority. A legal hold suspends disposal. On receipt, verify type, readability, complete pages and malware-scan outcome under approved tooling; isolate suspicious files. A content hash checks integrity, not safety or approval.

Decision and exception check: Perform a retrieval check by locating a selected record, opening all attachments and confirming identity/hash and related signatures. Disposal requires hold review, eligibility evidence, authorized approval and a destruction log. If no retention period is approved, retain the record pending disposition rather than inventing an expiry.

Record: QC-REC-013 retention, retrieval and disposition schedule; QC-SOP-010/024.

## Revision record

D0.2, 2026-10-04: expanded execution, exception and handoff controls; incorporated owner-confirmed official physical forms and completed technical decision proposals. Previous D0.1 sources are retained in History/D0.1 within Authoring_Sources.zip. Review and approval remain unrecorded.
